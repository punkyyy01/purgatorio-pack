execute store result storage blue:trims temp.target_id int 1 run scoreboard players get @s blue.id
function blue:tr/delayed/cmd/trust/define/check_list with storage blue:trims temp