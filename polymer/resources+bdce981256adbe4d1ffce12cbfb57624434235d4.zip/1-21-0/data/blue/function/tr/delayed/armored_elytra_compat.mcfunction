item replace block 200600 2 200600 container.10 from entity @s armor.chest
data modify storage blue:trims temp.elytra set from block 200600 2 200600 Items[-1]
data modify storage blue:trims temp.elytra.components."minecraft:trim" set from storage blue:trims temp.elytra.components."minecraft:bundle_contents"[0].components."minecraft:trim"
data remove storage blue:trims temp.elytra.components."minecraft:bundle_contents"[0].components."minecraft:trim"
data modify block 200600 2 200600 Items[-1] set from storage blue:trims temp.elytra
item replace entity @s armor.chest from block 200600 2 200600 container.10