schedule function blue:tr/delayed/5t 5t
execute if score #.tr.owner_finder blue.config matches 1 if score #.tr.ownership_system blue.config matches 1 as @a[tag=!blue.trim_disabled,predicate=blue:tr/track] unless score @s blue.tr.current_trim matches 1.. at @s run function blue:tr/delayed/track
execute if score #.tr.objective_type blue.config matches 2 as @a[scores={blue.tr.rtd_value=1..}] run function blue:tr/tasks/rtd/main
execute unless score #.tr.ability_shortcuts blue.config matches 1..2 as @a[scores={Trims_Menu.BLUE=1..}] at @s run function blue:tr/delayed/cmd/trigger
execute if score #.60 blue.misc matches 60.. run function blue:tr/delayed/3s