scoreboard players set #.players blue.misc 99999
scoreboard players set @s Trims_Menu.BLUE 1000
function blue:tr/delayed/cmd/trust