execute if entity @s[advancements={blue:tr/tags={trusted_self=false}}] run function blue:tr/delayed/cmd/trust/define/auto_self
advancement grant @s[advancements={blue:tr/display/guides/trust=false}] only blue:tr/display/guides/trust
function blue:tr/delayed/cmd/trust/define/main
execute unless score @s Trims_Menu.BLUE matches 1000 store result storage blue:trims temp.click int 1 run scoreboard players get @s Trims_Menu.BLUE
execute unless score @s Trims_Menu.BLUE matches 1000 store result score #.link blue.id run scoreboard players remove @s Trims_Menu.BLUE 1000
execute unless score @s Trims_Menu.BLUE matches 1000 as @a[predicate=blue:shared/id_link,limit=1] run function blue:tr/delayed/cmd/trust/change with storage blue:trims temp
execute unless score @s Trims_Menu.BLUE matches 1000 run tag @a[tag=blue.tr.trusted_player] remove blue.tr.trusted_player
execute unless score @s Trims_Menu.BLUE matches 1000 run return fail
playsound ui.button.click player @s 0 -128 0 0 2 0.75
data remove storage blue:trims display
execute unless score #.players blue.misc matches 99999 store result score #.players blue.misc if entity @a
tag @a[distance=..12] add blue.tr.trust_nearby
execute as @a[tag=blue.tr.trusted_player,tag=blue.tr.trust_nearby,sort=nearest] run function blue:tr/delayed/cmd/trust/player
execute as @a[tag=blue.tr.trusted_player,tag=!blue.tr.trust_nearby] run function blue:tr/delayed/cmd/trust/player
execute as @a[tag=!blue.tr.trusted_player,tag=blue.tr.trust_nearby,sort=nearest] run function blue:tr/delayed/cmd/trust/player
execute as @a[tag=!blue.tr.trusted_player,tag=!blue.tr.trust_nearby] run function blue:tr/delayed/cmd/trust/player
tag @a[tag=blue.tr.trusted_player] remove blue.tr.trusted_player
tag @a[tag=blue.tr.trust_nearby,distance=..13] remove blue.tr.trust_nearby
execute unless score #.players blue.misc >= #.tr.trust_compact blue.config run tellraw @s [{"text":"-- -- -- -- -- -- -- -- -- -- -- -- -- --\n","color":"gray"},{"storage":"blue:trims","nbt":"display[]","separator":"\n","interpret":true},"\n-- -- -- -- -- -- -- -- -- -- -- -- -- --"]
execute if score #.players blue.misc >= #.tr.trust_compact blue.config run tellraw @s [{"text":"-- -- -- -- -- -- -- -- -- -- -- -- -- --\n ","color":"gray"},{"storage":"blue:trims","nbt":"display[]","separator":{"text":", ","color":"gray"},"interpret":true},"\n-- -- -- -- -- -- -- -- -- -- -- -- -- --"]
scoreboard players reset #.players blue.misc