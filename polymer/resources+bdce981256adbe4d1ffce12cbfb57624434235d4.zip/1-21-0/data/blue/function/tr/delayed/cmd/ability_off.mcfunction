scoreboard players reset #.temp Trims_Menu.BLUE
execute unless score #.tr.no_toggle_vfx blue.config matches 1 run particle wax_off ~ ~1 ~ 0.3 0.5 0.3 2 12
execute unless score #.tr.no_toggle_vfx blue.config matches 1 run playsound block.amethyst_block.resonate player @a[distance=..20] ~ ~ ~ 0.5 0.5
execute unless score #.tr.no_toggle_vfx blue.config matches 1 run tellraw @s [{"translate":"blue.tr.trim_abilities","fallback":"Trim Abilities","color":"gray","clickEvent":{"action":"run_command","value":"/trigger Trims_Menu.BLUE set 2"},"hoverEvent":{"action":"show_text","contents":{"translate":"blue.tr.menu.abilities_hover","fallback":"Toggle Trim Ability","color":"gray"}}},{"text":": ","color":"dark_gray"},{"translate":"options.off","color":"dark_red"}]
tag @s add blue.trim_disabled
function blue:tr/inv/unequip/attributes
scoreboard players operation #.link blue.id = @s blue.id
scoreboard players set @e[tag=blue.tr.host.guardian,predicate=blue:shared/id_link,type=iron_golem] blue.misc 200
kill @e[tag=blue.tr.entity,type=!player,predicate=blue:shared/id_link]
tag @s[tag=blue.tr.shaper.absorption] remove blue.tr.shaper.absorption
tag @s[tag=blue.tr.shaper.falling] remove blue.tr.shaper.falling
tag @s[tag=blue.tr.spire.origin] remove blue.tr.spire.origin
tag @s[tag=blue.tr.tide.in_rain] remove blue.tr.tide.in_rain
tag @s[tag=blue.tr.wayfinder.warping] remove blue.tr.wayfinder.warping
tag @s[tag=blue.tr.ward.stonewall] remove blue.tr.ward.stonewall
tag @s[tag=blue.tr.eye.actionbar] remove blue.tr.eye.actionbar
tag @s[tag=blue.tr.eye.actionbar-2] remove blue.tr.eye.actionbar-2
tag @s[tag=blue.tr.vex.isolated] remove blue.tr.vex.isolated
tag @s[tag=blue.tr.vex.isolated_lunge] remove blue.tr.vex.isolated_lunge
tag @s[tag=blue.tr.wild.placing] remove blue.tr.wild.placing
tag @s[tag=blue.tr.wild.florist] remove blue.tr.wild.florist
tag @s[tag=blue.tr.wild.looking] remove blue.tr.wild.looking
tag @s[tag=blue.tr.host.channeling] remove blue.tr.host.channeling
tag @s[tag=blue.tr.flow.in_chamber] remove blue.tr.flow.in_chamber
tag @s[tag=blue.tr.flow.out_water] remove blue.tr.flow.out_water
effect give @s[scores={blue.tr.current_trim=9,blue.tr.primary_data=1..}] weakness 5 9
effect clear @s[scores={blue.tr.current_trim=11},predicate=blue:tr/aperture_res] resistance
scoreboard players reset @s blue.tr.primary_data
scoreboard players reset @s blue.tr.secondary_data
scoreboard players reset @s blue.tr.third_data
scoreboard players reset @s blue.tr.fourth_data
team leave @s[team=blue.tr.rib]
team leave @s[team=blue.tr.silence]
execute unless score @s blue.tr.current_trim matches 10 run return fail
kill @e[tag=blue.tr.gamble.display,predicate=blue:shared/id_link,type=text_display]
execute as @e[tag=blue.tr.gamble.item,predicate=blue:shared/id_link,type=item] run data merge entity @s {PickupDelay:10s,Age:400,Health:5s}
execute as @e[tag=blue.tr.gamble.item,predicate=blue:shared/id_link,type=item] on passengers run kill @s[type=text_display]
tag @e[tag=blue.tr.gamble.ground,predicate=blue:shared/id_link,type=item] remove blue.tr.ground
tag @e[tag=blue.tr.gamble.item,predicate=blue:shared/id_link,type=item] remove blue.tr.gamble.item