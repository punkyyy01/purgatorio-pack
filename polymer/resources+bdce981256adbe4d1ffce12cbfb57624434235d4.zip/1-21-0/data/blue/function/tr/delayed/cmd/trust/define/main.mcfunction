tag @a[tag=blue.tr.trusted_player] remove blue.tr.trusted_player
execute store result storage blue:trims temp.id int 1 run scoreboard players get @s blue.id
execute as @a run function blue:tr/delayed/cmd/trust/define/player