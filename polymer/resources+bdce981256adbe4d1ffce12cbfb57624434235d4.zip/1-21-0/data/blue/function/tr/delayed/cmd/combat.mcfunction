scoreboard players operation #x blue.misc = @s blue.tr.combat
scoreboard players operation #x blue.misc *= #20 blue.misc
execute if score #x blue.misc matches ..-1 run scoreboard players operation #x blue.misc *= #-1 blue.misc
execute store result score #z blue.misc store result storage blue:trims temp.int int 0.1 run scoreboard players operation #x blue.misc /= #40 blue.misc
execute store result score #x blue.misc run data get storage blue:trims temp.int 10
scoreboard players operation #z blue.misc -= #x blue.misc
execute if score @s blue.tr.combat matches 0.. run return run title @s actionbar {"translate":"blue.tr.out_combat","fallback":"You've been out of combat for %s seconds","color":"gray","with":[{"storage":"blue:trims","nbt":"temp.int","color":"white","plain":true}]}
title @s actionbar {"translate":"blue.tr.in_combat","fallback":"You're in combat for %s.%s seconds","color":"gray","with":[{"storage":"blue:trims","nbt":"temp.int","color":"red","plain":true},{"score":{"name":"#z","objective":"blue.misc"},"color":"dark_red"}]}