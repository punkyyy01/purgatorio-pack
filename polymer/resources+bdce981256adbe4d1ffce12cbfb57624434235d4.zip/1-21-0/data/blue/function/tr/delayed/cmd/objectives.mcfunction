tellraw @s {"text":"-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --","color":"gray"}
scoreboard players set #.temp blue.misc -123
function blue:tr/settings/objective_type
function blue:tr/settings/objective_completion
function blue:tr/settings/require_unlock
function blue:tr/settings/limit_owned_trims
scoreboard players reset #.temp blue.misc
tellraw @s "\n"
data remove storage blue:trims display
data modify storage blue:trims temp.d.wayfinder append value {"text":""}
data modify storage blue:trims temp.d.wayfinder append value {"translate":"structure.minecraft.ancient_city","fallback":"Ancient City","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wayfinder={ancient_city=false}}] run data modify storage blue:trims temp.d.wayfinder[-1].color set value "red"
data modify storage blue:trims temp.d.wayfinder append value {"translate":"structure.minecraft.bastion_remnant","fallback":"Bastion Remnant","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wayfinder={bastion_remnant=false}}] run data modify storage blue:trims temp.d.wayfinder[-1].color set value "red"
data modify storage blue:trims temp.d.wayfinder append value {"translate":"structure.minecraft.buried_treasure","fallback":"Buried Treasure","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wayfinder={buried_treasure=false}}] run data modify storage blue:trims temp.d.wayfinder[-1].color set value "red"
data modify storage blue:trims temp.d.wayfinder append value {"translate":"structure.minecraft.desert_pyramid","fallback":"Desert Pyramid","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wayfinder={desert_pyramid=false}}] run data modify storage blue:trims temp.d.wayfinder[-1].color set value "red"
data modify storage blue:trims temp.d.wayfinder append value {"translate":"structure.minecraft.end_city","fallback":"End City","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wayfinder={end_city=false}}] run data modify storage blue:trims temp.d.wayfinder[-1].color set value "red"
data modify storage blue:trims temp.d.wayfinder append value {"translate":"structure.minecraft.fortress","fallback":"Nether Fortress","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wayfinder={fortress=false}}] run data modify storage blue:trims temp.d.wayfinder[-1].color set value "red"
data modify storage blue:trims temp.d.wayfinder append value {"translate":"structure.minecraft.igloo","fallback":"Igloo","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wayfinder={igloo=false}}] run data modify storage blue:trims temp.d.wayfinder[-1].color set value "red"
data modify storage blue:trims temp.d.wayfinder append value {"translate":"structure.minecraft.jungle_pyramid","fallback":"Jungle Pyramid","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wayfinder={jungle_pyramid=false}}] run data modify storage blue:trims temp.d.wayfinder[-1].color set value "red"
data modify storage blue:trims temp.d.wayfinder append value {"translate":"structure.minecraft.mansion","fallback":"Mansion","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wayfinder={mansion=false}}] run data modify storage blue:trims temp.d.wayfinder[-1].color set value "red"
data modify storage blue:trims temp.d.wayfinder append value {"translate":"structure.minecraft.mineshaft","fallback":"Mineshaft","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wayfinder={mineshaft=false}}] run data modify storage blue:trims temp.d.wayfinder[-1].color set value "red"
data modify storage blue:trims temp.d.wayfinder append value {"translate":"structure.minecraft.monument","fallback":"Monument","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wayfinder={monument=false}}] run data modify storage blue:trims temp.d.wayfinder[-1].color set value "red"
data modify storage blue:trims temp.d.wayfinder append value {"translate":"structure.minecraft.nether_fossil","fallback":"Nether Fossil","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wayfinder={nether_fossil=false}}] run data modify storage blue:trims temp.d.wayfinder[-1].color set value "red"
data modify storage blue:trims temp.d.wayfinder append value {"translate":"structure.minecraft.ocean_ruin","fallback":"Ocean Ruin","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wayfinder={ocean_ruin=false}}] run data modify storage blue:trims temp.d.wayfinder[-1].color set value "red"
data modify storage blue:trims temp.d.wayfinder append value {"translate":"structure.minecraft.pillager_outpost","fallback":"Pillager Outpost","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wayfinder={pillager_outpost=false}}] run data modify storage blue:trims temp.d.wayfinder[-1].color set value "red"
data modify storage blue:trims temp.d.wayfinder append value {"translate":"structure.minecraft.ruined_portal","fallback":"Ruined Portal","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wayfinder={ruined_portal=false}}] run data modify storage blue:trims temp.d.wayfinder[-1].color set value "red"
data modify storage blue:trims temp.d.wayfinder append value {"translate":"structure.minecraft.shipwreck","fallback":"Shipwreck","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wayfinder={shipwreck=false}}] run data modify storage blue:trims temp.d.wayfinder[-1].color set value "red"
data modify storage blue:trims temp.d.wayfinder append value {"translate":"structure.minecraft.stronghold","fallback":"Stronghold","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wayfinder={stronghold=false}}] run data modify storage blue:trims temp.d.wayfinder[-1].color set value "red"
data modify storage blue:trims temp.d.wayfinder append value {"translate":"structure.minecraft.swamp_hut","fallback":"Swamp Hut","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wayfinder={swamp_hut=false}}] run data modify storage blue:trims temp.d.wayfinder[-1].color set value "red"
data modify storage blue:trims temp.d.wayfinder append value {"translate":"structure.minecraft.trail_ruins","fallback":"Trail Ruins","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wayfinder={trail_ruins=false}}] run data modify storage blue:trims temp.d.wayfinder[-1].color set value "red"
data modify storage blue:trims temp.d.wayfinder append value {"translate":"structure.minecraft.village","fallback":"Village","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wayfinder={village=false}}] run data modify storage blue:trims temp.d.wayfinder[-1].color set value "red"
data modify storage blue:trims temp.d.wayfinder append value {"translate":"structure.minecraft.trial_chamber","fallback":"Trial Chamber","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wayfinder={trial_chamber=false}}] run data modify storage blue:trims temp.d.wayfinder[-1].color set value "red"
execute if entity @s[advancements={blue:tr/quests/raiser={power=true}}] run data modify storage blue:trims temp.d.raiser append value {"translate":"enchantment.minecraft.power","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/raiser={sharpness=true}}] run data modify storage blue:trims temp.d.raiser append value {"translate":"enchantment.minecraft.sharpness","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/raiser={smite=true}}] run data modify storage blue:trims temp.d.raiser append value {"translate":"enchantment.minecraft.smite","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/raiser={bane_of_arthropods=true}}] run data modify storage blue:trims temp.d.raiser append value {"translate":"enchantment.minecraft.bane_of_arthropods","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/raiser={fire_aspect=true}}] run data modify storage blue:trims temp.d.raiser append value {"translate":"enchantment.minecraft.fire_aspect","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/raiser={thorns=true}}] run data modify storage blue:trims temp.d.raiser append value {"translate":"enchantment.minecraft.thorns"}
execute if entity @s[advancements={blue:tr/quests/snout={enchanted_book_1=true}}] run data modify storage blue:trims temp.d.snout append value {"translate":"item.minecraft.enchanted_book","extra":[{"text":"-1, ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/snout={enchanted_book_2=true}}] run data modify storage blue:trims temp.d.snout append value {"translate":"item.minecraft.enchanted_book","extra":[{"text":"-2, ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/snout={enchanted_book_3=true}}] run data modify storage blue:trims temp.d.snout append value {"translate":"item.minecraft.enchanted_book","extra":[{"text":"-3, ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/snout={iron_boots_1=true}}] run data modify storage blue:trims temp.d.snout append value {"translate":"item.minecraft.iron_boots","extra":[{"text":"-1, ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/snout={iron_boots_2=true}}] run data modify storage blue:trims temp.d.snout append value {"translate":"item.minecraft.iron_boots","extra":[{"text":"-2, ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/snout={iron_boots_3=true}}] run data modify storage blue:trims temp.d.snout append value {"translate":"item.minecraft.iron_boots","extra":[{"text":"-3, ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/snout={splash_potion=true}}] run data modify storage blue:trims temp.d.snout append value {"translate":"item.minecraft.splash_potion.effect.fire_resistance","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/snout={fire_potion=true}}] run data modify storage blue:trims temp.d.snout append value {"translate":"item.minecraft.potion.effect.fire_resistance","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/snout={potion=true}}] run data modify storage blue:trims temp.d.snout append value {"translate":"item.minecraft.potion.effect.water","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/snout={iron_nugget=true}}] run data modify storage blue:trims temp.d.snout append value {"translate":"item.minecraft.iron_nugget","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/snout={ender_pearl=true}}] run data modify storage blue:trims temp.d.snout append value {"translate":"item.minecraft.ender_pearl","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/snout={string=true}}] run data modify storage blue:trims temp.d.snout append value {"translate":"item.minecraft.string","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/snout={obsidian=true}}] run data modify storage blue:trims temp.d.snout append value {"translate":"item.minecraft.obsidian","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/snout={fire_charge=true}}] run data modify storage blue:trims temp.d.snout append value {"translate":"item.minecraft.fire_charge","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/snout={crying_obsidian=true}}] run data modify storage blue:trims temp.d.snout append value {"translate":"item.minecraft.crying_obsidian","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/snout={leather=true}}] run data modify storage blue:trims temp.d.snout append value {"translate":"item.minecraft.leather","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/snout={soul_sand=true}}] run data modify storage blue:trims temp.d.snout append value {"translate":"item.minecraft.soul_sand","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/snout={nether_brick=true}}] run data modify storage blue:trims temp.d.snout append value {"translate":"item.minecraft.nether_brick","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/snout={spectral_arrow=true}}] run data modify storage blue:trims temp.d.snout append value {"translate":"item.minecraft.spectral_arrow","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/snout={gravel=true}}] run data modify storage blue:trims temp.d.snout append value {"translate":"item.minecraft.gravel","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/snout={blackstone=true}}] run data modify storage blue:trims temp.d.snout append value {"translate":"item.minecraft.blackstone"}
execute if entity @s[advancements={blue:tr/quests/ward_stored={warden=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.warden","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={zombie=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.zombie","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={spider=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.spider","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={creeper=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.creeper","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={skeleton=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.skeleton","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={enderman=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.enderman","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={endermite=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.endermite","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={cave_spider=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.cave_spider","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={zombie_villager=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.zombie_villager","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={silverfish=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.silverfish","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={drowned=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.drowned","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={wither_skeleton=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.wither_skeleton","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={blaze=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.blaze","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={piglin=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.piglin","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={zombified_piglin=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.zombified_piglin","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={hoglin=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.hoglin","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={zoglin=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.zoglin","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={magma_cube=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.magma_cube","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={piglin_brute=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.piglin_brute","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={wither=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.wither","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={vex=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.vex","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={husk=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.husk","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={breeze=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.breeze","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={bogged=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.bogged","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={vindicator=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.vindicator","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={evoker=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.evoker","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={pillager=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.pillager","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={slime=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.slime","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={ravager=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.ravager","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={stray=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"entity.minecraft.stray","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/ward_stored={unknown=true}}] run data modify storage blue:trims temp.d.ward append value {"translate":"mco.configure.world.subscription.unknown","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/tags={unlocked_ward=true}}] run function blue:tr/quests/ward_store
data modify storage blue:trims temp.d.ward append value {"text":""}
data modify storage blue:trims temp.d.ward append value {"text":"- ","color":"dark_gray","extra":[{"score":{"name":"#.temp","objective":"blue.misc"},"extra":[{"text":"/"},{"score":{"objective":"blue.config","name":"#.tr.ward_quest"}}],"color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wild_tames={cat=true}}] run data modify storage blue:trims temp.d.wild append value {"translate":"entity.minecraft.cat","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wild_tames={wolf=true}}] run data modify storage blue:trims temp.d.wild append value {"translate":"entity.minecraft.wolf","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wild_tames={parrot=true}}] run data modify storage blue:trims temp.d.wild append value {"translate":"entity.minecraft.parrot","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wild_tames={horse=true}}] run data modify storage blue:trims temp.d.wild append value {"translate":"entity.minecraft.horse","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wild_tames={donkey=true}}] run data modify storage blue:trims temp.d.wild append value {"translate":"entity.minecraft.donkey","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wild_tames={mule=true}}] run data modify storage blue:trims temp.d.wild append value {"translate":"entity.minecraft.mule","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wild_tames={camel=true}}] run data modify storage blue:trims temp.d.wild append value {"translate":"entity.minecraft.camel","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wild_tames={llama=true}}] run data modify storage blue:trims temp.d.wild append value {"translate":"entity.minecraft.llama","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wild_tames={trader_llama=true}}] run data modify storage blue:trims temp.d.wild append value {"translate":"entity.minecraft.trader_llama","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wild_tames={skeleton_horse=true}}] run data modify storage blue:trims temp.d.wild append value {"translate":"entity.minecraft.skeleton_horse","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wild_tames={zombie_horse=true}}] run data modify storage blue:trims temp.d.wild append value {"translate":"entity.minecraft.zombie_horse","extra":[{"text":", ","color":"gray"}]}
execute if entity @s[advancements={blue:tr/quests/wild_tames={non_vanilla=true}}] run data modify storage blue:trims temp.d.wild append value {"translate":"mco.configure.world.subscription.unknown"}
function blue:tr/delayed/cmd/progress
execute unless score #.tr.objective_type blue.config matches 1..2 if entity @s[advancements={blue:tr/tags={unlocked_wayfinder=true}}] run data modify storage blue:trims display append value [{"translate":"Wayfinder","color":"#F1FFC8"},{"text":", ","color":"dark_gray"}]
execute unless score #.tr.objective_type blue.config matches 1..2 if entity @s[advancements={blue:tr/tags={unlocked_silence=true}}] run data modify storage blue:trims display append value [{"translate":"Silence","color":"#3842Cf"},{"text":", ","color":"dark_gray"}]
execute unless score #.tr.objective_type blue.config matches 1..2 if entity @s[advancements={blue:tr/tags={unlocked_raiser=true}}] run data modify storage blue:trims display append value [{"translate":"Raiser","color":"#95B623"},{"text":", ","color":"dark_gray"}]
execute unless score #.tr.objective_type blue.config matches 1..2 if entity @s[advancements={blue:tr/tags={unlocked_shaper=true}}] run data modify storage blue:trims display append value [{"translate":"Shaper","color":"#8F8F8F"},{"text":", ","color":"dark_gray"}]
execute unless score #.tr.objective_type blue.config matches 1..2 if entity @s[advancements={blue:tr/tags={unlocked_sentry=true}}] run data modify storage blue:trims display append value [{"translate":"Sentry","color":"#4B885B"},{"text":", ","color":"dark_gray"}]
execute unless score #.tr.objective_type blue.config matches 1..2 if entity @s[advancements={blue:tr/tags={unlocked_spire=true}}] run data modify storage blue:trims display append value [{"translate":"Spire","color":"#BE20C7"},{"text":", ","color":"dark_gray"}]
execute unless score #.tr.objective_type blue.config matches 1..2 if entity @s[advancements={blue:tr/tags={unlocked_coast=true}}] run data modify storage blue:trims display append value [{"translate":"Coast","color":"#C1C888"},{"text":", ","color":"dark_gray"}]
execute unless score #.tr.objective_type blue.config matches 1..2 if entity @s[advancements={blue:tr/tags={unlocked_snout=true}}] run data modify storage blue:trims display append value [{"translate":"Snout","color":"#F2B01A"},{"text":", ","color":"dark_gray"}]
execute unless score #.tr.objective_type blue.config matches 1..2 if entity @s[advancements={blue:tr/tags={unlocked_ward=true}}] run data modify storage blue:trims display append value [{"translate":"Ward","color":"#5C70AE"},{"text":", ","color":"dark_gray"}]
execute unless score #.tr.objective_type blue.config matches 1..2 if entity @s[advancements={blue:tr/tags={unlocked_bolt=true}}] run data modify storage blue:trims display append value [{"translate":"Bolt","color":"#B65D1A"},{"text":", ","color":"dark_gray"}]
execute unless score #.tr.objective_type blue.config matches 1..2 if entity @s[advancements={blue:tr/tags={unlocked_flow=true}}] run data modify storage blue:trims display append value [{"translate":"Flow","color":"#85B2C5"},{"text":", ","color":"dark_gray"}]
execute unless score #.tr.objective_type blue.config matches 1..2 if entity @s[advancements={blue:tr/tags={unlocked_dune=true}}] run data modify storage blue:trims display append value [{"translate":"Dune","color":"#E7C547"},{"text":", ","color":"dark_gray"}]
execute unless score #.tr.objective_type blue.config matches 1..2 if entity @s[advancements={blue:tr/tags={unlocked_wild=true}}] run data modify storage blue:trims display append value [{"translate":"Wild","color":"#00D529"},{"text":", ","color":"dark_gray"}]
execute unless score #.tr.objective_type blue.config matches 1..2 if entity @s[advancements={blue:tr/tags={unlocked_tide=true}}] run data modify storage blue:trims display append value [{"translate":"Tide","color":"#199ADD"},{"text":", ","color":"dark_gray"}]
execute unless score #.tr.objective_type blue.config matches 1..2 if entity @s[advancements={blue:tr/tags={unlocked_host=true}}] run data modify storage blue:trims display append value [{"translate":"Host","color":"#A34646"},{"text":", ","color":"dark_gray"}]
execute unless score #.tr.objective_type blue.config matches 1..2 if entity @s[advancements={blue:tr/tags={unlocked_eye=true}}] run data modify storage blue:trims display append value [{"translate":"Eye","color":"#1F8A46"},{"text":", ","color":"dark_gray"}]
execute unless score #.tr.objective_type blue.config matches 1..2 if entity @s[advancements={blue:tr/tags={unlocked_rib=true}}] run data modify storage blue:trims display append value [{"translate":"Rib","color":"#E6484B"},{"text":", ","color":"dark_gray"}]
execute unless score #.tr.objective_type blue.config matches 1..2 if entity @s[advancements={blue:tr/tags={unlocked_vex=true}}] run data modify storage blue:trims display append value [{"translate":"Vex","color":"#CFC6A5"},{"text":", ","color":"dark_gray"}]
data remove storage blue:trims display[-1][-1]
execute unless data storage blue:trims display[0][0] run data modify storage blue:trims display set value [[{"translate":"gui.none","color":"dark_red"}]]
tellraw @s [{"translate":"blue.tr.unlocked_objectives","fallback":"Unlocked Objectives","color":"gray"},{"text":": ","color":"dark_gray"},{"storage":"blue:trims","nbt":"display[][]","interpret":true,"separator":""}," ",{"text":"ℹ","color":"gray","hover_event":{"action":"show_text","value":{"translate":"blue.tr.unlocked_objectives_hover","fallback":"Based on the server settings, you need to pick up the vanilla template to unlock objectives. This is the list of templates you've already picked up.","color":"gray"}},"hoverEvent":{"action":"show_text","contents":{"translate":"blue.tr.unlocked_objectives_hover","fallback":"Based on the server settings, you need to pick up the vanilla template to unlock objectives. This is the list of templates you've already picked up.","color":"gray"}}},"\n"]
data remove storage blue:trims display
execute if score #.tr.wayfinder_completed blue.config matches 1.. run data modify storage blue:trims display append value [{"translate":"Wayfinder","color":"#F1FFC8"},{"text":", ","color":"dark_gray"}]
execute if score #.tr.silence_completed blue.config matches 1.. run data modify storage blue:trims display append value [{"translate":"Silence","color":"#3842Cf"},{"text":", ","color":"dark_gray"}]
execute if score #.tr.raiser_completed blue.config matches 1.. run data modify storage blue:trims display append value [{"translate":"Raiser","color":"#95B623"},{"text":", ","color":"dark_gray"}]
execute if score #.tr.shaper_completed blue.config matches 1.. run data modify storage blue:trims display append value [{"translate":"Shaper","color":"#8F8F8F"},{"text":", ","color":"dark_gray"}]
execute if score #.tr.sentry_completed blue.config matches 1.. run data modify storage blue:trims display append value [{"translate":"Sentry","color":"#4B885B"},{"text":", ","color":"dark_gray"}]
execute if score #.tr.spire_completed blue.config matches 1.. run data modify storage blue:trims display append value [{"translate":"Spire","color":"#BE20C7"},{"text":", ","color":"dark_gray"}]
execute if score #.tr.coast_completed blue.config matches 1.. run data modify storage blue:trims display append value [{"translate":"Coast","color":"#C1C888"},{"text":", ","color":"dark_gray"}]
execute if score #.tr.snout_completed blue.config matches 1.. run data modify storage blue:trims display append value [{"translate":"Snout","color":"#F2B01A"},{"text":", ","color":"dark_gray"}]
execute if score #.tr.ward_completed blue.config matches 1.. run data modify storage blue:trims display append value [{"translate":"Ward","color":"#5C70AE"},{"text":", ","color":"dark_gray"}]
execute if score #.tr.bolt_completed blue.config matches 1.. run data modify storage blue:trims display append value [{"translate":"Bolt","color":"#B65D1A"},{"text":", ","color":"dark_gray"}]
execute if score #.tr.flow_completed blue.config matches 1.. run data modify storage blue:trims display append value [{"translate":"Flow","color":"#85B2C5"},{"text":", ","color":"dark_gray"}]
execute if score #.tr.dune_completed blue.config matches 1.. run data modify storage blue:trims display append value [{"translate":"Dune","color":"#E7C547"},{"text":", ","color":"dark_gray"}]
execute if score #.tr.wild_completed blue.config matches 1.. run data modify storage blue:trims display append value [{"translate":"Wild","color":"#00D529"},{"text":", ","color":"dark_gray"}]
execute if score #.tr.tide_completed blue.config matches 1.. run data modify storage blue:trims display append value [{"translate":"Tide","color":"#199ADD"},{"text":", ","color":"dark_gray"}]
execute if score #.tr.host_completed blue.config matches 1.. run data modify storage blue:trims display append value [{"translate":"Host","color":"#A34646"},{"text":", ","color":"dark_gray"}]
execute if score #.tr.eye_completed blue.config matches 1.. run data modify storage blue:trims display append value [{"translate":"Eye","color":"#1F8A46"},{"text":", ","color":"dark_gray"}]
execute if score #.tr.rib_completed blue.config matches 1.. run data modify storage blue:trims display append value [{"translate":"Rib","color":"#E6484B"},{"text":", ","color":"dark_gray"}]
execute if score #.tr.vex_completed blue.config matches 1.. run data modify storage blue:trims display append value [{"translate":"Vex","color":"#CFC6A5"},{"text":", ","color":"dark_gray"}]
data remove storage blue:trims display[-1][-1]
execute unless data storage blue:trims display run data modify storage blue:trims display set value [{"translate":"gui.none","color":"dark_green"}]
tellraw @s [{"translate":"blue.tr.completed_objectives","fallback":"Completed Objectives","color":"gray"},{"text":": ","color":"dark_gray"},{"storage":"blue:trims","nbt":"display","interpret":true,"separator":""},"\n"]
data remove storage blue:trims temp.d
function blue:tr/delayed/cmd/check_owned
tellraw @s ""
data remove storage blue:trims display
execute if entity @s[advancements={blue:tr/blacklist={wayfinder=true}}] run data modify storage blue:trims display append value [{"translate":"Wayfinder","color":"#F1FFC8"},{"text":", ","color":"dark_gray"}]
execute if entity @s[advancements={blue:tr/blacklist={silence=true}}] run data modify storage blue:trims display append value [{"translate":"Silence","color":"#3842Cf"},{"text":", ","color":"dark_gray"}]
execute if entity @s[advancements={blue:tr/blacklist={raiser=true}}] run data modify storage blue:trims display append value [{"translate":"Raiser","color":"#95B623"},{"text":", ","color":"dark_gray"}]
execute if entity @s[advancements={blue:tr/blacklist={shaper=true}}] run data modify storage blue:trims display append value [{"translate":"Shaper","color":"#8F8F8F"},{"text":", ","color":"dark_gray"}]
execute if entity @s[advancements={blue:tr/blacklist={sentry=true}}] run data modify storage blue:trims display append value [{"translate":"Sentry","color":"#4B885B"},{"text":", ","color":"dark_gray"}]
execute if entity @s[advancements={blue:tr/blacklist={spire=true}}] run data modify storage blue:trims display append value [{"translate":"Spire","color":"#BE20C7"},{"text":", ","color":"dark_gray"}]
execute if entity @s[advancements={blue:tr/blacklist={coast=true}}] run data modify storage blue:trims display append value [{"translate":"Coast","color":"#C1C888"},{"text":", ","color":"dark_gray"}]
execute if entity @s[advancements={blue:tr/blacklist={snout=true}}] run data modify storage blue:trims display append value [{"translate":"Snout","color":"#F2B01A"},{"text":", ","color":"dark_gray"}]
execute if entity @s[advancements={blue:tr/blacklist={ward=true}}] run data modify storage blue:trims display append value [{"translate":"Ward","color":"#5C70AE"},{"text":", ","color":"dark_gray"}]
execute if entity @s[advancements={blue:tr/blacklist={dune=true}}] run data modify storage blue:trims display append value [{"translate":"Dune","color":"#E7C547"},{"text":", ","color":"dark_gray"}]
execute if entity @s[advancements={blue:tr/blacklist={wild=true}}] run data modify storage blue:trims display append value [{"translate":"Wild","color":"#00D529"},{"text":", ","color":"dark_gray"}]
execute if entity @s[advancements={blue:tr/blacklist={tide=true}}] run data modify storage blue:trims display append value [{"translate":"Tide","color":"#199ADD"},{"text":", ","color":"dark_gray"}]
execute if entity @s[advancements={blue:tr/blacklist={host=true}}] run data modify storage blue:trims display append value [{"translate":"Host","color":"#A34646"},{"text":", ","color":"dark_gray"}]
execute if entity @s[advancements={blue:tr/blacklist={eye=true}}] run data modify storage blue:trims display append value [{"translate":"Eye","color":"#1F8A46"},{"text":", ","color":"dark_gray"}]
execute if entity @s[advancements={blue:tr/blacklist={rib=true}}] run data modify storage blue:trims display append value [{"translate":"Rib","color":"#E6484B"},{"text":", ","color":"dark_gray"}]
execute if entity @s[advancements={blue:tr/blacklist={vex=true}}] run data modify storage blue:trims display append value [{"translate":"Vex","color":"#CFC6A5"},{"text":", ","color":"dark_gray"}]
data remove storage blue:trims display[-1][-1]
execute if data storage blue:trims display run tellraw @s [{"translate":"blue.tr.blacklisted_trims","fallback":"Your Blacklist","color":"gray"},{"text":": ","color":"dark_gray"},{"storage":"blue:trims","nbt":"display","interpret":true,"separator":""}," ",{"text":"ℹ","color":"gray","hover_event":{"action":"show_text","value":{"translate":"blue.tr.blacklist_hover","fallback":"This list is managed by server operators, per player.","color":"gray"}},"hoverEvent":{"action":"show_text","contents":{"translate":"blue.tr.blacklist_hover","fallback":"This list is managed by server operators, per player.","color":"gray"}}}]
tellraw @s {"text":"-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --","color":"gray"}