function blue:shared/repeat
execute store result storage blue:trims temp.target_id int 1 store result storage blue:trims temp.id int 1 run scoreboard players get @s blue.id
function blue:tr/delayed/cmd/trust/modify with storage blue:trims temp
advancement grant @s only blue:tr/tags trusted_self