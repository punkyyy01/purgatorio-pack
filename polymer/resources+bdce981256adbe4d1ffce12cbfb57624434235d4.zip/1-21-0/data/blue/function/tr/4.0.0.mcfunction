execute as @e[tag=blue.tr.silence.Silent] run data modify entity @s Silent set value 0b
execute as @e[tag=blue.tr.spire.NoGravity] run data modify entity @s NoGravity set value 0b
execute as @e[tag=blue.tr.silence.serene] run data modify entity @s Silent set value 0b
execute as @e[tag=blue.tr.spire.weightless] run data modify entity @s NoGravity set value 0b
execute if score #.tr.objective_type blue.config matches 2 run scoreboard objectives add blue.tr.rtd_time dummy
execute if score #.tr.objective_type blue.config matches 2 run scoreboard objectives add blue.tr.rtd_value dummy
scoreboard objectives remove blue.tr.RTDtime
scoreboard objectives remove blue.tr.RTDval
scoreboard players operation #.tr.wayfinder_task blue.config += #.tr.wayfinder_task blue.config
tag @a remove blue.tr.mats.blaze
tag @a remove blue.tr.mats.eye
tag @a remove blue.tr.mats.heart
tag @a remove blue.tr.mats.naut
tag @a remove blue.tr.mats.powder
tag @a remove blue.tr.mats.shard
tag @a remove blue.tr.mats.shulker
tag @a remove blue.tr.mats.star
tag @a remove blue.tr.mats.wind
scoreboard players remove #.wild.trap_limit blue.config 1
scoreboard players remove #.flow.wind_barrage_duration blue.config 30