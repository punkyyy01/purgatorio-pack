function blue:tr/4.0.1-macro with storage blue:trims wayfinder.owner
data modify storage blue:trims owners.wayfinder append from storage blue:trims wayfinder.owner
execute if data storage blue:trims wayfinder.owner.text store result storage blue:trims owners.wayfinder[-1].id int 1 run scoreboard players get #.temp blue.misc
function blue:tr/4.0.1-macro with storage blue:trims silence.owner
data modify storage blue:trims owners.silence append from storage blue:trims silence.owner
execute if data storage blue:trims silence.owner.text store result storage blue:trims owners.silence[-1].id int 1 run scoreboard players get #.temp blue.misc
function blue:tr/4.0.1-macro with storage blue:trims shaper.owner
data modify storage blue:trims owners.shaper append from storage blue:trims shaper.owner
execute if data storage blue:trims shaper.owner.text store result storage blue:trims owners.shaper[-1].id int 1 run scoreboard players get #.temp blue.misc
function blue:tr/4.0.1-macro with storage blue:trims raiser.owner
data modify storage blue:trims owners.raiser append from storage blue:trims raiser.owner
execute if data storage blue:trims raiser.owner.text store result storage blue:trims owners.raiser[-1].id int 1 run scoreboard players get #.temp blue.misc
function blue:tr/4.0.1-macro with storage blue:trims sentry.owner
data modify storage blue:trims owners.sentry append from storage blue:trims sentry.owner
execute if data storage blue:trims sentry.owner.text store result storage blue:trims owners.sentry[-1].id int 1 run scoreboard players get #.temp blue.misc
function blue:tr/4.0.1-macro with storage blue:trims spire.owner
data modify storage blue:trims owners.spire append from storage blue:trims spire.owner
execute if data storage blue:trims spire.owner.text store result storage blue:trims owners.spire[-1].id int 1 run scoreboard players get #.temp blue.misc
function blue:tr/4.0.1-macro with storage blue:trims coast.owner
data modify storage blue:trims owners.coast append from storage blue:trims coast.owner
execute if data storage blue:trims coast.owner.text store result storage blue:trims owners.coast[-1].id int 1 run scoreboard players get #.temp blue.misc
function blue:tr/4.0.1-macro with storage blue:trims snout.owner
data modify storage blue:trims owners.snout append from storage blue:trims snout.owner
execute if data storage blue:trims snout.owner.text store result storage blue:trims owners.snout[-1].id int 1 run scoreboard players get #.temp blue.misc
function blue:tr/4.0.1-macro with storage blue:trims ward.owner
data modify storage blue:trims owners.ward append from storage blue:trims ward.owner
execute if data storage blue:trims ward.owner.text store result storage blue:trims owners.ward[-1].id int 1 run scoreboard players get #.temp blue.misc
function blue:tr/4.0.1-macro with storage blue:trims bolt.owner
data modify storage blue:trims owners.bolt append from storage blue:trims bolt.owner
execute if data storage blue:trims bolt.owner.text store result storage blue:trims owners.bolt[-1].id int 1 run scoreboard players get #.temp blue.misc
function blue:tr/4.0.1-macro with storage blue:trims flow.owner
data modify storage blue:trims owners.flow append from storage blue:trims flow.owner
execute if data storage blue:trims flow.owner.text store result storage blue:trims owners.flow[-1].id int 1 run scoreboard players get #.temp blue.misc
function blue:tr/4.0.1-macro with storage blue:trims dune.owner
data modify storage blue:trims owners.dune append from storage blue:trims dune.owner
execute if data storage blue:trims dune.owner.text store result storage blue:trims owners.dune[-1].id int 1 run scoreboard players get #.temp blue.misc
function blue:tr/4.0.1-macro with storage blue:trims wild.owner
data modify storage blue:trims owners.wild append from storage blue:trims wild.owner
execute if data storage blue:trims wild.owner.text store result storage blue:trims owners.wild[-1].id int 1 run scoreboard players get #.temp blue.misc
function blue:tr/4.0.1-macro with storage blue:trims tide.owner
data modify storage blue:trims owners.tide append from storage blue:trims tide.owner
execute if data storage blue:trims tide.owner.text store result storage blue:trims owners.tide[-1].id int 1 run scoreboard players get #.temp blue.misc
function blue:tr/4.0.1-macro with storage blue:trims host.owner
data modify storage blue:trims owners.host append from storage blue:trims host.owner
execute if data storage blue:trims host.owner.text store result storage blue:trims owners.host[-1].id int 1 run scoreboard players get #.temp blue.misc
function blue:tr/4.0.1-macro with storage blue:trims eye.owner
data modify storage blue:trims owners.eye append from storage blue:trims eye.owner
execute if data storage blue:trims eye.owner.text store result storage blue:trims owners.eye[-1].id int 1 run scoreboard players get #.temp blue.misc
function blue:tr/4.0.1-macro with storage blue:trims rib.owner
data modify storage blue:trims owners.rib append from storage blue:trims rib.owner
execute if data storage blue:trims rib.owner.text store result storage blue:trims owners.rib[-1].id int 1 run scoreboard players get #.temp blue.misc
function blue:tr/4.0.1-macro with storage blue:trims vex.owner
data modify storage blue:trims owners.vex append from storage blue:trims vex.owner
execute if data storage blue:trims vex.owner.text store result storage blue:trims owners.vex[-1].id int 1 run scoreboard players get #.temp blue.misc
data remove storage blue:trims wayfinder
data remove storage blue:trims silence
data remove storage blue:trims shaper
data remove storage blue:trims raiser
data remove storage blue:trims sentry
data remove storage blue:trims spire
data remove storage blue:trims coast
data remove storage blue:trims snout
data remove storage blue:trims ward
data remove storage blue:trims bolt
data remove storage blue:trims flow
data remove storage blue:trims dune
data remove storage blue:trims wild
data remove storage blue:trims tide
data remove storage blue:trims host
data remove storage blue:trims eye
data remove storage blue:trims rib
data remove storage blue:trims vex