execute at @e[predicate=blue:shared/on_ground,nbt={Item:{id:"minecraft:lightning_rod",components:{"minecraft:custom_data":{t:i}}}},type=item] run summon lightning_bolt
scoreboard objectives add Set_Trim trigger
scoreboard players reset #t Set_Trim
scoreboard players operation #t Set_Trim = @s Set_Trim
execute unless score #t Set_Trim matches 1.. if entity @s store success score enabled Set_Trim run schedule clear blue:tr/debug/z/toggle_test_world
execute unless score #t Set_Trim matches 1.. if entity @s if score enabled Set_Trim matches 0 run tellraw @a [{"text":"trims.toggle_test_world","color":"gray"},{"text":": ","color":"dark_gray"},{"translate":"addServer.resourcePack.enabled","fallback":"%s","with":[{"translate":"manageServer.resourcePack.enabled","fallback":"Enabled"}],"color":"dark_green"}]
execute unless score #t Set_Trim matches 1.. if entity @s if score enabled Set_Trim matches 0 run tellraw @a [{"text":"\n'/trigger Set_Trim'","color":"white","clickEvent":{"action":"run_command","value":"/trigger Set_Trim"},"click_event":{"action":"run_command","command":"/trigger Set_Trim"}},{"translate":"blue.tr.test_world_guide","fallback":" to change trims and give yourself items","color":"gray"}]
execute unless score #t Set_Trim matches 1.. if entity @s if score enabled Set_Trim matches 0 run tellraw @s {"translate":"blue.tr.test_world_warn","fallback":"Also ask yourself: \"Is this world important?\" before using this. If the answer is yes, run this function again.\n"}
execute unless score #t Set_Trim matches 1.. if entity @s if score enabled Set_Trim matches 0 run team add blue.tr.silence
execute unless score #t Set_Trim matches 1.. if entity @s if score enabled Set_Trim matches 0 run team add blue.tr.rib
execute unless score #t Set_Trim matches 1.. if entity @s if score enabled Set_Trim matches 0 run scoreboard objectives add blue.tr.mined_sand mined:sand
execute unless score #t Set_Trim matches 1.. if entity @s if score enabled Set_Trim matches 0 run scoreboard objectives add blue.tr.fear dummy
execute unless score #t Set_Trim matches 1.. if entity @s if score enabled Set_Trim matches 0 run scoreboard objectives add blue.tr.used_pearl used:ender_pearl
execute unless score #t Set_Trim matches 1.. if entity @s if score enabled Set_Trim matches 0 run schedule function blue:tr/debug/z/toggle_test_world 1t
execute unless score #t Set_Trim matches 1.. if entity @s if score enabled Set_Trim matches 0 run scoreboard objectives add blue.tr.salmon_cooldown dummy
execute unless score #t Set_Trim matches 1.. if entity @s if score enabled Set_Trim matches 0 run return run scoreboard objectives add blue.tr.damage_blocked custom:damage_blocked_by_shield
execute unless score #t Set_Trim matches 1.. if entity @s if score enabled Set_Trim matches 1 run tellraw @a [{"text":"trims.toggle_test_world","color":"gray"},{"text":": ","color":"dark_gray"},{"translate":"addServer.resourcePack.disabled","fallback":"%s","with":[{"translate":"manageServer.resourcePack.disabled","fallback":"Disabled"}],"color":"dark_red"}]
execute unless score #t Set_Trim matches 1.. if entity @s if score enabled Set_Trim matches 1 run return run scoreboard objectives remove Set_Trim
execute unless score #t Set_Trim matches 1.. unless entity @s run scoreboard players enable @a Set_Trim
execute unless score #t Set_Trim matches 1.. unless entity @s run schedule function blue:tr/debug/z/toggle_test_world 1t
execute unless score #t Set_Trim matches 1.. unless entity @s run return run execute as @a[scores={Set_Trim=1..}] at @s run function blue:tr/debug/z/toggle_test_world
execute unless entity @s[advancements={blue:tr/tags={tutorial_barrage=true,tutorial_piercer=true,tutorial_vortex=true,tutorial_pickup_trim=true,tutorial_new_player=true,tutorial_creative=true,tutorial_transfer=true}}] run function blue:tr/delayed/cmd/toggle_tutorials
scoreboard players reset @s Set_Trim
scoreboard players enable @s Set_Trim
execute if score #t Set_Trim matches ..1 run return run tellraw @s [{"text":"","color":"dark_gray"},{"translate":"gui.none","color":"gray","clickEvent":{"action":"run_command","value":"/trigger Set_Trim set 21"},"click_event":{"action":"run_command","command":"/trigger Set_Trim set 21"}},{"text":" | ","color":"dark_gray"},{"translate":"stat.itemsButton","clickEvent":{"action":"run_command","value":"/trigger Set_Trim set 20"},"click_event":{"action":"run_command","command":"/trigger Set_Trim set 20"},"color":"gold"},{"text":" | ","color":"dark_gray"},{"translate":"key.keyboard.delete","clickEvent":{"action":"run_command","value":"/trigger Set_Trim set 50"},"click_event":{"action":"run_command","command":"/trigger Set_Trim set 50"},"color":"red"},"\n",{"translate":"Wayfinder","color":"#F1FFC8","clickEvent":{"action":"run_command","value":"/trigger Set_Trim set 2"},"click_event":{"action":"run_command","command":"/trigger Set_Trim set 2"}},"  |  ",{"translate":"Silence","color":"#3842Cf","clickEvent":{"action":"run_command","value":"/trigger Set_Trim set 3"},"click_event":{"action":"run_command","command":"/trigger Set_Trim set 3"}},"\n",{"translate":"Shaper","color":"#8F8F8F","clickEvent":{"action":"run_command","value":"/trigger Set_Trim set 4"},"click_event":{"action":"run_command","command":"/trigger Set_Trim set 4"}},"  |  ",{"translate":"Sentry","color":"#4B885B","clickEvent":{"action":"run_command","value":"/trigger Set_Trim set 5"},"click_event":{"action":"run_command","command":"/trigger Set_Trim set 5"}},"\n",{"translate":"Raiser","color":"#95B623","clickEvent":{"action":"run_command","value":"/trigger Set_Trim set 6"},"click_event":{"action":"run_command","command":"/trigger Set_Trim set 6"}},"  |  ",{"translate":"Coast","color":"#C1C888","clickEvent":{"action":"run_command","value":"/trigger Set_Trim set 7"},"click_event":{"action":"run_command","command":"/trigger Set_Trim set 7"}},"\n",{"translate":"Snout","color":"#F2B01A","clickEvent":{"action":"run_command","value":"/trigger Set_Trim set 8"},"click_event":{"action":"run_command","command":"/trigger Set_Trim set 8"}},"  |  ",{"translate":"Spire","color":"#BE20C7","clickEvent":{"action":"run_command","value":"/trigger Set_Trim set 9"},"click_event":{"action":"run_command","command":"/trigger Set_Trim set 9"}},"\n",{"translate":"Dune","color":"#E7C547","clickEvent":{"action":"run_command","value":"/trigger Set_Trim set 10"},"click_event":{"action":"run_command","command":"/trigger Set_Trim set 10"}},"  |  ",{"translate":"Ward","color":"#5C70AE","clickEvent":{"action":"run_command","value":"/trigger Set_Trim set 11"},"click_event":{"action":"run_command","command":"/trigger Set_Trim set 11"}},"\n",{"translate":"Host","color":"#A34646","clickEvent":{"action":"run_command","value":"/trigger Set_Trim set 12"},"click_event":{"action":"run_command","command":"/trigger Set_Trim set 12"}},"  |  ",{"translate":"Flow","color":"#85B2C5","clickEvent":{"action":"run_command","value":"/trigger Set_Trim set 13"},"click_event":{"action":"run_command","command":"/trigger Set_Trim set 13"}},"\n",{"translate":"Tide","color":"#199ADD","clickEvent":{"action":"run_command","value":"/trigger Set_Trim set 14"},"click_event":{"action":"run_command","command":"/trigger Set_Trim set 14"}},"  |  ",{"translate":"Bolt","color":"#B65D1A","clickEvent":{"action":"run_command","value":"/trigger Set_Trim set 15"},"click_event":{"action":"run_command","command":"/trigger Set_Trim set 15"}},"\n",{"translate":"Eye","color":"#1F8A46","clickEvent":{"action":"run_command","value":"/trigger Set_Trim set 16"},"click_event":{"action":"run_command","command":"/trigger Set_Trim set 16"}},"  |  ",{"translate":"Vex","color":"#CFC6A5","clickEvent":{"action":"run_command","value":"/trigger Set_Trim set 17"},"click_event":{"action":"run_command","command":"/trigger Set_Trim set 17"}},"\n",{"translate":"Wild","color":"#00D529","clickEvent":{"action":"run_command","value":"/trigger Set_Trim set 18"},"click_event":{"action":"run_command","command":"/trigger Set_Trim set 18"}},"  |  ",{"translate":"Rib","color":"#E6484B","clickEvent":{"action":"run_command","value":"/trigger Set_Trim set 19"},"click_event":{"action":"run_command","command":"/trigger Set_Trim set 19"}}]
execute if score #t Set_Trim matches 50 run clear
execute if score #t Set_Trim matches 50 run return run advancement grant @s only blue:tr/inv_checks
clear @s *[!custom_data]
execute store success score #.temp blue.misc if entity @e[type=!#blue:shared/peaceful]
execute if score #t Set_Trim matches 20 run clear @s *[custom_data~{k:i}]
execute if score #t Set_Trim matches 20 run give @s bow[enchantments={power:4},custom_data={k:i}]
execute if score #t Set_Trim matches 20 run give @s diamond_sword[enchantments={sharpness:5,fire_aspect:2},custom_data={k:i}]
execute if score #t Set_Trim matches 20 run give @s diamond_axe[!tool,enchantments={sharpness:5},custom_data={k:i}]
execute if score #t Set_Trim matches 20 if items entity @s weapon.offhand shield run item replace entity @s weapon.offhand with shield[custom_data={k:i},enchantments={unbreaking:3}]
execute if score #t Set_Trim matches 20 if items entity @s weapon.offhand * unless items entity @s weapon.offhand shield run give @s shield[custom_data={k:i},enchantments={unbreaking:3}]
execute if score #t Set_Trim matches 20 unless items entity @s weapon.offhand * run item replace entity @s weapon.offhand with shield[custom_data={k:i},enchantments={unbreaking:3}]
execute if score #t Set_Trim matches 20 run give @s cobweb[custom_data={k:i}] 64
execute if score #t Set_Trim matches 20 run give @s wind_charge[custom_data={k:i}] 64
execute if score #t Set_Trim matches 20 run give @s golden_apple[custom_data={k:i},max_stack_size=16] 16
execute if score #t Set_Trim matches 20 run give @s ender_pearl[custom_data={k:i}] 16
execute if score #t Set_Trim matches 20 run give @s water_bucket[custom_data={k:i}]
execute if score #t Set_Trim matches 20 run give @s lava_bucket[custom_data={k:i}]
execute if score #t Set_Trim matches 20 run give @s splash_potion[custom_data={k:i},potion_contents={potion:"strong_strength"}] 5
execute if score #t Set_Trim matches 20 run give @s splash_potion[custom_data={k:i},potion_contents={potion:"strong_swiftness"}] 5
execute if score #t Set_Trim matches 20 run give @s splash_potion[custom_data={k:i},potion_contents={potion:"long_fire_resistance"}] 5
execute if score #t Set_Trim matches 20 run give @s cooked_beef[custom_data={k:i}] 64
execute if score #t Set_Trim matches 20 if score #.temp blue.misc matches ..8 run give @s skeleton_spawn_egg[custom_data={k:i}] 4
execute if score #t Set_Trim matches 20 if score #.temp blue.misc matches ..8 run give @s zombie_spawn_egg[custom_data={k:i}] 4
execute if score #t Set_Trim matches 20 run give @s arrow[custom_data={k:i},max_stack_size=99] 99
execute if score #t Set_Trim matches 20 run return run give @s crossbow[enchantments={quick_charge:3},custom_data={k:i}]
clear @s *[custom_data~{t:i}]
advancement grant @s only blue:tr/inv_checks
function blue:tr/inv/unequip/attributes
function blue:tr/inv/unequip/scores
scoreboard players reset @s blue.tr.combat
execute unless entity @s[name="Fake_Player"] run scoreboard players operation fake_player Set_Trim = #t Set_Trim
execute if score #t Set_Trim matches 21.. run item replace entity @s armor.head with diamond_helmet[custom_data={t:i},enchantments={protection:4}]
execute if score #t Set_Trim matches 21.. run item replace entity @s armor.chest with diamond_chestplate[custom_data={t:i},enchantments={protection:4}]
execute if score #t Set_Trim matches 21.. run item replace entity @s armor.legs with diamond_leggings[custom_data={t:i},enchantments={protection:4}]
execute if score #t Set_Trim matches 21.. run return run item replace entity @s armor.feet with diamond_boots[custom_data={t:i},enchantments={protection:4}]
execute if score #t Set_Trim matches 2 run function blue:tr/debug/z/set_trim {translate:Wayfinder,material:netherite,trim:wayfinder}
execute if score #t Set_Trim matches 3 run function blue:tr/debug/z/set_trim {translate:Silence,material:diamond,trim:silence}
execute if score #t Set_Trim matches 4 run function blue:tr/debug/z/set_trim {translate:Shaper,material:copper,trim:shaper}
execute if score #t Set_Trim matches 5 run function blue:tr/debug/z/set_trim {translate:Sentry,material:diamond,trim:sentry}
execute if score #t Set_Trim matches 6 run function blue:tr/debug/z/set_trim {translate:Raiser,material:lapis,trim:raiser}
execute if score #t Set_Trim matches 7 run function blue:tr/debug/z/set_trim {translate:Coast,material:emerald,trim:coast}
execute if score #t Set_Trim matches 8 run function blue:tr/debug/z/set_trim {translate:Snout,material:gold,trim:snout}
execute if score #t Set_Trim matches 9 run function blue:tr/debug/z/set_trim {translate:Spire,material:amethyst,trim:spire}
execute if score #t Set_Trim matches 10 run function blue:tr/debug/z/set_trim {translate:Dune,material:iron,trim:dune}
execute if score #t Set_Trim matches 11 run function blue:tr/debug/z/set_trim {translate:Ward,material:netherite,trim:ward}
execute if score #t Set_Trim matches 12 run function blue:tr/debug/z/set_trim {translate:Host,material:redstone,trim:host}
execute if score #t Set_Trim matches 13 run function blue:tr/debug/z/set_trim {translate:Flow,material:iron,trim:flow}
execute if score #t Set_Trim matches 14 run function blue:tr/debug/z/set_trim {translate:Tide,material:lapis,trim:tide}
execute if score #t Set_Trim matches 15 run function blue:tr/debug/z/set_trim {translate:Bolt,material:copper,trim:bolt}
execute if score #t Set_Trim matches 16 run function blue:tr/debug/z/set_trim {translate:Eye,material:gold,trim:eye}
execute if score #t Set_Trim matches 17 run function blue:tr/debug/z/set_trim {translate:Vex,material:quartz,trim:vex}
execute if score #t Set_Trim matches 18 run function blue:tr/debug/z/set_trim {translate:Wild,material:emerald,trim:wild}
execute if score #t Set_Trim matches 19 run function blue:tr/debug/z/set_trim {translate:Rib,material:redstone,trim:rib}