$execute unless score .bypass_revoke blue.config matches 1 unless data storage blue:trims owners.$(trim) run return run tellraw @s {"translate":"argument.time.invalid_unit","color":"red","extra":[{"text":": $(trim)"}]}
$execute unless score .bypass_revoke blue.config matches 1 unless score $(name) blue.id matches 0.. run return run tellraw @s {"translate":"argument.time.invalid_unit","color":"red","extra":[{"text":": $(name)"}]}
$execute as $(name) run return run function blue:tr/debug/revoke/$(trim)
scoreboard objectives add blue.tr.debug.offline_revoke dummy
$execute store result storage blue:trims temp.int int 1 run scoreboard players get $(name) blue.id
$data modify storage blue:trims temp.list set from storage blue:trims owners.$(trim)
function blue:tr/debug/revoke/z/remove with storage blue:trims temp
$data modify storage blue:trims owners.$(trim) set from storage blue:trims temp.list
$execute if data storage blue:trims temp.list[{"translate":"gui.none"}] run scoreboard players set #.tr.$(trim)_completed blue.config 0
$execute if data storage blue:trims temp.list[{"translate":"gui.none"}] run advancement revoke @a only blue:tr/display/$(trim)
$data modify storage blue:trims logs.append.trim set from storage blue:trims translations[{"trim":"$(trim)"}]
data remove storage blue:trims logs.append.trim.trim
data remove storage blue:trims logs.append.trim.value
$tellraw @a [{"text":"- ","color":"dark_gray"},{"translate":"blue.tr.lost_trim","fallback":"%s has lost their ownership over %s","color":"gray","with":[{"text":"$(name)"},{"storage":"blue:trims","nbt":"logs.append.trim","interpret":true}]}]
function blue:shared/get_name
data modify storage blue:trims logs.append.by set from storage blue:shared player_name
$data modify storage blue:trims logs.append.user set value "$(name)"
data modify storage blue:trims logs.completion append from storage blue:trims logs.append
data remove storage blue:trims logs.append.by
$execute store success score $(name) blue.tr.debug.offline_revoke run data modify storage blue:trims temp.trim set value "$(trim)"
function blue:tr/debug/revoke/z/modify_revoke with storage blue:trims temp
$execute if score .temp blue.tr.debug.offline_revoke matches 1 run tellraw @s {"translate":"blue.tr.offline_revoke.true","fallback":"%s will lose %s whenever they rejoin","color":"dark_red","with":[{"text":"$(name)","color":"red"},{"text":"$(trim)","color":"red"}]}
$execute if score .temp blue.tr.debug.offline_revoke matches 0 run tellraw @s {"translate":"blue.tr.offline_revoke.false","fallback":"%s will NOT lose %s whenever they rejoin","color":"dark_green","with":[{"text":"$(name)","color":"green"},{"text":"$(trim)","color":"green"}]}