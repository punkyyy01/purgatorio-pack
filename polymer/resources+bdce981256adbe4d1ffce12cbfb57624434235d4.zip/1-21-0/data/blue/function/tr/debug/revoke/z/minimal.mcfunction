$execute at @s[tag=blue.tr.trim.$(trim)] run function blue:tr/inv/untrim/direct
$execute at @s as @e[type=item,distance=..4] if items entity @s contents $(trim)_armor_trim_smithing_template run kill
$clear @s $(trim)_armor_trim_smithing_template
$tag @s remove blue.tr.$(trim)
$execute unless items entity @s enderchest.* *[trim~{pattern:$(trim)}] unless items entity @s enderchest.* $(trim)_armor_trim_smithing_template run return fail
$function blue:tr/debug/revoke/z/enderchest {trim:"$(trim)"}