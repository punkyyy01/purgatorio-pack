$item replace entity @s armor.head with diamond_helmet[custom_data={t:i},trim={material:"minecraft:$(material)",pattern:"minecraft:$(trim)"},enchantments={protection:4}]
$item replace entity @s armor.chest with diamond_chestplate[custom_data={t:i},trim={material:"minecraft:$(material)",pattern:"minecraft:$(trim)"},enchantments={protection:4}]
$item replace entity @s armor.legs with diamond_leggings[custom_data={t:i},trim={material:"minecraft:$(material)",pattern:"minecraft:$(trim)"},enchantments={protection:4}]
$item replace entity @s armor.feet with diamond_boots[custom_data={t:i},trim={material:"minecraft:$(material)",pattern:"minecraft:$(trim)"},enchantments={protection:4}]
scoreboard players set @s[tag=b.tr.send_msg] Trims_Menu.BLUE 51
execute if score #t Set_Trim matches 2 run give @s compass[custom_data={t:i}]
execute if score #t Set_Trim matches 2 run give @s lodestone[custom_data={t:i}]
execute if score #t Set_Trim matches 2 run give @s filled_map[custom_data={t:i}]
execute if score #t Set_Trim matches 2 run give @s fishing_rod[custom_data={t:i}]
execute if score #t Set_Trim matches 3 run give @s echo_shard[custom_data={t:i}] 64
execute if score #t Set_Trim matches 4 run give @s diamond_pickaxe
execute if score #t Set_Trim matches 4 run give @s tnt[custom_data={t:i}] 9
execute if score #t Set_Trim matches 5 unless items entity @s container.* crossbow unless items entity @s weapon.offhand crossbow run give @s crossbow[enchantments={quick_charge:3},custom_data={t:i,k:i}]
execute if score #t Set_Trim matches 5 run give @s arrow 16
execute if score #t Set_Trim matches 5 run effect give @s hero_of_the_village 240 4 true
execute if score #t Set_Trim matches 6 run give @s experience_bottle[custom_data={t:i}] 16
execute if score #t Set_Trim matches 7 run give @s trident[enchantments={loyalty:3},custom_data={t:i}]
execute if score #t Set_Trim matches 7 run give @s cod[custom_data={t:i}] 34
execute if score #t Set_Trim matches 7 run give @s pufferfish[custom_data={t:i}] 28
execute if score #t Set_Trim matches 7 run give @s salmon[custom_data={t:i}] 22
execute if score #t Set_Trim matches 7 run give @s tropical_fish[custom_data={t:i}] 16
execute if score #t Set_Trim matches 8 run give @s gold_nugget[custom_data={t:i}] 32
execute if score #t Set_Trim matches 8 run give @s gold_ingot[custom_data={t:i}] 26
execute if score #t Set_Trim matches 8 run give @s gold_block[custom_data={t:i}] 20
execute if score #t Set_Trim matches 9 run give @s dragon_breath[custom_data={t:i}] 8
execute if score #t Set_Trim matches 10 run give @s sand[custom_data={t:i}] 64
execute if score #t Set_Trim matches 11 unless items entity @s container.* shield unless items entity @s weapon.offhand shield run give @s shield[custom_data={t:i,k:i}]
execute if score #t Set_Trim matches 12 run give @s iron_golem_spawn_egg[custom_data={t:i}]
execute if score #t Set_Trim matches 13 run give @s wind_charge 64
execute if score #t Set_Trim matches 13 run give @s mace[enchantments={wind_burst:2,density:1},custom_data={t:i}]
execute if score #t Set_Trim matches 14 run give @s trident[enchantments={loyalty:3},custom_data={t:i}]
execute if score #t Set_Trim matches 14 run give @s trident[enchantments={riptide:3},custom_data={t:i}]
execute if score #t Set_Trim matches 15 run give @s lightning_rod[item_name='"Drop to spawn lightning"',lore=['"Test-mode exclusive"'],custom_data={t:i}]
execute if score #t Set_Trim matches 15 run give @s oxidized_copper[custom_data={t:i}] 32
execute if score #t Set_Trim matches 15 run give @s copper_block[custom_data={t:i}] 32
execute if score #t Set_Trim matches 16 unless items entity @s container.* ender_pearl run give @s ender_pearl[custom_data={t:i}] 4
execute if score #t Set_Trim matches 16 run give @s ender_eye[custom_data={t:i}]
execute if score #t Set_Trim matches 16 run give @s spyglass[custom_data={t:i}]
execute if score #t Set_Trim matches 17 unless items entity @s container.* #axes run give @s diamond_axe[custom_data={t:i}]
execute if score #t Set_Trim matches 18 run give @s cornflower[custom_data={t:i}] 16