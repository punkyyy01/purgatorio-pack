$data modify storage blue:trims logs.append.trim set value $(log)
tellraw @a [{"text":"- ","color":"dark_gray"},{"translate":"blue.tr.lost_trim","fallback":"%s has lost their ownership over %s","color":"gray","with":[{"selector":"@s"},{"storage":"blue:trims","nbt":"logs.append.trim","interpret":true}]}]
playsound block.beacon.deactivate player @a 0 0 0 0 1.75 1
execute as @p run function blue:shared/get_name
data modify storage blue:trims logs.append.by set from storage blue:shared player_name
function blue:shared/get_name
data modify storage blue:trims logs.completion append from storage blue:trims logs.append
data remove storage blue:trims logs.append.by
$data modify storage blue:trims temp.list set from storage blue:trims owners.$(trim)
function blue:tr/debug/revoke/z/start_remove
$data modify storage blue:trims owners.$(trim) set from storage blue:trims temp.list
$execute if data storage blue:trims temp.list[{"translate":"gui.none"}] run scoreboard players set #.tr.$(trim)_completed blue.config 0
$execute if data storage blue:trims temp.list[{"translate":"gui.none"}] run advancement revoke @a only blue:tr/display/$(trim)
$execute at @s[tag=blue.tr.trim.$(trim)] run function blue:tr/inv/untrim/direct
$execute at @s as @e[type=item,distance=..4] if items entity @s contents $(trim)_armor_trim_smithing_template run kill
$clear @s $(trim)_armor_trim_smithing_template
$tag @s remove blue.tr.$(trim)
$execute unless items entity @s enderchest.* *[trim~{pattern:$(trim)}] unless items entity @s enderchest.* $(trim)_armor_trim_smithing_template run return fail
$function blue:tr/debug/revoke/z/enderchest {trim:"$(trim)"}