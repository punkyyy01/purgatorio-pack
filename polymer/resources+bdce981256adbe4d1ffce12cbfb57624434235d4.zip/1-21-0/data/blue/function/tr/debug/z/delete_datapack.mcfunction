execute unless entity @s[tag=blue.tr.delete_confirmation] run return run tellraw @s {"translate":"blue.tr.no_delete_confirmation","fallback":"You don't have deletion confirmation, please run the remove_trims_overhaul debug function first.","color":"gray"}
tag @s remove blue.tr.delete_confirmation
scoreboard players set #.tr.manual_untrimming blue.config 1
scoreboard players set #.tr.template_clearing blue.config 0
execute as @a run function blue:tr/inv/untrim/main
data remove storage blue:trims inventory
advancement grant @a only blue:tr/inv_checks
data remove storage blue:trims owners
data remove storage blue:trims logs
data remove storage blue:trims temp
execute as @a run function blue:tr/inv/unequip/attributes
function blue:tr/settings/set_default
scoreboard players reset #.tr.wayfinder_completed blue.config
scoreboard players reset #.tr.silence_completed blue.config
scoreboard players reset #.tr.raiser_completed blue.config
scoreboard players reset #.tr.shaper_completed blue.config
scoreboard players reset #.tr.sentry_completed blue.config
scoreboard players reset #.tr.spire_completed blue.config
scoreboard players reset #.tr.coast_completed blue.config
scoreboard players reset #.tr.snout_completed blue.config
scoreboard players reset #.tr.ward_completed blue.config
scoreboard players reset #.tr.bolt_completed blue.config
scoreboard players reset #.tr.flow_completed blue.config
scoreboard players reset #.tr.dune_completed blue.config
scoreboard players reset #.tr.wild_completed blue.config
scoreboard players reset #.tr.tide_completed blue.config
scoreboard players reset #.tr.host_completed blue.config
scoreboard players reset #.tr.eye_completed blue.config
scoreboard players reset #.tr.rib_completed blue.config
scoreboard players reset #.tr.vex_completed blue.config
scoreboard players reset #.Trims_Overhaul blue.misc
scoreboard objectives remove blue.tr.primary_data
scoreboard objectives remove blue.tr.primary_cooldown
scoreboard objectives remove blue.tr.secondary_data
scoreboard objectives remove blue.tr.secondary_cooldown
scoreboard objectives remove blue.tr.third_data
scoreboard objectives remove blue.tr.fourth_data
scoreboard objectives remove blue.tr.ambient
scoreboard objectives remove blue.tr.schedule_context
scoreboard objectives remove blue.tr.swim
scoreboard objectives remove blue.tr.blocks_swam
scoreboard objectives remove blue.tr.walk
scoreboard objectives remove blue.tr.blocks_walked
scoreboard objectives remove blue.tr.desert_time
scoreboard objectives remove blue.tr.dragons_killed
scoreboard objectives remove blue.tr.animals_tamed
scoreboard objectives remove blue.tr.animals_bred
scoreboard objectives remove blue.tr.ominous_vault
scoreboard objectives remove blue.tr.plain_vault
scoreboard objectives remove blue.tr.piglin_trades
scoreboard objectives remove blue.tr.pre_barter
scoreboard objectives remove blue.tr.mobs_killed
scoreboard objectives remove blue.tr.silverfish_killed
scoreboard objectives remove blue.tr.explosions_survived
scoreboard objectives remove blue.tr.villagers_cured
scoreboard objectives remove blue.tr.damage_blocked
scoreboard objectives remove blue.tr.items_fished
scoreboard objectives remove blue.tr.items_enchanted
scoreboard objectives remove blue.tr.raids_won
scoreboard objectives remove blue.tr.lava_seconds
scoreboard objectives remove blue.tr.rtd_time
scoreboard objectives remove blue.tr.rtd_value
scoreboard objectives remove RTD.BLUE
scoreboard objectives remove blue.tr.structures
scoreboard objectives remove blue.tr.current_trim
scoreboard objectives remove blue.tr.fear
scoreboard objectives remove blue.tr.combat
scoreboard objectives remove blue.tr.died
scoreboard objectives remove blue.tr.transfer
scoreboard objectives remove Trims_Menu.BLUE
scoreboard objectives remove blue.tr.mined_sand
scoreboard objectives remove blue.tr.used_pearl
scoreboard objectives remove blue.tr.salmon_cooldown
team remove blue.tr.rib
team remove blue.tr.silence
tag @a remove blue.tr.wayfinder
tag @a remove blue.tr.silence
tag @a remove blue.tr.shaper
tag @a remove blue.tr.sentry
tag @a remove blue.tr.raiser
tag @a remove blue.tr.coast
tag @a remove blue.tr.snout
tag @a remove blue.tr.spire
tag @a remove blue.tr.dune
tag @a remove blue.tr.ward
tag @a remove blue.tr.host
tag @a remove blue.tr.flow
tag @a remove blue.tr.tide
tag @a remove blue.tr.bolt
tag @a remove blue.tr.eye
tag @a remove blue.tr.vex
tag @a remove blue.tr.wild
tag @a remove blue.tr.rib
tag @e remove blue.tr.armor
tag @e remove blue.tr.checked
tag @e remove blue.tr.return
tag @a remove blue.tr.coast.propel
kill @e[tag=blue.tr.wild.trap]
kill b163102f-0-0-0-1
tellraw @a {"translate":"blue.tr.delete_success","fallback":"\nYou have disabled ActuallyBlue's %s datapack, and it has removed most of its data from your world.\n\n - Please confirm the datapack is disabled by confirming it doesn't appear in %s\n - If you wish to re-enable the datapack, just run: %s\n\n   (the `trims...` is a placeholder. Fill in whatever looks correct)","color":"gray","with":[{"translate":"blue.tr.trims_overhaul","fallback":"Trims Overhaul","color":"#3aa56a"},{"text":"/datapack disable \"file/trims...\"","color":"white"},{"text":"/datapack enable \"file/trims...\"","color":"white"}]}
playsound block.bell.use master @a 0 -128 0 0 0.75 1
datapack disable "file/CUSTOM_trims_overhaul-MOD-v4.0.1.jar"
datapack disable "file/CUSTOM_trims_overhaul-DP_RP-v4.0.1.zip"
datapack disable "file/CUSTOM_trims_overhaul-DP-v4.0.1"
datapack disable "file/trims_overhaul-MOD-v4.0.1.jar"
datapack disable "file/trims_overhaul-DP_RP-v4.0.1.zip"
datapack disable "file/trims_overhaul-DP_RP-v4.0.1"
datapack disable "file/trims_overhaul-MOD-v4.0.1.jar"
datapack disable "file/trims_overhaul-DP_RP-v4.0.1.zip"
datapack disable "file/trims_overhaul-DP_RP-v4.0.1"
datapack disable "file/trims_overhaul-dp-rp-v4.0.1.zip"
datapack disable "file/trims_overhaul-dp-rp-v4.0.1"