execute store result storage blue:trims temp.int int 1 run scoreboard players get @s blue.id
function blue:tr/debug/revoke/z/remove with storage blue:trims temp