$data modify storage blue:trims offline_revoke.temp set from storage blue:trims offline_revoke.$(id)
execute if data storage blue:trims offline_revoke.temp{wayfinder:1b} run function blue:tr/debug/revoke/z/minimal {trim:"wayfinder"}
execute if data storage blue:trims offline_revoke.temp{silence:1b} run function blue:tr/debug/revoke/z/minimal {trim:"silence"}
execute if data storage blue:trims offline_revoke.temp{shaper:1b} run function blue:tr/debug/revoke/z/minimal {trim:"shaper"}
execute if data storage blue:trims offline_revoke.temp{raiser:1b} run function blue:tr/debug/revoke/z/minimal {trim:"raiser"}
execute if data storage blue:trims offline_revoke.temp{sentry:1b} run function blue:tr/debug/revoke/z/minimal {trim:"sentry"}
execute if data storage blue:trims offline_revoke.temp{spire:1b} run function blue:tr/debug/revoke/z/minimal {trim:"spire"}
execute if data storage blue:trims offline_revoke.temp{coast:1b} run function blue:tr/debug/revoke/z/minimal {trim:"coast"}
execute if data storage blue:trims offline_revoke.temp{snout:1b} run function blue:tr/debug/revoke/z/minimal {trim:"snout"}
execute if data storage blue:trims offline_revoke.temp{ward:1b} run function blue:tr/debug/revoke/z/minimal {trim:"ward"}
execute if data storage blue:trims offline_revoke.temp{bolt:1b} run function blue:tr/debug/revoke/z/minimal {trim:"bolt"}
execute if data storage blue:trims offline_revoke.temp{flow:1b} run function blue:tr/debug/revoke/z/minimal {trim:"flow"}
execute if data storage blue:trims offline_revoke.temp{dune:1b} run function blue:tr/debug/revoke/z/minimal {trim:"dune"}
execute if data storage blue:trims offline_revoke.temp{wild:1b} run function blue:tr/debug/revoke/z/minimal {trim:"wild"}
execute if data storage blue:trims offline_revoke.temp{tide:1b} run function blue:tr/debug/revoke/z/minimal {trim:"tide"}
execute if data storage blue:trims offline_revoke.temp{host:1b} run function blue:tr/debug/revoke/z/minimal {trim:"host"}
execute if data storage blue:trims offline_revoke.temp{eye:1b} run function blue:tr/debug/revoke/z/minimal {trim:"eye"}
execute if data storage blue:trims offline_revoke.temp{rib:1b} run function blue:tr/debug/revoke/z/minimal {trim:"rib"}
execute if data storage blue:trims offline_revoke.temp{vex:1b} run function blue:tr/debug/revoke/z/minimal {trim:"vex"}
scoreboard players reset @s blue.tr.debug.offline_revoke
$data remove storage blue:trims offline_revoke.$(id)