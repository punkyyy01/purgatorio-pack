$execute if items entity @s enderchest.0 $(trim)_armor_trim_smithing_template run item replace entity @s enderchest.0 with air
$execute if items entity @s enderchest.0 #trimmable_armor[trim~{pattern:$(trim)}] run item modify entity @s enderchest.0 blue:shared/remove_trim
$execute if items entity @s enderchest.1 $(trim)_armor_trim_smithing_template run item replace entity @s enderchest.1 with air
$execute if items entity @s enderchest.1 #trimmable_armor[trim~{pattern:$(trim)}] run item modify entity @s enderchest.1 blue:shared/remove_trim
$execute if items entity @s enderchest.2 $(trim)_armor_trim_smithing_template run item replace entity @s enderchest.2 with air
$execute if items entity @s enderchest.2 #trimmable_armor[trim~{pattern:$(trim)}] run item modify entity @s enderchest.2 blue:shared/remove_trim
$execute if items entity @s enderchest.3 $(trim)_armor_trim_smithing_template run item replace entity @s enderchest.3 with air
$execute if items entity @s enderchest.3 #trimmable_armor[trim~{pattern:$(trim)}] run item modify entity @s enderchest.3 blue:shared/remove_trim
$execute if items entity @s enderchest.4 $(trim)_armor_trim_smithing_template run item replace entity @s enderchest.4 with air
$execute if items entity @s enderchest.4 #trimmable_armor[trim~{pattern:$(trim)}] run item modify entity @s enderchest.4 blue:shared/remove_trim
$execute if items entity @s enderchest.5 $(trim)_armor_trim_smithing_template run item replace entity @s enderchest.5 with air
$execute if items entity @s enderchest.5 #trimmable_armor[trim~{pattern:$(trim)}] run item modify entity @s enderchest.5 blue:shared/remove_trim
$execute if items entity @s enderchest.6 $(trim)_armor_trim_smithing_template run item replace entity @s enderchest.6 with air
$execute if items entity @s enderchest.6 #trimmable_armor[trim~{pattern:$(trim)}] run item modify entity @s enderchest.6 blue:shared/remove_trim
$execute if items entity @s enderchest.7 $(trim)_armor_trim_smithing_template run item replace entity @s enderchest.7 with air
$execute if items entity @s enderchest.7 #trimmable_armor[trim~{pattern:$(trim)}] run item modify entity @s enderchest.7 blue:shared/remove_trim
$execute if items entity @s enderchest.8 $(trim)_armor_trim_smithing_template run item replace entity @s enderchest.8 with air
$execute if items entity @s enderchest.8 #trimmable_armor[trim~{pattern:$(trim)}] run item modify entity @s enderchest.8 blue:shared/remove_trim
$execute if items entity @s enderchest.9 $(trim)_armor_trim_smithing_template run item replace entity @s enderchest.9 with air
$execute if items entity @s enderchest.9 #trimmable_armor[trim~{pattern:$(trim)}] run item modify entity @s enderchest.9 blue:shared/remove_trim
$execute if items entity @s enderchest.10 $(trim)_armor_trim_smithing_template run item replace entity @s enderchest.10 with air
$execute if items entity @s enderchest.10 #trimmable_armor[trim~{pattern:$(trim)}] run item modify entity @s enderchest.10 blue:shared/remove_trim
$execute if items entity @s enderchest.11 $(trim)_armor_trim_smithing_template run item replace entity @s enderchest.11 with air
$execute if items entity @s enderchest.11 #trimmable_armor[trim~{pattern:$(trim)}] run item modify entity @s enderchest.11 blue:shared/remove_trim
$execute if items entity @s enderchest.12 $(trim)_armor_trim_smithing_template run item replace entity @s enderchest.12 with air
$execute if items entity @s enderchest.12 #trimmable_armor[trim~{pattern:$(trim)}] run item modify entity @s enderchest.12 blue:shared/remove_trim
$execute if items entity @s enderchest.13 $(trim)_armor_trim_smithing_template run item replace entity @s enderchest.13 with air
$execute if items entity @s enderchest.13 #trimmable_armor[trim~{pattern:$(trim)}] run item modify entity @s enderchest.13 blue:shared/remove_trim
$execute if items entity @s enderchest.14 $(trim)_armor_trim_smithing_template run item replace entity @s enderchest.14 with air
$execute if items entity @s enderchest.14 #trimmable_armor[trim~{pattern:$(trim)}] run item modify entity @s enderchest.14 blue:shared/remove_trim
$execute if items entity @s enderchest.15 $(trim)_armor_trim_smithing_template run item replace entity @s enderchest.15 with air
$execute if items entity @s enderchest.15 #trimmable_armor[trim~{pattern:$(trim)}] run item modify entity @s enderchest.15 blue:shared/remove_trim
$execute if items entity @s enderchest.16 $(trim)_armor_trim_smithing_template run item replace entity @s enderchest.16 with air
$execute if items entity @s enderchest.16 #trimmable_armor[trim~{pattern:$(trim)}] run item modify entity @s enderchest.16 blue:shared/remove_trim
$execute if items entity @s enderchest.17 $(trim)_armor_trim_smithing_template run item replace entity @s enderchest.17 with air
$execute if items entity @s enderchest.17 #trimmable_armor[trim~{pattern:$(trim)}] run item modify entity @s enderchest.17 blue:shared/remove_trim
$execute if items entity @s enderchest.18 $(trim)_armor_trim_smithing_template run item replace entity @s enderchest.18 with air
$execute if items entity @s enderchest.18 #trimmable_armor[trim~{pattern:$(trim)}] run item modify entity @s enderchest.18 blue:shared/remove_trim
$execute if items entity @s enderchest.19 $(trim)_armor_trim_smithing_template run item replace entity @s enderchest.19 with air
$execute if items entity @s enderchest.19 #trimmable_armor[trim~{pattern:$(trim)}] run item modify entity @s enderchest.19 blue:shared/remove_trim
$execute if items entity @s enderchest.20 $(trim)_armor_trim_smithing_template run item replace entity @s enderchest.20 with air
$execute if items entity @s enderchest.20 #trimmable_armor[trim~{pattern:$(trim)}] run item modify entity @s enderchest.20 blue:shared/remove_trim
$execute if items entity @s enderchest.21 $(trim)_armor_trim_smithing_template run item replace entity @s enderchest.21 with air
$execute if items entity @s enderchest.21 #trimmable_armor[trim~{pattern:$(trim)}] run item modify entity @s enderchest.21 blue:shared/remove_trim
$execute if items entity @s enderchest.22 $(trim)_armor_trim_smithing_template run item replace entity @s enderchest.22 with air
$execute if items entity @s enderchest.22 #trimmable_armor[trim~{pattern:$(trim)}] run item modify entity @s enderchest.22 blue:shared/remove_trim
$execute if items entity @s enderchest.23 $(trim)_armor_trim_smithing_template run item replace entity @s enderchest.23 with air
$execute if items entity @s enderchest.23 #trimmable_armor[trim~{pattern:$(trim)}] run item modify entity @s enderchest.23 blue:shared/remove_trim
$execute if items entity @s enderchest.24 $(trim)_armor_trim_smithing_template run item replace entity @s enderchest.24 with air
$execute if items entity @s enderchest.24 #trimmable_armor[trim~{pattern:$(trim)}] run item modify entity @s enderchest.24 blue:shared/remove_trim
$execute if items entity @s enderchest.25 $(trim)_armor_trim_smithing_template run item replace entity @s enderchest.25 with air
$execute if items entity @s enderchest.25 #trimmable_armor[trim~{pattern:$(trim)}] run item modify entity @s enderchest.25 blue:shared/remove_trim
$execute if items entity @s enderchest.26 $(trim)_armor_trim_smithing_template run item replace entity @s enderchest.26 with air
$execute if items entity @s enderchest.26 #trimmable_armor[trim~{pattern:$(trim)}] run item modify entity @s enderchest.26 blue:shared/remove_trim