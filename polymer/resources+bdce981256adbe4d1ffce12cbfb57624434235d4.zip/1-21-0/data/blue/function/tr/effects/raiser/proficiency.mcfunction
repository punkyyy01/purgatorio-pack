execute if score #.60 blue.misc matches 15 run xp add @s[level=20..] 1
execute if score #.60 blue.misc matches 15 run xp add @s[level=20..40] 1
execute if entity @s[advancements={blue:tr/tags={tutorial_piercer=false}},predicate=blue:tr/raiser_charge] unless entity @s[scores={blue.tr.combat=..400},level=20..] run function blue:tr/effects/raiser/piercer/tutorial
execute store result score #.temp blue.misc run xp query @s levels
execute if score #.temp blue.misc = @s blue.tr.secondary_data run return fail
scoreboard players operation @s blue.tr.secondary_data = #.temp blue.misc
particle totem_of_undying ~ ~1 ~ 0.3 0.4 0.3 0.1 2
attribute @s generic.movement_speed modifier remove blue:tr.trim
attribute @s generic.attack_speed modifier remove blue:tr.trim
attribute @s generic.attack_damage modifier remove blue:tr.trim
execute if entity @s[level=..20] run return fail
scoreboard players operation #.temp blue.misc < #.raiser.limit blue.config
execute store result storage blue:trims temp.float float 0.01 store result storage blue:trims temp.f2 float 0.0009 store result storage blue:trims temp.f3 float 0.00008 run scoreboard players get #.temp blue.misc
execute store result storage blue:trims temp.int int 1000 run scoreboard players get #.raiser.multiplier blue.config
function blue:tr/effects/raiser/multiplier with storage blue:trims temp
function blue:tr/effects/raiser/set_attributes with storage blue:trims temp