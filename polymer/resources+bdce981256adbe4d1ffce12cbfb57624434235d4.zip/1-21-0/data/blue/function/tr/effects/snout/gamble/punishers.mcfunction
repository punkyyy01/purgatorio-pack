title @s actionbar {"translate":"blue.tr.gamble.punishers","fallback":"Punishers","color":"dark_red"}
summon piglin_brute ~4 ~ ~ {Tags:["blue.tr.gamble.punisher","blue.tr.gamble.punisher_new"],HandItems:[{id:golden_axe},{id:golden_axe}],equipment:{mainhand:{id:golden_axe},offhand:{id:golden_axe}},DeathLootTable:""}
summon piglin_brute ~-4 ~ ~ {Tags:["blue.tr.gamble.punisher","blue.tr.gamble.punisher_new"],HandItems:[{id:golden_axe},{id:golden_axe}],equipment:{mainhand:{id:golden_axe},offhand:{id:golden_axe}},DeathLootTable:""}
execute as @e[tag=blue.tr.gamble.punisher_new,distance=..9,limit=2,type=piglin_brute] at @s run function blue:tr/effects/snout/gamble/brutes
playsound entity.piglin_brute.converted_to_zombified player @a[distance=..40] ~ ~ ~ 1.5 0.75