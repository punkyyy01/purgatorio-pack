scoreboard players add @s blue.tr.ambient 1
execute if predicate blue:shared/is_sneaking_flag if entity @s[advancements={blue:tr/tags={not_sneaking=true}}] run function blue:tr/effects/spire/sneak
execute if score #.20 blue.misc matches 15 run function blue:tr/effects/spire/origin/delay
execute if dimension overworld if entity @s[y=400,dy=30] in the_end run function blue:tr/effects/spire/origin/to_end
execute if score @s blue.tr.ambient matches 10.. store success score @s blue.tr.ambient run particle dragon_breath ~ ~0.8 ~ 0.2 0.35 0.2 0.01 1 normal @a[scores={blue.particles=1..},distance=..64]
execute if score @s blue.tr.ambient matches 5 run particle dragon_breath ~ ~0.8 ~ 0.2 0.35 0.2 0.01 1 normal @a[scores={blue.particles=2..},distance=..64]
execute if score @s blue.tr.primary_data matches ..-1 run function blue:tr/effects/spire/reversal/negative_charge
execute if entity @s[x_rotation=-90..-75] if predicate blue:shared/on_ground rotated 0 0 run function blue:tr/effects/spire/reversal/charge
execute if score @s blue.tr.primary_data matches 0.. unless predicate blue:shared/on_ground run function blue:tr/effects/spire/reversal/release
execute if score @s blue.tr.primary_data matches 1.. run function blue:tr/effects/spire/reversal/timer
execute as @e[tag=!blue.tr.checked,predicate=blue:tr/blast-o-breath,distance=..6,limit=1,type=item] run function blue:tr/effects/spire/throw
execute if score #.spire.aperture blue.config matches 0 run return fail
execute if dimension the_end if entity @s[y=-40,dy=-30] positioned ~ -20 ~ run function blue:tr/effects/spire/origin/to_overworld
execute unless predicate blue:tr/aperture_res run return fail
execute if items entity @s armor.chest elytra if predicate blue:shared/is_flying run return run particle end_rod ~ ~ ~ 0.2 0.2 0.2 0.015 2
particle end_rod ~ ~-1 ~ 0.3 1 0.3 0.015 2