advancement revoke @s only blue:tr/ability/alarm
execute store success score #.temp blue.misc if predicate blue:shared/in_stronghold
tag @s add blue.tr.current_tick
execute as @e[tag=blue.tr.eye.alarm,type=marker,distance=..300] run function blue:tr/effects/eye/alarm/marker
tag @s remove blue.tr.current_tick