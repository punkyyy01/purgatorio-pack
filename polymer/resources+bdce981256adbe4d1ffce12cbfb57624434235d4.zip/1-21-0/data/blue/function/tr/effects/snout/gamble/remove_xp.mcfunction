playsound block.note_block.guitar player @a[distance=..20] ~ ~ ~ 0.75 0.5
particle scrape ~ ~1 ~ 0.2 0.25 0.2 2.5 6
xp add @s -150 points