scoreboard players set #.temp blue.misc -466
effect give @s resistance 5 1 true
effect give @s speed 5 0 true