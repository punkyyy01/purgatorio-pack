kill @e[tag=blue.tr.rib.hitbox,predicate=blue:shared/id_link,distance=..24,type=interaction]
scoreboard players set @s blue.tr.primary_cooldown 180
execute if predicate blue:shared/in_fortress run scoreboard players set @s blue.tr.primary_cooldown 90
playsound entity.blaze.shoot player @a[distance=..40] ^ ^ ^1 1.8 1.2
function blue:tr/effects/rib/proj/fireball/spawn
particle flame ^ ^0.1 ^4 0.1 0.1 0.1 0.1 16
scoreboard players set @s blue.tr.fourth_data 15