particle poof ~ ~-0.8 ~
scoreboard players add @s blue.tr.ambient 1
scoreboard players set @s[scores={blue.tr.ambient=21..}] blue.tr.ambient 1
execute unless score @s blue.tr.ambient matches 2..10 unless score @s blue.tr.ambient matches 12.. run playsound block.sand.break player @a[distance=..20] ~ ~ ~ 0.5 0.4
execute store result storage blue:trims temp.id int 1 run scoreboard players operation #.link blue.id = @s blue.id
execute as @a[distance=..64] run function blue:tr/delayed/cmd/trust/define/player
execute unless block ~ ~ ~ #blue:shared/passable run return run function blue:tr/effects/dune/geyser/quiet_vfx
execute unless score @s blue.tr.ambient matches 2..10 unless score @s blue.tr.ambient matches 12.. positioned ~-1.5 ~ ~-1.5 as @a[tag=!blue.tr.trusted_player,dx=2,dy=3,dz=2] run damage @s 7 blue:tr/fire by @a[scores={blue.tr.current_trim=2},predicate=blue:shared/id_link,limit=1]
execute unless score @s blue.tr.ambient matches 2..10 unless score @s blue.tr.ambient matches 12.. run playsound block.lava.pop player @a[tag=!blue.tr.trusted_player,distance=..24] ~ ~0.25 ~ 0.8 0.8
particle flame ~ ~0.6 ~ 0.14 1.2 0.14 0.001 8 normal @a[tag=!blue.tr.trusted_player,distance=..64]
particle flame ~ ~0.3 ~ 0.17 0.3 0.17 0.005 4 normal @a[tag=!blue.tr.trusted_player,scores={blue.particles=1..},distance=..64]
particle small_flame ~ ~0.7 ~ 0.175 1.4 0.175 0 4 normal @a[tag=!blue.tr.trusted_player,scores={blue.particles=2..},distance=..64]
particle smoke ~ ~1 ~ 0.2 0.5 0.2 0 3 normal @a[tag=!blue.tr.trusted_player,distance=..64]
execute if score @s blue.tr.ambient matches 1 run playsound weather.rain player @a[tag=blue.tr.trusted_player,distance=..24] ~ ~0.25 ~ 0.4 1.6
execute positioned ~-1.5 ~ ~-1.5 run effect give @a[tag=blue.tr.trusted_player,dx=2,dy=4,dz=2,predicate=!blue:shared/has_regen] regeneration 3 2 true
particle splash ~ ~0.6 ~ 0.08 1.5 0.08 0 40 normal @a[tag=blue.tr.trusted_player,distance=..64]
particle splash ~ ~0.5 ~ 0.1 0.6 0.1 0 12 normal @a[tag=blue.tr.trusted_player,scores={blue.particles=2..},distance=..64]
particle rain ~ ~0.1 ~ 0.225 0.25 0.225 0 26 normal @a[tag=blue.tr.trusted_player,scores={blue.particles=1..},distance=..64]
tag @a[tag=blue.tr.trusted_player] remove blue.tr.trusted_player
execute positioned ~-0.5 ~ ~-0.5 run effect give @a[dy=1] slow_falling 1 0 true
execute unless score @s blue.tr.ambient matches 2..10 unless score @s blue.tr.ambient matches 12.. run particle cloud ~ ~0.2 ~ 0 100000 0 0.0000015 0