tag @a[tag=blue.tr.current_tick,distance=..24,limit=1] add blue.tr.eye.actionbar
tag @a[tag=blue.tr.current_tick,distance=..24,limit=1] remove blue.tr.eye.actionbar-2
execute if score @a[tag=blue.tr.current_tick,distance=..24,limit=1] blue.tr.secondary_data matches 1.. run return fail
execute unless score @s blue.tr.fear matches 2.. run return run title @a[tag=blue.tr.current_tick,distance=..24,limit=1] actionbar {"translate":"blue.tr.fear_amount","fallback":"%s has %s.%ss of Fear","color":"gray","with":[{"selector":"@s"},"0","0"]}
tag @s add blue.tr.eye.fear_visible
scoreboard players remove @s blue.tr.fear 2
scoreboard players operation #x blue.misc = @s blue.tr.fear
scoreboard players operation #x blue.misc *= #20 blue.misc
execute store result score #z blue.misc store result storage blue:trims temp.int int 0.1 run scoreboard players operation #x blue.misc /= #40 blue.misc
execute store result score #x blue.misc run data get storage blue:trims temp.int 10
scoreboard players operation #z blue.misc -= #x blue.misc
title @a[tag=blue.tr.current_tick,distance=..24,limit=1] actionbar {"translate":"blue.tr.fear_amount","fallback":"%s has %s.%ss of Fear","color":"gray","with":[{"selector":"@s"},{"storage":"blue:trims","nbt":"temp.int","color":"green","plain":true},{"score":{"name":"#z","objective":"blue.misc"},"color":"dark_green"}]}