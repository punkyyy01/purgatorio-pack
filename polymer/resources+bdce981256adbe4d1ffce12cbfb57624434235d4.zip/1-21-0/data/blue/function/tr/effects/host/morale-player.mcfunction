execute if entity @s[advancements={blue:tr/tags={heavy_hit=true}}] as @a[tag=blue.tr.current_tick,distance=..32,limit=1] at @s run function blue:tr/effects/host/sacrifice
effect give @a[tag=blue.tr.current_tick,distance=..32,limit=1] resistance 1 1 true
advancement revoke @s only blue:tr/tags heavy_hit
effect give @s resistance 1 1 true