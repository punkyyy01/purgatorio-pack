execute on origin if entity @s[tag=blue.tr.current_tick] run scoreboard players set #.temp blue.misc -8821
execute on origin if entity @s[tag=blue.tr.current_tick,scores={blue.tr.secondary_data=1..}] run scoreboard players set #.temp blue.misc -8822
execute unless score #.temp blue.misc matches -8822..-8821 run return fail
particle sweep_attack
playsound entity.player.attack.sweep player @a[distance=..20] ~ ~ ~ 0.5 2
playsound entity.skeleton.death player @a[distance=..20] ~ ~ ~ 1 2
schedule function blue:tr/effects/rib/deflect/loop 1t
execute store result entity @s acceleration_power double 0.25 run data get entity @s acceleration_power 10
execute if score #.temp blue.misc matches -8821 store result entity @s ExplosionPower byte 3 run data get entity @s ExplosionPower
execute if score #.temp blue.misc matches -8822 store result entity @s ExplosionPower byte 4.5 run data get entity @s ExplosionPower
scoreboard players reset #.temp blue.misc
tag @s add blue.tr.rib.deflected