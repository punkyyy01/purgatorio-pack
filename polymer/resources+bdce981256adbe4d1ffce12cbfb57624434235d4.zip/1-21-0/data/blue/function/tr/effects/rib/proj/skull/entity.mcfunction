tp ^ ^ ^1.2
scoreboard players add @s blue.misc 1
scoreboard players operation #.link blue.id = @s blue.id
execute if score @s blue.misc matches 5.. run particle smoke ^ ^ ^0.6 0.2 0.2 0.2 0.025 2
execute if score @s blue.misc matches 5.. run particle smoke ^ ^ ^ 0.2 0.2 0.2 0.025 2 normal @a[scores={blue.particles=1..}]
execute if score @s blue.misc matches 2 run data merge entity @s {transformation:{left_rotation:[0,1,0,0],right_rotation:[0,0,0,1],scale:[1.75,1.75,1.75],translation:[0.0,0.5d,0.0]},start_interpolation:0}
execute at @s if block ~ ~-0.25 ~ #blue:shared/passable if block ~0.25 ~ ~ #blue:shared/passable if block ~-0.25 ~ ~ #blue:shared/passable if block ~ ~ ~0.25 #blue:shared/passable if block ~ ~ ~-0.25 #blue:shared/passable if block ~ ~0.25 ~ #blue:shared/passable if block ~-0.25 ~ ~-0.25 #blue:shared/passable if block ~0.25 ~ ~-0.25 #blue:shared/passable if block ~-0.25 ~ ~0.25 #blue:shared/passable if block ~0.25 ~ ~0.25 #blue:shared/passable if block ~-0.25 ~0.25 ~-0.25 #blue:shared/passable if block ~-0.25 ~0.25 ~0.25 #blue:shared/passable if block ~-0.25 ~0.25 ~ #blue:shared/passable if block ~0.25 ~0.25 ~ #blue:shared/passable if block ~-0.25 ~-0.25 ~-0.25 #blue:shared/passable if block ~-0.25 ~-0.25 ~0.25 #blue:shared/passable if block ~-0.25 ~-0.25 ~ #blue:shared/passable if block ~0.25 ~-0.25 ~ #blue:shared/passable if block ~-0.25 ~0.25 ~-0.25 #blue:shared/passable if block ~0.25 ~0.25 ~-0.25 #blue:shared/passable if block ~-0.25 ~0.25 ~0.25 #blue:shared/passable if block ~0.25 ~0.25 ~0.25 #blue:shared/passable if block ~-0.25 ~-0.25 ~-0.25 #blue:shared/passable if block ~0.25 ~-0.25 ~-0.25 #blue:shared/passable if block ~-0.25 ~-0.25 ~0.25 #blue:shared/passable if block ~0.25 ~-0.25 ~0.25 #blue:shared/passable if score @s blue.misc matches ..35 positioned ~-1 ~-1 ~-1 unless entity @e[type=!#blue:shared/no_ai,predicate=!blue:shared/id_link,dx=1,dy=1,dz=1] run return fail
particle soul ^ ^ ^1 0.1 0.1 0.1 0.1 28 force
execute if score @s blue.misc matches 35.. run return run kill
particle soul ^ ^ ^1 0.1 0.1 0.1 0.15 12
particle large_smoke ^ ^ ^1 0.1 0.1 0.1 0.1 16
execute if dimension the_nether positioned ^ ^ ^1 as @e[type=!#blue:shared/no_ai,tag=!blue.tr.trim.rib,team=!blue.tr.rib,distance=..4.5] run damage @s 24 blue:tr/skull by @e[tag=blue.tr.rib.skull,distance=..6,predicate=blue:shared/id_link,limit=1,type=item_display] from @a[scores={blue.tr.current_trim=6},predicate=blue:shared/id_link,limit=1]
execute unless dimension the_nether positioned ^ ^ ^1 as @e[type=!#blue:shared/no_ai,tag=!blue.tr.trim.rib,team=!blue.tr.rib,distance=..3.5] run damage @s 16 blue:tr/skull by @e[tag=blue.tr.rib.skull,distance=..6,predicate=blue:shared/id_link,limit=1,type=item_display] from @a[scores={blue.tr.current_trim=6},predicate=blue:shared/id_link,limit=1]
effect give @e[type=!#blue:shared/no_ai,tag=!blue.tr.trim.rib,team=!blue.tr.rib,distance=..3.5] wither 3 3
playsound entity.wither.hurt player @a[distance=..32] ^ ^ ^1 1.5 1.5
playsound entity.generic.explode player @a[distance=..64] ^ ^ ^1 3 0.9
playsound entity.generic.explode player @a[distance=..64] ^ ^ ^1 3 0.9
kill