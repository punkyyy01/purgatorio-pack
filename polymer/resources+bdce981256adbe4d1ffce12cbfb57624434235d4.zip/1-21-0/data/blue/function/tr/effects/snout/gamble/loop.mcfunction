scoreboard players remove @a[scores={blue.tr.current_trim=10,blue.tr.primary_data=1..}] blue.tr.primary_data 1
scoreboard players remove @a[scores={blue.tr.current_trim=10,blue.tr.secondary_data=1..}] blue.tr.secondary_data 1
execute if entity @a[scores={blue.tr.current_trim=10,blue.tr.primary_data=1..},limit=1] run schedule function blue:tr/effects/snout/gamble/loop 1t
execute if entity @a[scores={blue.tr.current_trim=10,blue.tr.secondary_data=1..},limit=1] run schedule function blue:tr/effects/snout/gamble/loop 1t