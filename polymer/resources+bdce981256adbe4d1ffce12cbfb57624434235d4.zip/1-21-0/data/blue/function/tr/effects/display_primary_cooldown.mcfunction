tag @s[scores={blue.tr.primary_cooldown=..10}] add blue.tr.actionbar
tag @s[scores={blue.tr.primary_cooldown=..10}] remove blue.tr.actionbar-2
execute if score @s blue.tr.primary_cooldown matches ..10 run schedule function blue:tr/effects/display_reset 2t
scoreboard players operation #x blue.misc = @s blue.tr.primary_cooldown
scoreboard players operation #x blue.misc *= #20 blue.misc
execute store result score #z blue.misc store result storage blue:trims temp.int int 0.1 run scoreboard players operation #x blue.misc /= #40 blue.misc
execute store result score #x blue.misc run data get storage blue:trims temp.int 10
scoreboard players operation #z blue.misc -= #x blue.misc
execute if entity @s[tag=blue.tr.trim.vex] run data modify storage blue:trims display set value {"translate":"blue.tr.lunge_name","fallback":"Lunge","color":"#cfc6a5"}
execute if entity @s[tag=blue.tr.trim.coast] run data modify storage blue:trims display set value {"translate":"blue.tr.fire_name","fallback":"Fire!","color":"#C1C888"}
execute if entity @s[tag=blue.tr.trim.shaper] run data modify storage blue:trims display set value {"translate":"blue.tr.not-so_controlled_demolition_name","fallback":"Not-so Controlled Demolition","color":"#8F8F8F"}
execute if entity @s[tag=blue.tr.trim.sentry] run data modify storage blue:trims display set value {"translate":"blue.tr.ballista_name","fallback":"Ballista","color":"#4B885B"}
execute if entity @s[tag=blue.tr.trim.tide] run data modify storage blue:trims display set value {"translate":"blue.tr.tidal_burst_name","fallback":"Tidal Burst","color":"#199ADD"}
execute if entity @s[tag=blue.tr.trim.host] run data modify storage blue:trims display set value {"translate":"blue.tr.exchange_name","fallback":"Exchange","color":"#A34646"}
execute if entity @s[tag=blue.tr.trim.rib] run data modify storage blue:trims display set value {"translate":"blue.tr.nether_volley_name","fallback":"Nether Volley","color":"#E6484B"}
execute if entity @s[tag=blue.tr.trim.silence] run data modify storage blue:trims display set value {"translate":"blue.tr.vortex_name","fallback":"Vortex","color":"#3842Cf"}
execute if entity @s[tag=blue.tr.trim.spire] run data modify storage blue:trims display set value {"translate":"blue.tr.reversal_name","fallback":"Reversal","color":"#BE20C7"}
execute if entity @s[tag=blue.tr.trim.ward] run data modify storage blue:trims display set value {"translate":"blue.tr.kinetic_deflection_name","fallback":"Kinetic Deflection","color":"#7D91D5"}
execute if entity @s[tag=blue.tr.trim.wayfinder] run data modify storage blue:trims display set value {"translate":"blue.tr.warp_name","fallback":"Warp","color":"#F1FFC8"}
execute if entity @s[tag=blue.tr.trim.flow] run data modify storage blue:trims display set value {"translate":"blue.tr.wind_barrage_name","fallback":"Wind Barrage","color":"#85B2C5"}
title @s actionbar {"translate":"%s • %s.%ss","color":"gray","with":[{"storage":"blue:trims","nbt":"display","interpret":true},{"storage":"blue:trims","nbt":"temp.int","color":"white","plain":true},{"score":{"name":"#z","objective":"blue.misc"},"color":"white"}]}