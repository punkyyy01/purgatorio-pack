execute if score @s blue.tr.primary_data matches ..-1 run scoreboard players operation @s blue.tr.primary_cooldown = @s blue.tr.primary_data
execute if score @s blue.tr.primary_data matches ..-1 run scoreboard players operation @s[scores={blue.tr.primary_cooldown=..-1}] blue.tr.primary_cooldown *= #-1 blue.misc
execute if score @s blue.tr.primary_data matches ..-1 run return run function blue:tr/effects/display_primary_cooldown
scoreboard players reset #.temp0 blue.misc
scoreboard players reset #.cast blue.misc
scoreboard players add @s blue.tr.primary_data 1
execute if score @s blue.tr.primary_data matches ..70 run scoreboard players remove @s blue.tr.secondary_data 10
execute unless score @s blue.tr.primary_data matches ..70 run scoreboard players remove @s blue.tr.secondary_data 9
execute if score @s blue.tr.primary_data matches 10..69 run particle enchant ~ ~1 ~ 0.1 0.1 0.1 3 2
execute if score @s blue.tr.primary_data matches 70.. run particle enchant ~ ~1 ~ 0.1 0.1 0.1 3 1
execute if score @s blue.tr.primary_data matches 25.. run effect give @s slowness 1 2 true
execute if score @s blue.tr.primary_data matches 55.. run effect give @s slowness 1 4 true
execute if score @s blue.tr.primary_data matches 25 run playsound block.beacon.power_select player @s ~ ~ ~ 1.5 1.25
execute if score @s blue.tr.primary_data matches 25 positioned ~0.55 ~0.1 ~ run return run function blue:tr/effects/spire/reversal/cast_one
execute if score @s blue.tr.primary_data matches 40 run playsound block.beacon.power_select player @s ~ ~ ~ 2 1.5
execute if score @s blue.tr.primary_data matches 40 positioned ~0.55 ~0.27 ~ run function blue:tr/effects/spire/reversal/cast_two
execute if score @s blue.tr.primary_data matches 40 run scoreboard players reset #.cast blue.misc
execute if score @s blue.tr.primary_data matches 40 positioned ~0.55 ~0.15 ~ run return run function blue:tr/effects/spire/reversal/cast_two
execute if score @s blue.tr.primary_data matches 55 run playsound block.beacon.power_select player @s ~ ~ ~ 2.5 1.75
execute if score @s blue.tr.primary_data matches 55 positioned ~0.55 ~0.5 ~ run function blue:tr/effects/spire/reversal/cast_three
execute if score @s blue.tr.primary_data matches 55 run scoreboard players reset #.cast blue.misc
execute if score @s blue.tr.primary_data matches 55 positioned ~0.55 ~0.425 ~ run function blue:tr/effects/spire/reversal/cast_three
execute if score @s blue.tr.primary_data matches 55 run scoreboard players reset #.cast blue.misc
execute if score @s blue.tr.primary_data matches 55 positioned ~0.55 ~0.34 ~ run return run function blue:tr/effects/spire/reversal/cast_three
execute unless score @s blue.tr.primary_data matches 70 run return fail
playsound block.beacon.power_select player @s ~ ~ ~ 3 2
execute positioned ~0.55 ~1.3 ~ run function blue:tr/effects/spire/reversal/cast_five
scoreboard players reset #.cast blue.misc
execute positioned ~0.55 ~1.05 ~ run function blue:tr/effects/spire/reversal/cast_four
scoreboard players reset #.cast blue.misc
execute positioned ~0.55 ~0.85 ~ run function blue:tr/effects/spire/reversal/cast_four
scoreboard players reset #.cast blue.misc
execute positioned ~0.55 ~0.72 ~ run function blue:tr/effects/spire/reversal/cast_four
scoreboard players reset #.cast blue.misc
execute positioned ~0.55 ~0.6 ~ run function blue:tr/effects/spire/reversal/cast_four