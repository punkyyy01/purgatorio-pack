data merge entity @s {Tags:["blue.tr.gamble.display","blue.tr.gamble.apple"],alignment:center,billboard:center,transformation:{scale:[3,3,3],translation:[0f,0.5f,0f],left_rotation:[0,0,0,1],right_rotation:[0,0,0,1]}}
data modify entity @s text set from storage blue:trims display
scoreboard players operation @s blue.id = #.link blue.id
execute store result score @s blue.tr.schedule_context run schedule function blue:tr/effects/snout/gluttony/kill 35t append