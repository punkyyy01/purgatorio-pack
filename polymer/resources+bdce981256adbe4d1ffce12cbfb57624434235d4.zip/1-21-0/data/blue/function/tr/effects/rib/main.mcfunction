scoreboard players add @s blue.tr.ambient 1
execute if score @s blue.tr.ambient matches 5.. store success score @s blue.tr.ambient run particle small_flame ~ ~0.7 ~ 0.3 0.3 0.3 0 1 normal @a[scores={blue.particles=1..},distance=..64]
execute unless score @s blue.tr.primary_cooldown matches 1.. unless predicate blue:tr/cancel_volley anchored eyes run function blue:tr/effects/rib/proj/detect
execute if entity @s[tag=blue.tr.sneaking,predicate=blue:tr/cancel_volley] run function blue:tr/effects/rib/proj/reset
execute as @e[distance=..20,tag=!blue.tr.rib.deflected,tag=!dnt_ghasted_fireball,type=fireball] at @s run function blue:tr/effects/rib/deflect/check
execute if score @s blue.tr.ambient matches 3 run particle small_flame ~ ~0.7 ~ 0.3 0.3 0.3 0 1 normal @a[scores={blue.particles=2..},distance=..64]
execute if score @s blue.tr.secondary_data matches 1.. run function blue:tr/effects/rib/ashen/active
execute if score @s blue.tr.fourth_data matches 1.. run function blue:tr/effects/rib/proj/fireball/timer
execute unless score #.20 blue.misc matches 3 run return fail
effect give @s fire_resistance 4 0 true
execute if block ~ ~ ~ lava run effect give @s[predicate=!blue:shared/has_regen] regeneration 2 0 true
execute unless predicate blue:shared/has_vehicle run return fail
execute on vehicle run effect give @s fire_resistance 4 0 true
execute on vehicle run effect clear @s wither