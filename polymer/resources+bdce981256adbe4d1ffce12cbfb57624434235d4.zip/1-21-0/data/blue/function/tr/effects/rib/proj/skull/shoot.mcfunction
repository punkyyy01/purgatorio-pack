stopsound @a[distance=..24] * entity.player.attack.nodamage
kill @e[tag=blue.tr.rib.hitbox,predicate=blue:shared/id_link,distance=..24,type=interaction]
scoreboard players set @s blue.tr.primary_cooldown 220
execute if predicate blue:shared/in_fortress run scoreboard players set @s blue.tr.primary_cooldown 110
scoreboard players set #.tr.entity_exists blue.misc 1
summon item_display ~ ~ ~ {Tags:["blue.tr.rib.skull","blue.tr.entity","blue.tr.temp"],item:{id:wither_skeleton_skull,components:{enchantment_glint_override:true}},brightness:{block:15,sky:15},transformation:{left_rotation:[0,1,0,0],right_rotation:[0,0,0,1],scale:[0,0,0],translation:[0,0,0]},interpolation_duration:9}
execute as @e[tag=blue.tr.temp,type=item_display,distance=..1,limit=1] run function blue:tr/effects/rib/proj/skull/modify
playsound entity.wither.shoot player @a[distance=..40] ^ ^ ^1 2 1.2
particle smoke ^ ^ ^3 0.1 0.1 0.1 0.075 12