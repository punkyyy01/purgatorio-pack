tag @s add blue.tr.deflectable
execute if items entity @s contents gold_nugget run tag @s add blue.tr.snout.add_trail
execute if score #.temp blue.misc matches 400.. if items entity @s contents gold_ingot run tag @s add blue.tr.snout.add_trail
execute if score #.temp blue.misc matches 600.. if items entity @s contents gold_block run tag @s add blue.tr.snout.add_trail
playsound item.trident.throw player @a[distance=..40] ~ ~ ~ 1.5 2
data modify storage blue:trims temp.Motion set from entity @s Motion
execute store result storage blue:trims temp.Motion[0] double 0.004 run data get storage blue:trims temp.Motion[0] 1000
execute store result storage blue:trims temp.Motion[1] double 0.004 run data get storage blue:trims temp.Motion[1] 1000
execute store result storage blue:trims temp.Motion[2] double 0.004 run data get storage blue:trims temp.Motion[2] 1000
data modify entity @s Motion set from storage blue:trims temp.Motion