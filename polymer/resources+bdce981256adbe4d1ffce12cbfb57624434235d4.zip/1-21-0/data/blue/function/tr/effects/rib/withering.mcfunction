advancement revoke @s only blue:tr/ability/withering req
playsound entity.wither_skeleton.death player @a[distance=..26] ^ ^ ^4 1 1.5
playsound entity.wither_skeleton.death player @a[distance=..26] ^ ^ ^4 1 1.5
execute anchored eyes run loot spawn ^ ^-0.25 ^2 loot entities/wither_skeleton
execute if predicate blue:r/40c anchored eyes run loot spawn ^ ^-0.25 ^2 loot blocks/wither_skeleton_skull
advancement grant @s only blue:tr/tags can_inflict