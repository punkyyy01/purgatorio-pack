scoreboard players add @s blue.tr.ambient 1
execute if score @s blue.tr.ambient matches 8.. store success score @s blue.tr.ambient run particle glow ~ ~0.7 ~ 0.3 0.25 0.3 0 1 normal @a[scores={blue.particles=1..},distance=..64]
execute if score #.20 blue.misc matches 6 run function blue:tr/effects/eye/delay
execute if score @s blue.tr.ambient matches 4 run particle glow ~ ~0.7 ~ 0.3 0.25 0.3 0 1 normal @a[scores={blue.particles=2..},distance=..64]
execute if entity @s[tag=blue.tr.eye.actionbar] run function blue:tr/effects/eye/displays
execute if score #.eye.two_tick blue.misc matches 1 if items entity @s weapon.* ender_eye positioned ^ ^ ^5 as @p[distance=..9,tag=!blue.tr.current_tick,gamemode=!spectator] run function blue:tr/effects/eye/fear/display
execute as @e[tag=!blue.tr.checked,distance=..6,type=eye_of_ender] run function blue:tr/effects/eye/disfigure/track_eye
schedule function blue:tr/effects/eye/tick_loop 1t
execute if predicate blue:shared/is_sneaking run return run function blue:tr/effects/eye/charge_reveal
execute if score @s blue.tr.primary_data matches 1.. run function blue:tr/effects/eye/end_reveal