execute if score #.60 blue.misc matches 25 if entity @e[distance=..100,limit=1,type=villager] if entity @e[type=#raiders,distance=..80,limit=1] run function blue:tr/effects/sentry/defender
execute if score #.60 blue.misc matches 50 if entity @e[distance=..100,limit=1,type=villager] if entity @e[type=#raiders,distance=..80,limit=1] run particle enchanted_hit ~ ~0.9 ~ 0.3 0.3 0.3 0 5 normal @a[scores={blue.particles=2..},distance=..64]
scoreboard players add @s blue.tr.ambient 1
execute if score @s blue.tr.ambient matches 3 run particle enchanted_hit ~ ~0.8 ~ 0.3 0.3 0.3 0 1 normal @a[scores={blue.particles=2..},distance=..64]
execute if score @s blue.tr.ambient matches 5.. store success score @s blue.tr.ambient run particle enchanted_hit ~ ~0.8 ~ 0.3 0.3 0.3 0 1 normal @a[scores={blue.particles=1..},distance=..64]
execute if score @s blue.tr.primary_data matches 0.. unless predicate blue:tr/can_shoot store success score @s blue.tr.fourth_data run scoreboard players reset @s blue.tr.primary_data
execute anchored eyes positioned ^ ^ ^1 as @e[type=#arrows,tag=!blue.tr.checked,distance=..5] run function blue:tr/effects/sentry/arrow
execute if score @s blue.tr.secondary_data matches 1.. run function blue:tr/effects/sentry/streak_duration
execute unless predicate blue:shared/has_hero run return fail
execute if predicate {"condition":"entity_properties","type":"entity_properties","entity":"this","predicate":{"effects":{"hero_of_the_village":{"duration":{"max":1}}}}} run function blue:tr/effects/sentry/refresh
effect clear @s slowness
effect clear @s poison
execute if predicate blue:tr/can_shoot anchored eyes run function blue:tr/effects/sentry/ballista/can_shoot