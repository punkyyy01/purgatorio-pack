damage @s 5 blue:tr/pufferfish by @a[tag=blue.tr.current_tick,limit=1]
scoreboard players set #.temp blue.misc -99
particle rain ^ ^ ^-0.25 0.1 0.1 0.1 0 24
playsound entity.puffer_fish.hurt player @a[distance=..32]