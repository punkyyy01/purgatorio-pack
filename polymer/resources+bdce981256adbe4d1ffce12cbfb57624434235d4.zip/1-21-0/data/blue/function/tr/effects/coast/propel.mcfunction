tag @s add blue.tr.propel_check
execute on origin if entity @s[tag=blue.tr.current_tick] run scoreboard players set #.temp blue.misc -5912
execute unless score #.temp blue.misc matches -5912 run return fail
scoreboard players reset #.temp blue.misc
execute on origin unless score @s blue.tr.primary_data matches 40.. run tag @s remove blue.tr.coast.propel
execute on origin if score @s blue.tr.primary_data matches 40.. run scoreboard players remove @s blue.tr.primary_data 40
playsound item.trident.throw player @a[distance=..20] ~ ~ ~ 1 0.9
data modify storage blue:trims temp.Motion set from entity @s Motion
execute store result storage blue:trims temp.Motion[0] double 0.0015 run data get storage blue:trims temp.Motion[0] 1000
execute store result storage blue:trims temp.Motion[1] double 0.0015 run data get storage blue:trims temp.Motion[1] 1000
execute store result storage blue:trims temp.Motion[2] double 0.0015 run data get storage blue:trims temp.Motion[2] 1000
data modify entity @s Motion set from storage blue:trims temp.Motion
data modify entity @s crit set value 1b
tag @s add blue.tr.coast.propelled