team join blue.tr.silence @e[team=,tag=!blue.tr.silence.was_hit,distance=..100,type=warden]
team join blue.tr.silence