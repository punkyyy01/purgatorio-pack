advancement revoke @s only blue:tr/ability/fisher req
function blue:tr/effects/get_luck
execute if score #.temp blue.misc matches 1001.. run scoreboard players set #.temp blue.misc 1000
execute store result score #.temp0 blue.misc run time query day
execute unless score #.temp0 blue.misc = @s blue.tr.third_data run tag @s add blue.tr.coast.propel
execute unless score #.temp0 blue.misc = @s blue.tr.third_data run scoreboard players operation @s blue.tr.primary_data = @s blue.tr.secondary_data
execute unless score #.temp0 blue.misc = @s blue.tr.third_data unless score @s blue.tr.secondary_data matches 2000.. run scoreboard players add @s blue.tr.secondary_data 20
execute unless score #.temp0 blue.misc = @s blue.tr.third_data run scoreboard players operation #.temp blue.misc += @s blue.tr.secondary_data
execute unless score #.temp0 blue.misc = @s blue.tr.third_data run scoreboard players add #.temp blue.misc 100
scoreboard players operation @s blue.tr.third_data = #.temp0 blue.misc
loot spawn ~ ~0.5 ~ fish blue:tr/z/fish ~ ~ ~