schedule function blue:tr/effects/spire/aperture/find 1t
execute as @e[tag=blue.tr.spire.aperture,type=marker] at @s run function blue:tr/effects/spire/aperture/marker