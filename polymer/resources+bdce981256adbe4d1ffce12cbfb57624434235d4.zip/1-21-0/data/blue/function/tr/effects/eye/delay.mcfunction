scoreboard players operation #.link blue.id = @s blue.id
execute if predicate blue:shared/in_stronghold run function blue:tr/effects/eye/alarm/in_stronghold
execute as @a[distance=16.01..32,predicate=blue:shared/has_glowing,gamemode=!spectator,gamemode=!creative] unless score @s blue.tr.fear matches 500.. run scoreboard players add @s blue.tr.fear 4
execute as @a[distance=8.01..16,predicate=blue:shared/has_glowing,gamemode=!spectator,gamemode=!creative] unless score @s blue.tr.fear matches 600.. run scoreboard players add @s blue.tr.fear 8
execute as @a[distance=0.01..8,predicate=blue:shared/has_glowing,gamemode=!spectator,gamemode=!creative] unless score @s blue.tr.fear matches 700.. run scoreboard players add @s blue.tr.fear 12
execute at @e[tag=blue.tr.eye.alarm,predicate=blue:shared/id_link,type=marker,limit=1] as @a[distance=..300,predicate=blue:shared/in_stronghold,gamemode=!spectator,gamemode=!creative] at @s run function blue:tr/effects/eye/alarm/debuff