advancement revoke @s only blue:tr/ability/afterstrike
execute on attacker run advancement revoke @s only blue:tr/ability/afterstrike
execute on attacker run tag @s add blue.tr.snout.temp
particle enchanted_hit ~ ~1 ~ 0.3 0.4 0.3 0.4 32
particle crit ~ ~1 ~ 0 0.5 0 0 16
playsound ui.stonecutter.take_result player @a[distance=..40] ~ ~ ~ 1.5 1.2
damage @s 10 blue:tr/raw by @a[tag=blue.tr.snout.temp,limit=1]
tag @a[tag=blue.tr.snout.temp,limit=1] remove blue.tr.snout.temp