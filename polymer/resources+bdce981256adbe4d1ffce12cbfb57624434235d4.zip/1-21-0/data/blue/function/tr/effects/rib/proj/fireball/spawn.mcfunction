scoreboard players set #.tr.entity_exists blue.misc 1
execute positioned 0.0 0 0.0 positioned ^ ^ ^2.5 summon marker run function blue:shared/shootfacing
execute store result storage blue:shared player_id int 1 run scoreboard players get @s blue.id
function blue:shared/get_uuid with storage blue:shared
data modify storage blue:trims merge.fireball.Owner set from storage blue:shared UUID
data modify storage blue:trims merge.fireball.Motion set from storage blue:shared Pos
execute positioned ^ ^ ^-0.3 positioned ~ ~-0.15 ~ summon small_fireball run data modify entity @s {} merge from storage blue:trims merge.fireball
playsound entity.blaze.shoot player @a[distance=..40] ^ ^ ^1 1.3 1.6
particle flame ^ ^0.1 ^4.5 0.1 0.1 0.1 0.02 2