scoreboard players set #.temp0 blue.misc 0
execute on attacker store success score #.temp0 blue.misc run tag @s[scores={blue.tr.current_trim=1}] add blue.tr.current_tick
execute if score #.temp0 blue.misc matches 0 run tag @p[scores={blue.tr.current_trim=1},distance=0.1..] add blue.tr.current_tick
damage @s[scores={blue.health=..3}] 30 blue:tr/pufferfish by @a[scores={blue.tr.current_trim=1},limit=1]
execute if score @s blue.health matches ..3 run tag @a[scores={blue.tr.current_trim=1},limit=1] add blue.tr.coast.propel
scoreboard players reset #.temp blue.misc
execute if entity @s[gamemode=survival] run scoreboard players set #.temp blue.misc -1
execute if entity @s[gamemode=adventure] run scoreboard players set #.temp blue.misc -2
gamemode creative
tp @s ~ ~1000 ~
execute facing entity @a[scores={blue.tr.current_trim=1},limit=1] feet positioned ^ ^ ^-2 positioned ~ ~1001.5 ~ summon end_crystal run damage @s 1
execute if entity @s[tag=blue.tr.coast.delay_strong] facing entity @a[scores={blue.tr.current_trim=1},limit=1] feet positioned ^ ^ ^-2.2 positioned ~ ~1001.5 ~ summon end_crystal run damage @s 1
execute if score #.temp blue.misc matches -1 run gamemode survival
execute if score #.temp blue.misc matches -2 run gamemode adventure
tag @a[tag=blue.tr.current_tick,limit=1] remove blue.tr.current_tick
tp @s ~ ~ ~
tag @s remove blue.tr.coast.delay_strong
tag @s remove blue.tr.coast.delay