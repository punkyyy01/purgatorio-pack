particle smoke ~ ~0.5 ~ 0.25 0.25 0.25 0 1 normal @a[scores={blue.particles=1..},distance=..64]
execute unless score #.shaper.tnt_bounce blue.config matches 1 run return fail
data modify storage blue:trims temp.Motion set from entity @s Motion
execute store result score #x blue.misc run data get storage blue:trims temp.Motion[0] 100000
execute store result score #y blue.misc run data get storage blue:trims temp.Motion[1] 100000
execute store result score #z blue.misc run data get storage blue:trims temp.Motion[2] 100000
execute if score #x blue.misc matches 0 unless score @s blue.tr.primary_data matches -2000..2000 store result entity @s Motion[0] double -0.000005 run scoreboard players get @s blue.tr.primary_data
execute if score #y blue.misc matches 0 unless score @s blue.tr.secondary_data matches -5000..2000 store result entity @s Motion[1] double -0.000005 run scoreboard players get @s blue.tr.secondary_data
execute if score #z blue.misc matches 0 unless score @s blue.tr.third_data matches -2000..2000 store result entity @s Motion[2] double -0.000005 run scoreboard players get @s blue.tr.third_data
execute store result score @s blue.tr.primary_data run data get storage blue:trims temp.Motion[0] 100000
execute store result score @s blue.tr.secondary_data run data get storage blue:trims temp.Motion[1] 100000
execute store result score @s blue.tr.third_data run data get storage blue:trims temp.Motion[2] 100000