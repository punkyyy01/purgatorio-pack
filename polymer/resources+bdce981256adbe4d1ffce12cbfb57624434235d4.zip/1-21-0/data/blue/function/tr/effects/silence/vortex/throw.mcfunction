execute positioned 0.0 0.3 0.0 positioned ^ ^ ^0.9 summon marker run function blue:shared/shootfacing
scoreboard players set #.tr.entity_exists blue.misc 1
execute anchored eyes run summon item ^ ^ ^1 {Invulnerable:1b,Age:5600s,PickupDelay:32767s,Item:{id:"minecraft:sculk",Count:1b},Tags:["blue.tr.checked","blue.tr.silence.vortex","blue.tr.entity","smithed.entity","blue.tr.deflectable","blue.tr.temp"],Motion:[0d,0d,0d]}
scoreboard players operation @e[tag=blue.tr.temp,type=item,distance=..9,limit=1] blue.id = @s blue.id
data modify entity @e[tag=blue.tr.temp,type=item,distance=..9,limit=1] Motion set from storage blue:shared Pos
tag @e[tag=blue.tr.temp,type=item,distance=..9,limit=1] remove blue.tr.temp
scoreboard players set @s blue.tr.primary_cooldown 800
playsound entity.warden.attack_impact player @a[distance=..50] ~ ~ ~ 2.5 0.5
advancement grant @s only blue:tr/tags tutorial_vortex
scoreboard players set @s blue.tr.primary_data 300