advancement revoke @s only blue:tr/ability/archaeology
execute unless score @s blue.tr.current_trim matches 2 run return fail
playsound entity.armadillo.brush player @a[distance=..20] ^ ^ ^2 1 0.5
execute anchored eyes run particle enchanted_hit ^ ^ ^2 0.15 0.2 0.15 0.3 16
execute anchored eyes positioned ^ ^ ^2 summon experience_orb store result entity @s Value int 1 run random value 1..63
execute anchored eyes positioned ^ ^ ^2 run loot spawn ~ ~-0.3 ~ loot blue:tr/z/archaeology