tag @s remove blue.tr.spire.breath_cooldown
execute store success score #.temp blue.misc if dimension the_end
execute if score #.temp blue.misc matches 1 run function blue:tr/effects/spire/origin/in_end
execute if score #.temp blue.misc matches 1 if entity @s[tag=blue.tr.spire.origin] run return fail
execute if score #.temp blue.misc matches 0 unless entity @s[tag=blue.tr.spire.origin] run return fail
particle end_rod ~ ~1 ~ 0.4 0.6 0.4 0.1 16
execute if score #.temp blue.misc matches 1 run attribute @s generic.attack_damage modifier add blue:tr.trim 1.5 add_value
execute if score #.temp blue.misc matches 1 run attribute @s generic.armor modifier add blue:tr.trim 4 add_value
execute if score #.temp blue.misc matches 1 run return run tag @s add blue.tr.spire.origin
attribute @s generic.attack_damage modifier remove blue:tr.trim
attribute @s generic.armor modifier remove blue:tr.trim
tag @s remove blue.tr.spire.origin