execute unless score @s blue.tr.primary_data matches 60.. run return run scoreboard players reset @s blue.tr.primary_data
effect clear @e[type=!player,tag=!smithed.entity,distance=..128] glowing
scoreboard players reset @s blue.tr.primary_data
playsound entity.phantom.ambient player @a[distance=..40] ~ ~ ~ 1.5 1.5
particle reverse_portal ~ ~1 ~ 0.2 0.2 0.2 3 128
effect give @s glowing 1 0 true
effect give @s speed 5 2 true
effect clear @s blindness
function blue:tr/effects/flash {args:""}