$attribute @s generic.movement_speed modifier add blue:tr.trim $(f3) add_value
$attribute @s generic.attack_speed modifier add blue:tr.trim $(f2) add_multiplied_total
$attribute @s generic.attack_damage modifier add blue:tr.trim $(float) add_value