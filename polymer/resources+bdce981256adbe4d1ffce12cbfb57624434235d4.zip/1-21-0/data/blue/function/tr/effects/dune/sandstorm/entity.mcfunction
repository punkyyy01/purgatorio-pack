particle dust{color:[0.9f,0.8f,0.6f],scale:1.6} ~ ~0.1 ~ 3 1.5 3 0 40
particle dust{color:[0.9f,0.8f,0.6f],scale:1.6} ~ ~0.1 ~ 3 1.5 3 0 20 force
function blue:tr/delayed/cmd/trust/define/main
execute as @e[tag=!blue.tr.dune.thrown,type=ender_pearl,distance=..9] if function blue:tr/effects/dune/sandstorm/origin run data merge entity @s {Item:{id:"minecraft:birch_button",custom_model_data:200600,components:{"minecraft:item_model":"air"}},Tags:["blue.tr.dune.thrown"]}
execute unless score #.temp blue.misc matches 3 run particle dust{color:[0.9f,0.8f,0.6f],scale:1.6} ~ ~0.1 ~ 3 1.5 3 0 30 normal @a[scores={blue.particles=2..}]
execute unless score #.temp blue.misc matches 3 run particle dust{color:[0.9f,0.8f,0.6f],scale:1.6} ~ ~0.1 ~ 3 1.5 3 0 90 normal @a[tag=!blue.tr.trusted_player]
execute if score #.temp blue.misc matches 1 run particle dust{color:[0.9f,0.8f,0.6f],scale:1.2} ~ ~0.1 ~ 1.5 0.75 1.5 0 60 normal @a[tag=!blue.tr.trusted_player]
tag @a[tag=blue.tr.trusted_player] remove blue.tr.trusted_player
scoreboard players set #.temp0 blue.misc 140
execute if biome ~ ~ ~ #blue:shared/sandy run scoreboard players add #.temp0 blue.misc 30
execute positioned over motion_blocking unless entity @s[dy=300] run scoreboard players remove #.temp0 blue.misc 30
execute if predicate blue:shared/raining unless biome ~ ~ ~ #blue:shared/no_rain positioned over ocean_floor at @s[dy=300] run scoreboard players remove #.temp0 blue.misc 30
execute unless score @s blue.misc >= #.temp0 blue.misc run return run scoreboard players add @s blue.misc 1
playsound block.soul_sand.place player @a[distance=..50] ~ ~ ~ 2.5 0.5
playsound block.soul_sand.place player @a[distance=..50] ~ ~ ~ 2.5 0.5
kill