advancement revoke @s only blue:tr/ability/spire_land req
effect clear @s resistance