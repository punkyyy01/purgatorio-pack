execute store result storage blue:trims temp.id int 1 run scoreboard players get @a[tag=blue.tr.current_tick,distance=..9,limit=1] blue.id
execute on origin run function blue:tr/delayed/cmd/trust/define/player
execute on origin if entity @s[tag=blue.tr.trusted_player] run return run tag @s remove blue.tr.trusted_player