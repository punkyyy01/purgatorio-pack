scoreboard players add @s blue.misc 1
execute if score @s blue.misc matches 36.. run kill
execute unless block ~ ~ ~ water run return fail
playsound block.fire.extinguish player @a[distance=..20] ~ ~ ~ 1 1.1
particle smoke ~ ~0.1 ~ 0.1 0.1 0.1 0.05 16
particle lava
kill