execute store result score @a[tag=blue.tr.current_tick,distance=..8,limit=1] blue.tr.schedule_context run schedule function blue:tr/effects/host/guardian/anger 1t append
execute as @e[distance=..32,tag=!smithed.entity,nbt={PlayerCreated:1b},type=iron_golem] run data modify entity @s PlayerCreated set value 0b
scoreboard players remove @a[tag=blue.tr.current_tick,distance=..8,limit=1] blue.tr.combat 900
effect give @a[tag=blue.tr.current_tick,distance=..8,limit=1] resistance 3 2 true
effect give @e[distance=..32,type=iron_golem] speed 2 1 true
execute if entity @e[tag=blue.tr.host.guardian,type=iron_golem,limit=1] run return fail
scoreboard players operation #.link blue.id = @a[tag=blue.tr.current_tick,distance=..8,limit=1] blue.id
execute store success score #.temp blue.misc if predicate blue:shared/in_village
execute positioned ^ ^ ^-0.5 summon iron_golem run function blue:tr/effects/host/guardian/context
schedule function blue:tr/effects/host/guardian/loop 1t