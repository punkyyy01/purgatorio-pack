advancement revoke @s only blue:tr/ability/stalk req
tag @s add blue.tr.eye.actionbar
tag @s remove blue.tr.eye.actionbar-2
execute anchored eyes positioned ^ ^ ^100 run function blue:tr/effects/eye/stalk/square
tag @s add blue.tr.current_tick
execute anchored eyes positioned ^ ^ ^1.5 run function blue:tr/effects/eye/stalk/cast
tag @s remove blue.tr.current_tick
execute if score @s blue.tr.secondary_data matches 1.. unless entity @a[tag=blue.tr.stalk_limit,limit=1] run function blue:tr/effects/eye/stalk/decay
tag @a[tag=blue.tr.stalk_limit] remove blue.tr.stalk_limit
execute if score @s blue.tr.secondary_cooldown matches 1.. run return run title @s actionbar {"text":"##########","color":"dark_green","italic":true,"obfuscated":true}
execute unless score @s blue.tr.secondary_data matches 19.. run return run title @s actionbar {"text":"👁👁👁👁👁👁👁👁👁👁","color":"dark_green","italic":true}
execute if score @s blue.tr.secondary_data matches 20..39 run title @s actionbar ["",{"text":"👁","color":"green","bold":true},{"text":"👁👁👁👁👁👁👁👁👁","color":"dark_green","italic":true}]
execute if score @s blue.tr.secondary_data matches 40..59 run title @s actionbar ["",{"text":"👁👁","color":"green","bold":true},{"text":"👁👁👁👁👁👁👁👁","color":"dark_green","italic":true}]
execute if score @s blue.tr.secondary_data matches 60..79 run title @s actionbar ["",{"text":"👁👁👁","color":"green","bold":true},{"text":"👁👁👁👁👁👁👁","color":"dark_green","italic":true}]
execute if score @s blue.tr.secondary_data matches 80..99 run title @s actionbar ["",{"text":"👁👁👁👁","color":"green","bold":true},{"text":"👁👁👁👁👁👁","color":"dark_green","italic":true}]
execute if score @s blue.tr.secondary_data matches 100..119 run title @s actionbar ["",{"text":"👁👁👁👁👁","color":"green","bold":true},{"text":"👁👁👁👁👁","color":"dark_green","italic":true}]
execute if score @s blue.tr.secondary_data matches 120..139 run title @s actionbar ["",{"text":"👁👁👁👁👁👁","color":"green","bold":true},{"text":"👁👁👁👁","color":"dark_green","italic":true}]
execute if score @s blue.tr.secondary_data matches 140..159 run title @s actionbar ["",{"text":"👁👁👁👁👁👁👁","color":"green","bold":true},{"text":"👁👁👁","color":"dark_green","italic":true}]
execute if score @s blue.tr.secondary_data matches 160..179 run title @s actionbar ["",{"text":"👁👁👁👁👁👁👁👁","color":"green","bold":true},{"text":"👁👁","color":"dark_green","italic":true}]
execute if score @s blue.tr.secondary_data matches 180..199 run title @s actionbar ["",{"text":"👁👁👁👁👁👁👁👁👁","color":"green","bold":true},{"text":"👁","color":"dark_green","italic":true}]
execute if score @s blue.tr.secondary_data matches 200.. run title @s actionbar {"text":"- 👁👁👁👁👁👁👁👁👁👁 -","color":"green","bold":true}
scoreboard players operation #.temp blue.misc = @s blue.tr.secondary_data
scoreboard players operation #.temp blue.misc /= #20 blue.misc
scoreboard players add @s blue.tr.third_data 0
execute unless score #.temp blue.misc > @s blue.tr.third_data run return fail
scoreboard players operation @s blue.tr.third_data = #.temp blue.misc
execute if score @s blue.tr.secondary_data matches ..119 run function blue:tr/effects/eye/stalk/sound_low
execute if score @s blue.tr.secondary_data matches 120..219 run function blue:tr/effects/eye/stalk/sound_high