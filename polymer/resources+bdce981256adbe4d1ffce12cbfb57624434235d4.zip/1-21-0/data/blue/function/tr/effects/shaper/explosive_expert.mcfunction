advancement revoke @s only blue:tr/ability/explosive_expert req
playsound block.anvil.land player @a[distance=..20] ~ ~ ~ 1 1.8
particle smoke ~ ~1.5 ~ 0.3 0.4 0.3 0.1 40
effect give @s instant_health 1 0 true
effect give @s regeneration 3 1 true