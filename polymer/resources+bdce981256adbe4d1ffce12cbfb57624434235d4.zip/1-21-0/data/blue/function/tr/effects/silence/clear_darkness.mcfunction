advancement revoke @s only blue:tr/ability/darkness req
effect clear @s darkness