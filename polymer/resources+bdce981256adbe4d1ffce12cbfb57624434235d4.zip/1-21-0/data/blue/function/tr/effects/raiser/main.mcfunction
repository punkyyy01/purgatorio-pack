scoreboard players add @s blue.tr.ambient 1
execute if score #.60 blue.misc matches 15 run function blue:tr/effects/raiser/proficiency
execute as @e[distance=1..15,type=experience_orb] run function blue:tr/effects/raiser/orb
execute if entity @s[scores={blue.tr.combat=..1200},level=20..,predicate=blue:tr/raiser_charge] anchored eyes positioned ^ ^ ^0.2 positioned ~ ~-0.4 ~ run return run function blue:tr/effects/raiser/piercer/charge
execute if score @s blue.tr.primary_data matches 1.. run function blue:tr/effects/raiser/piercer/reset
execute unless score @s blue.tr.ambient matches 7.. run return fail
scoreboard players set @s blue.tr.ambient 1
execute if entity @s[level=100..] run return run particle entity_effect{color:[0.9f,0.9f,0.9f,1f]} ~ ~0.4 ~ 0.25 0.3 0.25 0 1 normal @a[scores={blue.particles=1..},distance=..64]
execute if entity @s[level=100..] run return run particle entity_effect{color:[1f,1f,1f,1f]} ~ ~0.4 ~ 0.25 0.3 0.25 0 1 normal @a[scores={blue.particles=2..},distance=..64]
execute if entity @s[level=30..59] run return run particle entity_effect{color:[0f,0f,0f,0.6f]} ~ ~0.4 ~ 0.15 0.3 0.15 0 1 normal @a[scores={blue.particles=1..},distance=..64]
execute if entity @s[level=60..99] run return run particle entity_effect{color:[0.7f,0.7f,0.7f,0.8f]} ~ ~0.4 ~ 0.2 0.3 0.2 0 1 normal @a[scores={blue.particles=1..},distance=..64]
xp add @s[level=..19] 1