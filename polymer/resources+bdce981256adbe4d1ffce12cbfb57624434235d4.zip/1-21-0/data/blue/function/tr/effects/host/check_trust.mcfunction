function blue:tr/delayed/cmd/trust/define/player
execute unless entity @s[tag=blue.tr.trusted_player] run return fail
execute store result storage blue:trims temp.id int 1 run scoreboard players get @s blue.id
execute as @a[tag=blue.tr.current_tick,distance=..1,limit=1] run function blue:tr/delayed/cmd/trust/define/player
execute unless entity @a[tag=blue.tr.current_tick,tag=blue.tr.trusted_player,distance=..1,limit=1] run tag @s remove blue.tr.trusted_player