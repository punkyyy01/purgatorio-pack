playsound entity.zombie_villager.converted player @a[distance=..20] ~ ~ ~ 0.5 1.5
particle item_cobweb ~ ~1 ~ 0.3 0.4 0.3 0.5 16
effect give @s mining_fatigue 6 100
effect give @s slowness 6 100
effect give @s weakness 6 100