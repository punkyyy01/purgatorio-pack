playsound block.fire.extinguish player @a[distance=..20] ~ ~ ~ 0.5 1.25
particle smoke ~ ~0.1 ~ 0.1 0.1 0.1 0.02 8
particle lava
kill