tag @s add blue.tr.stalk_limit
execute unless score @a[tag=blue.tr.current_tick,distance=..200,limit=1] blue.tr.secondary_cooldown matches 1.. unless score @a[tag=blue.tr.current_tick,distance=..200,limit=1] blue.tr.secondary_data matches 220.. run scoreboard players add @a[tag=blue.tr.current_tick,distance=..200,limit=1] blue.tr.secondary_data 1
execute if entity @a[tag=blue.tr.current_tick,distance=..200,tag=blue.tr.eye.actionbar,limit=1] run return fail
scoreboard players add @s blue.tr.fear 1600
scoreboard players set @a[tag=blue.tr.current_tick,distance=..200,limit=1] blue.tr.secondary_cooldown 200
playsound item.totem.use player @s ~ ~ ~ 2 1.5
kill b163102f-0-6-0-1
summon marker ~ ~ ~ {UUID:[I;-1318907857,6,0,1]}
execute if entity @a[tag=blue.tr.current_tick,distance=..64,limit=1] run damage @s 28 blue:tr/scare by b163102f-0-6-0-1 from @a[tag=blue.tr.current_tick,distance=..200,limit=1]
execute if entity @a[tag=blue.tr.current_tick,distance=64.01..,limit=1] run damage @s 36 blue:tr/scare by b163102f-0-6-0-1 from @a[tag=blue.tr.current_tick,distance=..200,limit=1]
kill b163102f-0-6-0-1
function blue:tr/effects/flash {args:" ~ ~1 ~ 0.2 0.2 0.2 0 8 force @s[scores={blue.particles=1..}]"}
particle scrape ~ ~1 ~ 0.1 0.1 0.1 50 32 force @a[distance=3..256]
effect give @s mining_fatigue 6 0
effect give @s darkness 1 0
effect give @s weakness 6 0
effect give @s glowing 6 0