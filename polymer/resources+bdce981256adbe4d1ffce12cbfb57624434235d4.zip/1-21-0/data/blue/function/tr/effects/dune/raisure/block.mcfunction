execute store result entity @s Air byte 1 run scoreboard players get #.20 blue.misc
particle falling_dust{block_state:{Name:sand,id:sand}} ~ ~0.5 ~ 0.25 0.2 0.25 0 1
particle falling_dust{block_state:{Name:sand,id:sand}} ~ ~0.5 ~ 0.25 0.2 0.25 0 1 normal @a[scores={blue.particles=1..}]
scoreboard players add @s blue.misc 1
execute unless score @s blue.misc matches 10.. run return fail
execute store success score #.temp blue.misc if entity @s[tag=blue.tr.dune.no_sandstorm,tag=!blue.tr.dune.tossed]
execute if score #.temp blue.misc matches 1 if score @s blue.misc matches 25.. run kill
execute store result score #.temp0 blue.misc run scoreboard players add @s blue.tr.combat 1
scoreboard players operation #.link blue.id = @s blue.id
execute positioned ~-0.5 ~-0.25 ~-0.5 as @a[dx=0,gamemode=!spectator,gamemode=!creative] run function blue:tr/effects/dune/raisure/hit
execute unless score #.temp blue.misc matches -592 positioned ~-0.5 ~-0.25 ~-0.5 as @e[type=!#blue:shared/peaceful,type=!player,dx=0] run function blue:tr/effects/dune/raisure/hit
execute unless score #.temp blue.misc matches -592 run return fail
particle item{item:suspicious_sand} ~ ~0.5 ~ 0.3 0.25 0.3 0.1 48
playsound item.brush.brushing.sand.complete player @a[distance=..40] ~ ~ ~ 1.5 1
playsound block.suspicious_sand.place player @a[distance=..32]
execute on passengers run kill
kill