scoreboard players add @s[tag=blue.tr.eye.fear_visible] blue.tr.fear 20
tag @s[tag=blue.tr.eye.fear_visible] remove blue.tr.eye.fear_visible
scoreboard players set @s[scores={blue.tr.fear=..19}] blue.tr.fear 20
execute store result score #.temp blue.misc store result score #.temp0 blue.misc run scoreboard players remove @s blue.tr.fear 20
scoreboard players operation #.temp0 blue.misc *= #10000 blue.misc
scoreboard players add #.temp blue.misc 1000
scoreboard players operation #.temp0 blue.misc /= #.temp blue.misc
execute unless predicate blue:tr/fear_chance run return fail
scoreboard players operation #.temp0 blue.misc = @s blue.tr.fear
scoreboard players operation #.temp0 blue.misc /= #10 blue.misc
scoreboard players operation @s blue.tr.fear -= #.temp0 blue.misc
execute store result score #.temp blue.misc run random value 1..60
scoreboard players operation #.temp0 blue.misc /= #2 blue.misc
scoreboard players operation #.temp blue.misc += #.temp0 blue.misc
execute if score #.temp blue.misc matches 59.. store result score #.temp blue.misc run random value 45..60
scoreboard players operation @s blue.tr.fear -= #.temp blue.misc
execute if score @s blue.tr.fear matches ..-1 run scoreboard players set @s blue.tr.fear 0
execute if score #.temp blue.misc matches ..44 at @s run function blue:tr/effects/eye/fear/low
execute if score #.temp blue.misc matches 45.. at @s run function blue:tr/effects/eye/fear/high