scoreboard players operation #.link blue.id = @s blue.id
tag @s add blue.tr.sneaking
scoreboard players set #.temp blue.misc 0
execute positioned ^ ^ ^0.6 store success score #.temp blue.misc run tp @e[tag=blue.tr.rib.hitbox,predicate=blue:shared/id_link,limit=1,type=interaction] ~ ~-0.2 ~
execute if score #.temp blue.misc matches 0 positioned ^ ^ ^0.6 positioned ~ ~-0.2 ~ summon interaction run function blue:tr/effects/rib/proj/spawn_interaction
execute positioned ^ ^ ^0.6 as @e[tag=blue.tr.rib.hitbox,predicate=blue:shared/id_link,distance=..5,limit=1,type=interaction] run function blue:tr/effects/rib/proj/interaction
execute if score #.temp blue.misc matches 3 positioned ^ ^ ^0.1 run function blue:tr/effects/rib/proj/fireball/activate
execute if score #.temp blue.misc matches 2 positioned ^ ^ ^0.1 run function blue:tr/effects/rib/proj/skull/shoot