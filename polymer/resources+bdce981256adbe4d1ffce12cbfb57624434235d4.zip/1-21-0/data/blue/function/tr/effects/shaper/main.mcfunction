scoreboard players add @s blue.tr.ambient 1
execute if score @s blue.tr.ambient matches 4.. store success score @s blue.tr.ambient run particle smoke ~ ~0.5 ~ 0.2 0.3 0.2 0.015 1 normal @a[scores={blue.particles=1..},distance=..64]
execute if entity @e[distance=..8,limit=1,nbt={fuse:1s},type=tnt] run function blue:tr/effects/shaper/invul
execute positioned ^ ^0.5 ^1.5 as @e[distance=..6,tag=!blue.tr.checked,predicate=blue:tr/shaper_item,type=item] run function blue:tr/effects/shaper/item
execute if score @s blue.tr.ambient matches 2 run particle smoke ~ ~0.5 ~ 0.2 0.3 0.2 0.015 2 normal @a[scores={blue.particles=2..},distance=..64]
execute if entity @s[tag=blue.tr.shaper.absorption,predicate=blue:shared/on_ground] run function blue:tr/effects/shaper/absorption
execute if entity @s[tag=blue.tr.shaper.falling] run function blue:tr/effects/shaper/fall
tag @s[tag=blue.tr.shaper.falling] remove blue.tr.shaper.falling
execute if score #.difficulty blue.misc matches 3.. run return run tag @s[predicate=blue:tr/high_fall] add blue.tr.shaper.falling
execute if score #.difficulty blue.misc matches 2 run return run tag @s[predicate=blue:tr/mid_fall] add blue.tr.shaper.falling
execute if score #.difficulty blue.misc matches ..1 run tag @s[predicate=blue:tr/low_fall] add blue.tr.shaper.falling