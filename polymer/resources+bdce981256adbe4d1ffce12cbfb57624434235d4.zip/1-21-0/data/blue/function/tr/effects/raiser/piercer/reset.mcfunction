scoreboard players set @s blue.tr.primary_cooldown 100
execute if score @s blue.tr.primary_data matches ..48 run return run scoreboard players reset @s blue.tr.primary_data
scoreboard players reset @s blue.tr.primary_data
playsound block.moss.break player @a[distance=..20] ~ ~ ~ 0.5 1
playsound block.moss.break player @a[distance=..20] ~ ~ ~ 0.5 1
playsound block.moss.break player @a[distance=..20] ~ ~ ~ 0.5 1
playsound block.moss.break player @a[distance=..20] ~ ~ ~ 0.5 1