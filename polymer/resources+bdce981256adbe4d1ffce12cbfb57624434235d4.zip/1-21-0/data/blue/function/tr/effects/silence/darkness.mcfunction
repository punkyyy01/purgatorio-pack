execute store result storage blue:trims temp.id int 1 run scoreboard players get @a[tag=blue.tr.current_tick,distance=..16,limit=1] blue.id
function blue:tr/delayed/cmd/trust/define/player
execute if entity @s[tag=blue.tr.trusted_player] run return run tag @s remove blue.tr.trusted_player
particle sculk_charge{roll:0} ~ ~0.8 ~ 0.3 0.5 0.3 0.02 4
execute if biome ~ ~ ~ deep_dark run schedule function blue:tr/effects/silence/muffle_loop 1t
execute if biome ~ ~ ~ deep_dark run return run effect give @s darkness 6 78 true
effect give @s darkness 5 1 true