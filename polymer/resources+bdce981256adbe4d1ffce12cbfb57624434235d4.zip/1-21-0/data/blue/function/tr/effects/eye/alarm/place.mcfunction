scoreboard players set #.temp blue.misc 0
kill @e[tag=blue.tr.eye.alarm,predicate=blue:shared/id_link,type=marker]
tag @s add smithed.entity
tag @s add smithed.strict
tag @s add blue.tr.eye.alarm
execute positioned ~30 ~ ~-30 if predicate blue:shared/in_stronghold store success score #.temp blue.misc run tp ~ ~ ~
execute unless score #.temp blue.misc matches 1 positioned ~-30 ~ ~30 if predicate blue:shared/in_stronghold store success score #.temp blue.misc run tp ~ ~ ~
execute unless score #.temp blue.misc matches 1 positioned ~-30 ~ ~-30 if predicate blue:shared/in_stronghold store success score #.temp blue.misc run tp ~ ~ ~
execute unless score #.temp blue.misc matches 1 positioned ~30 ~ ~30 if predicate blue:shared/in_stronghold store success score #.temp blue.misc run tp ~ ~ ~
execute unless score #.temp blue.misc matches 1 run tp ~ ~ ~
scoreboard players operation @s blue.id = #.link blue.id
data modify storage blue:shared Pos set from entity @s Pos
execute store result score #x blue.misc run data get storage blue:shared Pos[0]
execute store result score #y blue.misc run data get storage blue:shared Pos[1]
execute store result score #z blue.misc run data get storage blue:shared Pos[2]
tellraw @a[tag=blue.tr.current_tick,limit=1] {"translate":"blue.tr.eye.placed","fallback":"\n Alarm will now activate on this Stronghold %s\n  - It is best not to lose these coordinates for now.","color":"gray","with":[{"translate":"[%s, %s, %s]","color":"white","with":[{"score":{"name":"#x","objective":"blue.misc"},"color":"gold"},{"score":{"name":"#y","objective":"blue.misc"},"color":"gold"},{"score":{"name":"#z","objective":"blue.misc"},"color":"gold"}]}]}
tag @a[tag=blue.tr.current_tick,limit=1] add blue.tr.eye.placed