effect give @s slow_falling 1 0 true
scoreboard players reset #.temp blue.misc
execute if entity @s[gamemode=survival] run scoreboard players set #.temp blue.misc -1
execute if entity @s[gamemode=adventure] run scoreboard players set #.temp blue.misc -2
execute if dimension the_end run scoreboard players set @s blue.tr.secondary_cooldown 60
execute unless dimension the_end run scoreboard players set @s blue.tr.secondary_cooldown 100
gamemode creative
tp @s ~ 0 ~
tp @s ~ ~ ~
tp @s ~ ~1000 ~
execute unless score #.spire.limit_plunge blue.config matches 0 if score @s blue.tr.primary_data matches ..0 if score @s blue.tr.fourth_data matches ..0 rotated ~ 0 run return run function blue:tr/effects/spire/plunge/start
execute if score #.spire.limit_plunge blue.config matches 0 if score @s blue.tr.primary_data matches ..0 if score @s blue.tr.fourth_data matches ..0 run return run function blue:tr/effects/spire/plunge/start
execute store success score #.temp0 blue.misc if items entity @s weapon.* #spears
execute positioned ^ ^ ^-1 positioned ~ ~1001.2 ~ summon end_crystal run damage @s 1
execute if score #.spire.guidance_range blue.config matches 2.. positioned ^ ^ ^-6.5 positioned ~ ~1001.2 ~ summon end_crystal run damage @s 1
execute if score #.spire.guidance_range blue.config matches 3.. positioned ^ ^ ^-7.5 positioned ~ ~1001.2 ~ summon end_crystal run damage @s 1
execute if score #.temp0 blue.misc matches 1 positioned ^ ^ ^9 positioned ~ ~1001.2 ~ summon end_crystal run damage @s 1
execute if score #.temp0 blue.misc matches 1 if score #.spire.guidance_range blue.config matches 2.. positioned ^ ^ ^9.25 positioned ~ ~1001.2 ~ summon end_crystal run damage @s 1
tp @s ~ ~ ~
execute if score #.temp blue.misc matches -1 run gamemode survival
execute if score #.temp blue.misc matches -2 run gamemode adventure
playsound entity.phantom.flap player @a[distance=..16] ~ ~ ~ 2 1.5
playsound entity.phantom.flap player @a[distance=..16] ~ ~ ~ 2 1.5
playsound entity.phantom.flap player @a[distance=..16] ~ ~ ~ 2 1.5
execute positioned ~ ~0.5 ~ run particle cloud ^ ^ ^-0.3 0.1 0.4 0.1 0.03 6