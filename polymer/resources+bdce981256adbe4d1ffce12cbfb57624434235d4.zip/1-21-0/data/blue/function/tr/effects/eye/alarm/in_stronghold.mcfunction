execute unless entity @s[tag=blue.tr.eye.placed] summon marker run function blue:tr/effects/eye/alarm/place
execute unless entity @e[tag=blue.tr.eye.alarm,predicate=blue:shared/id_link,type=marker,distance=..300] run return fail
effect give @s invisibility 5 0 true
effect give @s speed 5 1 true