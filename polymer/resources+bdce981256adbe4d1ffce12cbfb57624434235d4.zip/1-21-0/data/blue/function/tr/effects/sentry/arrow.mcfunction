tag @s add blue.tr.checked
scoreboard players reset #.temp blue.misc
execute on origin if score @s blue.tr.current_trim matches 7 run scoreboard players operation #.temp blue.misc = @s blue.tr.secondary_data
execute if score #.temp blue.misc matches 51.. run scoreboard players set #.temp blue.misc 50
execute unless score #.temp blue.misc matches 0.. run return fail
scoreboard players add #.temp blue.misc 6
execute store result score #.temp0 blue.misc run data get entity @s damage 10
execute if predicate blue:shared/in_village run scoreboard players add #.temp blue.misc 6
execute if score #.temp blue.misc matches 14.. run data modify entity @s crit set value 1b
execute store result entity @s damage double 0.1 run scoreboard players operation #.temp blue.misc += #.temp0 blue.misc
execute on origin run scoreboard players remove @s blue.tr.secondary_data 3
execute on origin unless predicate blue:shared/is_sneaking run return fail
data modify entity @s SoundEvent set value "block.grass.fall"