scoreboard players remove @s blue.tr.fourth_data 1
execute if score @s blue.tr.fourth_data matches 6 anchored eyes positioned ^ ^ ^0.1 run return run function blue:tr/effects/rib/proj/fireball/spawn
execute if score @s blue.tr.fourth_data matches 4 anchored eyes positioned ^ ^ ^0.1 run return run function blue:tr/effects/rib/proj/fireball/spawn
execute if score @s blue.tr.fourth_data matches 2 anchored eyes positioned ^ ^ ^0.1 run return run function blue:tr/effects/rib/proj/fireball/spawn
execute unless dimension the_nether run return fail
execute if score @s blue.tr.fourth_data matches 12 anchored eyes positioned ^ ^ ^0.1 run return run function blue:tr/effects/rib/proj/fireball/spawn
execute if score @s blue.tr.fourth_data matches 10 anchored eyes positioned ^ ^ ^0.1 run return run function blue:tr/effects/rib/proj/fireball/spawn
execute if score @s blue.tr.fourth_data matches 8 anchored eyes positioned ^ ^ ^0.1 run function blue:tr/effects/rib/proj/fireball/spawn