execute unless entity @s[tag=blue.tr.eye.actionbar-2] run return run tag @s add blue.tr.eye.actionbar-2
tag @s remove blue.tr.eye.actionbar-2
tag @s remove blue.tr.eye.actionbar
title @s actionbar ""
execute unless score @s blue.tr.secondary_data matches 0.. run return fail
scoreboard players set @s blue.tr.third_data 0
scoreboard players operation #.temp blue.misc = @s blue.tr.secondary_data
scoreboard players reset @s blue.tr.secondary_data
execute if score #.temp blue.misc matches 200.. run playsound item.totem.use player @s ~ ~ ~ 0.5 2
execute if score #.temp blue.misc matches 200.. anchored eyes positioned ^ ^ ^1.5 run function blue:tr/effects/eye/stalk/cast
execute if score #.temp blue.misc matches 200.. run tag @a[tag=blue.tr.stalk_limit] remove blue.tr.stalk_limit
execute store result score @s blue.tr.schedule_context run schedule function blue:tr/effects/eye/stalk/actionbar 3t append
execute if score @s blue.tr.secondary_cooldown matches 1.. run return fail
execute unless score #.temp blue.misc matches 20.. run title @s actionbar {"text":"👁👁👁👁👁👁👁👁👁👁","color":"dark_gray","italic":true}
execute if score #.temp blue.misc matches 20..39 run title @s actionbar ["",{"text":"👁","color":"gray","bold":true},{"text":"👁👁👁👁👁👁👁👁👁","color":"dark_gray","italic":true}]
execute if score #.temp blue.misc matches 40..59 run title @s actionbar ["",{"text":"👁👁","color":"gray","bold":true},{"text":"👁👁👁👁👁👁👁👁","color":"dark_gray","italic":true}]
execute if score #.temp blue.misc matches 60..79 run title @s actionbar ["",{"text":"👁👁👁","color":"gray","bold":true},{"text":"👁👁👁👁👁👁👁","color":"dark_gray","italic":true}]
execute if score #.temp blue.misc matches 80..99 run title @s actionbar ["",{"text":"👁👁👁👁","color":"gray","bold":true},{"text":"👁👁👁👁👁👁","color":"dark_gray","italic":true}]
execute if score #.temp blue.misc matches 100..119 run title @s actionbar ["",{"text":"👁👁👁👁👁","color":"gray","bold":true},{"text":"👁👁👁👁👁","color":"dark_gray","italic":true}]
execute if score #.temp blue.misc matches 120..139 run title @s actionbar ["",{"text":"👁👁👁👁👁👁","color":"gray","bold":true},{"text":"👁👁👁👁","color":"dark_gray","italic":true}]
execute if score #.temp blue.misc matches 140..159 run title @s actionbar ["",{"text":"👁👁👁👁👁👁👁","color":"gray","bold":true},{"text":"👁👁👁","color":"dark_gray","italic":true}]
execute if score #.temp blue.misc matches 160..179 run title @s actionbar ["",{"text":"👁👁👁👁👁👁👁👁","color":"gray","bold":true},{"text":"👁👁","color":"dark_gray","italic":true}]
execute if score #.temp blue.misc matches 180..199 run title @s actionbar ["",{"text":"👁👁👁👁👁👁👁👁👁","color":"gray","bold":true},{"text":"👁","color":"dark_gray","italic":true}]
execute if score #.temp blue.misc matches 200.. run title @s actionbar {"text":"- 👁👁👁👁👁👁👁👁👁👁 -","color":"gray","bold":true}