advancement revoke @s only blue:tr/ability/infliction req
execute on attacker run advancement revoke @s only blue:tr/tags can_inflict
playsound entity.wither.break_block player @a[distance=..20] ~ ~ ~ 0.6 2
particle ash ~ ~1.2 ~ 0.3 0.4 0.3 0 24
effect give @s wither 3 9
damage @s 5 wither