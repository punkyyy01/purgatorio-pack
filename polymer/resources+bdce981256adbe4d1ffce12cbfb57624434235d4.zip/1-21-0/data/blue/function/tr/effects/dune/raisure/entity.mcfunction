execute if entity @s[tag=blue.tr.dune.block] run function blue:tr/effects/dune/raisure/block
execute if entity @s[tag=blue.tr.dune.hitbox] run function blue:tr/effects/dune/raisure/hitbox