execute store result score #.temp blue.misc run data get entity @s Brain.memories."minecraft:admiring_item".ttl
execute unless score #.temp blue.misc matches 90.. run return fail
scoreboard players set #.temp blue.misc 90
execute if entity @a[tag=blue.tr.current_tick,tag=blue.tr.mats.gold,distance=..1,limit=1] run scoreboard players remove #.temp blue.misc 30
execute if entity @a[tag=blue.tr.current_tick,predicate=blue:tr/gold_set,distance=..1,limit=1] run scoreboard players remove #.temp blue.misc 30
execute store result entity @s Brain.memories."minecraft:admiring_item".ttl int 1 run scoreboard players get #.temp blue.misc
execute at @s run particle happy_villager ~ ~1 ~ 0.4 0.4 0.4 0 6