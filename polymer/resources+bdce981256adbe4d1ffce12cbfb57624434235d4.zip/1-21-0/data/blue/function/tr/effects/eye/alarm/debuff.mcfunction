execute store result storage blue:trims temp.id int 1 run scoreboard players get #.link blue.id
function blue:tr/delayed/cmd/trust/define/player
execute if entity @s[tag=blue.tr.trusted_player] run return run tag @s remove blue.tr.trusted_player
execute unless score @s blue.tr.fear matches 1200.. run scoreboard players add @s blue.tr.fear 20
particle portal ~ ~1 ~ 0.3 0.3 0.3 0.6 4
effect give @s slowness 2 0 true
effect give @s glowing 2 0 true