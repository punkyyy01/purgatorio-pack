effect give @s levitation 1 9 true
particle poof ~ ~1 ~ 0.4 0.6 0.4 0.1 12
scoreboard players set @s blue.tr.primary_cooldown 1200
playsound block.trial_spawner.about_to_spawn_item player @a ~ ~ ~ 4.5 0.6
advancement grant @s only blue:tr/tags tutorial_barrage
advancement grant @s only blue:tr/ability/flow_gust
execute if predicate {"condition":"entity_properties","type":"entity_properties","entity":"this","predicate":{"movement":{"y":{"min":-0.1}}}} run return fail
tp @s ~ 100 ~
tp @s ~ ~ ~