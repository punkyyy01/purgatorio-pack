scoreboard players set #.eye.disfigure_time blue.misc 20
execute unless predicate {"condition":"entity_properties","type":"entity_properties","entity":"this","predicate":{"effects":{"minecraft:nausea":{"amplifier":17}}}} run return run scoreboard players reset @s blue.tr.used_pearl
scoreboard players set @s blue.tr.used_pearl -123
execute at @s as @e[type=ender_pearl,distance=..64,sort=nearest] run function blue:tr/effects/eye/disfigure/cursed_pearl
scoreboard players reset @s blue.tr.used_pearl
scoreboard players reset #.temp blue.misc