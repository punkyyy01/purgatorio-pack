execute store result score #.temp blue.misc if entity @e[tag=blue.tr.dune.sandstorm,limit=3,type=marker]
execute at @e[tag=blue.tr.dune.thrown,type=ender_pearl] run particle dust{color:[0.9f,0.8f,0.6f],scale:0.3} ~ ~0.1 ~ 0.1 0.1 0.1 0 6 force
execute as @e[tag=blue.tr.dune.sandstorm,type=marker] at @s run function blue:tr/effects/dune/sandstorm/entity
execute if score #.temp blue.misc matches 1.. run schedule function blue:tr/effects/dune/sandstorm/loop 1t