tp @s ^ ^ ^-1 ~ ~
tag @s remove blue.tr.temp
data modify entity @s teleport_duration set value 1
scoreboard players operation @s blue.id = #.link blue.id