tag @s remove blue.tr.shaper.absorption
effect clear @s absorption