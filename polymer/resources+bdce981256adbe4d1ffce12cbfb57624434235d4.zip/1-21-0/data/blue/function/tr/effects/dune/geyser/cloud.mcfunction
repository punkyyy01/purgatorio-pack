scoreboard players operation #.link blue.id = @s blue.id
execute unless entity @s[tag=blue.tr.activate] if entity @e[tag=blue.tr.dune.block,predicate=blue:shared/id_link,dy=3,limit=1,type=falling_block] run tag @s add blue.tr.activate
execute if entity @s[tag=blue.tr.activate] unless score @s blue.misc matches 1.. unless entity @e[tag=blue.tr.dune.block,predicate=blue:shared/id_link,dy=10,limit=1,type=falling_block] positioned ~0.5 ~ ~0.5 run function blue:tr/effects/dune/geyser/create
execute if block ~ ~ ~ sand run return fail
execute positioned ~0.5 ~ ~0.5 as @e[distance=..0.15,tag=!smithed.entity,limit=1,type=falling_block] align xz run function blue:tr/effects/dune/raisure/wall
kill