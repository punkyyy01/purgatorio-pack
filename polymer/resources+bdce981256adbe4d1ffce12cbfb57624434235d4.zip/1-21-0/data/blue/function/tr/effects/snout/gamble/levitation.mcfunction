title @s actionbar {"translate":"effect.minecraft.levitation","color":"gray"}
playsound block.shulker_box.open player @a[distance=..40] ~ ~ ~ 1.5 0.5
particle end_rod ~ ~4 ~ 0.2 3 0.2 0.02 32
effect give @s levitation 9 0 true