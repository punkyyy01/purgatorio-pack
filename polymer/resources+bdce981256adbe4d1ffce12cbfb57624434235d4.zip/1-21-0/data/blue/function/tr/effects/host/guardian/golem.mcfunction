schedule function blue:tr/effects/host/guardian/loop 2t
scoreboard players operation #.link blue.id = @s blue.id
execute store success score #.temp blue.misc run advancement revoke @a[scores={blue.tr.current_trim=4},predicate=blue:shared/id_link,limit=1] only blue:tr/tags heavy_hit
execute if score #.temp blue.misc matches 1 run scoreboard players add @a[scores={blue.tr.current_trim=4},predicate=blue:shared/id_link,limit=1] blue.tr.secondary_data 1
execute as @a[scores={blue.tr.current_trim=4,blue.tr.secondary_data=2..},predicate=blue:shared/id_link,limit=1] at @s run function blue:tr/effects/host/sacrifice
scoreboard players add @s blue.misc 1
execute unless score @s blue.misc matches 200.. run return fail
playsound entity.iron_golem.death player @a[distance=..40] ~ ~ ~ 1.2 2
particle damage_indicator ~ ~1 ~ 0.6 1 0.6 0.1 24
tp ~ -128 ~
data merge entity @s {DeathTime:20s,Health:0f}