title @s actionbar {"translate":"blue.tr.gamble.throwing","fallback":"Throwing LVL.%s","color":"gray","with":["3"]}
schedule function blue:tr/effects/snout/gamble/loop 1t
scoreboard players set @s blue.tr.primary_data 800
playsound entity.witch.throw player @a[distance=..40] ~ ~ ~ 1.5 0.5