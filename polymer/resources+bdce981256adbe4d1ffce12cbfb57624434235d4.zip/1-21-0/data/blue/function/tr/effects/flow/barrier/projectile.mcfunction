tag @s add blue.tr.checked
execute if function blue:tr/effects/flow/barrier/own run return run execute if entity @s[type=wind_charge] if function blue:tr/effects/flow/air run function blue:tr/effects/flow/barrier/boost
execute unless entity @s[type=!wind_charge,type=!breeze_wind_charge] run return run function blue:tr/effects/flow/barrier/wind
data modify storage blue:trims temp.flow_Motion set from entity @s Motion
execute store result storage blue:trims temp.Motion[0] double -0.125 run data get storage blue:trims temp.flow_Motion[0]
execute store result storage blue:trims temp.Motion[1] double -0.125 run data get storage blue:trims temp.flow_Motion[1]
execute store result storage blue:trims temp.Motion[2] double -0.125 run data get storage blue:trims temp.flow_Motion[2]
execute if score @a[tag=blue.tr.current_tick,distance=..9,limit=1] blue.tr.primary_data matches 1.. run function blue:tr/effects/flow/barrage/deflect
data modify entity @s Motion set from storage blue:trims temp.Motion
playsound entity.breeze.deflect player @a[distance=..32]
particle cloud