execute if score @s blue.id = #.link blue.id run return run execute positioned ~ ~0.5 ~ if score #.temp blue.misc matches 0 run function blue:tr/effects/dune/sandstorm/create
execute at @a[scores={blue.tr.current_trim=2},predicate=blue:shared/id_link,limit=1] if biome ~ ~ ~ #blue:shared/sandy run scoreboard players add #.temp0 blue.misc 100
execute if block ~0.5 ~0.5 ~0.5 cobweb run scoreboard players operation #.temp0 blue.misc /= #3 blue.misc
execute if score #.temp0 blue.misc matches ..50 run damage @s 22 blue:tr/raisure by @n[tag=blue.tr.dune.block,type=falling_block,distance=..4] from @a[scores={blue.tr.current_trim=2},predicate=blue:shared/id_link,limit=1]
execute if score #.temp0 blue.misc matches 51..100 run damage @s 26 blue:tr/raisure by @n[tag=blue.tr.dune.block,type=falling_block,distance=..4] from @a[scores={blue.tr.current_trim=2},predicate=blue:shared/id_link,limit=1]
execute if score #.temp0 blue.misc matches 101..150 run damage @s 30 blue:tr/raisure by @n[tag=blue.tr.dune.block,type=falling_block,distance=..4] from @a[scores={blue.tr.current_trim=2},predicate=blue:shared/id_link,limit=1]
execute if score #.temp0 blue.misc matches 151..200 run damage @s 34 blue:tr/raisure by @n[tag=blue.tr.dune.block,type=falling_block,distance=..4] from @a[scores={blue.tr.current_trim=2},predicate=blue:shared/id_link,limit=1]
execute if score #.temp0 blue.misc matches 201..250 run damage @s 38 blue:tr/raisure by @n[tag=blue.tr.dune.block,type=falling_block,distance=..4] from @a[scores={blue.tr.current_trim=2},predicate=blue:shared/id_link,limit=1]
execute if score #.temp0 blue.misc matches 251..300 run damage @s 42 blue:tr/raisure by @n[tag=blue.tr.dune.block,type=falling_block,distance=..4] from @a[scores={blue.tr.current_trim=2},predicate=blue:shared/id_link,limit=1]
execute if score #.temp0 blue.misc matches 301..350 run damage @s 46 blue:tr/raisure by @n[tag=blue.tr.dune.block,type=falling_block,distance=..4] from @a[scores={blue.tr.current_trim=2},predicate=blue:shared/id_link,limit=1]
execute if score #.temp0 blue.misc matches 351..400 run damage @s 50 blue:tr/raisure by @n[tag=blue.tr.dune.block,type=falling_block,distance=..4] from @a[scores={blue.tr.current_trim=2},predicate=blue:shared/id_link,limit=1]
execute if score #.temp0 blue.misc matches 401.. run damage @s 54 blue:tr/raisure by @n[tag=blue.tr.dune.block,type=falling_block,distance=..4] from @a[scores={blue.tr.current_trim=2},predicate=blue:shared/id_link,limit=1]
execute if score #.temp0 blue.misc matches 401.. run playsound block.suspicious_sand.break player @a[distance=..64] ~ ~ ~ 2 0.5
execute unless score #.temp0 blue.misc matches ..200 run effect give @s slowness 4 2 true
execute if score #.temp0 blue.misc matches ..200 run effect give @s slowness 2 1 true
scoreboard players set #.temp blue.misc -592