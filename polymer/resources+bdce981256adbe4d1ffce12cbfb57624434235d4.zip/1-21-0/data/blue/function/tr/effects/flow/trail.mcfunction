execute if entity @s[type=wind_charge] at @s run particle small_gust ~ ~ ~ 0.1 0.1 0.1 0 2 force
execute store result entity @s Air byte 1 run scoreboard players get #.20 blue.misc