tp @s ~ 0 ~
tp @s ~ ~ ~
scoreboard players reset #.temp blue.misc
execute if entity @s[gamemode=survival] run scoreboard players set #.temp blue.misc -1
execute if entity @s[gamemode=adventure] run scoreboard players set #.temp blue.misc -2
gamemode creative
tp @s ~ ~1000 ~
execute positioned ~ ~1000 ~ summon end_crystal run damage @s 1
execute positioned ~ ~1000 ~ summon end_crystal run damage @s 1
tp @s ~ ~1 ~
execute store result score @s blue.tr.schedule_context run schedule function blue:tr/effects/dune/raisure/give 34t append
execute if score #.temp blue.misc matches -1 run return run gamemode survival
execute if score #.temp blue.misc matches -2 run gamemode adventure