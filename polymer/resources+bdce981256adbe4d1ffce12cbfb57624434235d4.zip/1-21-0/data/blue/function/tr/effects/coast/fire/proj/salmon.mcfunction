tp ^ ^ ^1.5
kill @s[scores={blue.misc=10..}]
particle dolphin ~ ~ ~ 0.02 0.02 0.02 0 1 normal @a[scores={blue.particles=1..},distance=..64]
particle dolphin ^ ^ ^0.65 0.02 0.02 0.02 0 1 normal @a[scores={blue.particles=2..},distance=..64]
execute store success score #.temp blue.misc if entity @s[tag=blue.tr.coast.pierced]
execute positioned ~-0.5 ~-0.5 ~-0.5 as @n[type=!#blue:shared/peaceful,tag=!blue.tr.current_tick,tag=!blue.tr.salmon_cooldown,dx=0] positioned ~0.5 ~0.5 ~0.5 run function blue:tr/effects/coast/fire/proj/salmon_hit
execute if score #.temp blue.misc matches -99 run tag @s add blue.tr.coast.pierced
execute if block ~ ~ ~ #blue:shared/passable if block ^ ^ ^0.3 #blue:shared/passable if block ^ ^ ^0.6 #blue:shared/passable if block ^ ^ ^0.9 #blue:shared/passable if block ^ ^ ^1.2 #blue:shared/passable run return fail
playsound item.bucket.fill player @a[distance=..20] ~ ~ ~ 0.9 2
particle splash ^ ^ ^-0.2 0.1 0.1 0.1 0 12
execute unless dimension the_nether run particle splash ^ ^ ^-0.2 0.1 0.1 0.1 0 20
kill