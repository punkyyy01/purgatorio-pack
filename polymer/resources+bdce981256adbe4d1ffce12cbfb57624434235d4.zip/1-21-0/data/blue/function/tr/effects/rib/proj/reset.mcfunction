tag @s remove blue.tr.sneaking
scoreboard players operation #.link blue.id = @s blue.id
kill @e[tag=blue.tr.rib.hitbox,predicate=blue:shared/id_link,type=interaction]