execute store success score #.temp blue.misc run scoreboard players remove @e[scores={blue.tr.salmon_cooldown=1..}] blue.tr.salmon_cooldown 1
tag @e[tag=blue.tr.salmon_cooldown,scores={blue.tr.salmon_cooldown=0}] remove blue.tr.salmon_cooldown
execute if score #.temp blue.misc matches 1 run schedule function blue:tr/effects/coast/fire/proj/salmon_cooldown 1t