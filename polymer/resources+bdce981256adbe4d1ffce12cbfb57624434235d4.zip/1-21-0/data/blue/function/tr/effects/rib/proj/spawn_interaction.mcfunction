data merge entity @s {Tags:["blue.tr.rib.hitbox"],width:0.4,height:0.5,response:1b}
scoreboard players operation @s blue.id = #.link blue.id