particle effect ~ ~-0.1 ~ 0.2 0.35 0.2 1 1
scoreboard players add @s blue.tr.primary_data 2
scoreboard players remove @s[scores={blue.tr.primary_data=1..,blue.tr.primary_cooldown=1..}] blue.tr.primary_data 1
execute if items entity @s weapon experience_bottle run scoreboard players set @s blue.tr.primary_data 2
execute if score @s blue.tr.ambient matches 7.. run scoreboard players set @s blue.tr.ambient 1
execute store success score #.temp blue.misc if biome ~ ~ ~ #blue:shared/old_growth
execute if score @s blue.tr.primary_data matches 48.. run return run function blue:tr/effects/raiser/piercer/fire
execute if score @s blue.tr.ambient matches 1 positioned ~ ~0.1 ~ if items entity @s weapon experience_bottle run return run function blue:tr/effects/raiser/piercer/spray
execute if score @s blue.tr.primary_data matches 36 run return run playsound block.enchantment_table.use player @a[distance=..14] ~ ~ ~ 1.5 1.1
execute if score @s blue.tr.primary_data matches 12 run return run playsound block.enchantment_table.use player @a[distance=..12] ~ ~ ~ 1.3 0.6
execute if score @s blue.tr.primary_data matches 1 if entity @s[advancements={blue:tr/tags={tutorial_piercer=false}}] run advancement grant @s only blue:tr/tags tutorial_piercer