execute unless entity @s[tag=blue.tr.ground] run return run function blue:tr/effects/snout/gamble/item/ground
scoreboard players remove @s[tag=blue.tr.gamble.withdrawal,scores={blue.misc=..49},predicate=!blue:r/40c] blue.misc 1
execute store result score #.temp0 blue.misc run scoreboard players add @s blue.misc 1
execute if score #.temp0 blue.misc matches ..8 run return run playsound block.lever.click player @a[distance=..20] ~ ~ ~ 0.4 1.6
execute if score #.temp0 blue.misc matches 9..16 run return run playsound block.lever.click player @a[distance=..20] ~ ~ ~ 0.4 1.5
execute if score #.temp0 blue.misc matches 17..24 run return run playsound block.lever.click player @a[distance=..20] ~ ~ ~ 0.4 1.4
execute if score #.temp0 blue.misc matches 25..32 run return run playsound block.lever.click player @a[distance=..20] ~ ~ ~ 0.4 1.3
execute if score #.temp0 blue.misc matches 32..40 run return run playsound block.lever.click player @a[distance=..20] ~ ~ ~ 0.5 1.2
execute if score #.temp0 blue.misc matches 41..48 run return run playsound block.lever.click player @a[distance=..20] ~ ~ ~ 0.6 1.1
execute if score #.temp0 blue.misc matches 50 run function blue:tr/effects/snout/gamble/item/update
execute unless score #.temp0 blue.misc matches 80 run return fail
scoreboard players operation #.temp blue.misc = @s blue.tr.died
function blue:tr/delayed/cmd/trust/define/main
execute if score @s blue.tr.combat matches 1 unless entity @s[tag=blue.tr.gamble.none] on origin run function blue:tr/effects/snout/gamble/item/good
execute if score @s blue.tr.combat matches 0 unless entity @s[tag=blue.tr.gamble.none] on origin run function blue:tr/effects/snout/gamble/item/bad
tag @a[tag=blue.tr.trusted_player] remove blue.tr.trusted_player
execute on origin run tag @s remove blue.tr.current_tick
execute if predicate blue:r/2c unless entity @s[tag=blue.tr.gamble.none] on origin run function blue:tr/effects/snout/gamble/tunes
execute on passengers run kill
kill