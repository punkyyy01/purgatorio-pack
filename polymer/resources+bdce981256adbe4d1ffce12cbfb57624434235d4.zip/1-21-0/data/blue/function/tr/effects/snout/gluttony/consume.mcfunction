execute store success score #.temp blue.misc if entity @s[advancements={blue:tr/ability/gluttony={enchanted_golden_apple=true}}]
execute store success score #.temp0 blue.misc if entity @s[advancements={blue:tr/ability/gluttony={golden_apple=true}}]
advancement revoke @s only blue:tr/ability/gluttony
execute if score #.temp blue.misc matches 1 run function blue:tr/effects/snout/gluttony/enchanted
execute if score #.temp0 blue.misc matches 1 run effect give @s resistance 6 0
playsound entity.generic.eat player @a[distance=..40] ~ ~ ~ 1.25 0.6
effect give @s saturation 2 0 true