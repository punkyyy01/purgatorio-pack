scoreboard players remove #.temp blue.misc 1
execute unless block ~ ~ ~ #blue:shared/passable run return run function blue:tr/effects/sentry/ballista/collide
execute unless block ^ ^ ^0.375 #blue:shared/passable run return run function blue:tr/effects/sentry/ballista/collide
execute positioned ~-0.5 ~-0.5 ~-0.5 as @e[type=!#blue:shared/peaceful,dx=0] if score #.temp blue.misc matches 1.. at @s run function blue:tr/effects/sentry/ballista/was_shot
execute positioned ^ ^ ^0.75 if score #.temp blue.misc matches 1.. run function blue:tr/effects/sentry/ballista/cast
execute if entity @s[distance=..9] run return run particle dust{color:[1f,0f,0f],scale:0.5}
scoreboard players add #.temp1 blue.misc 1
execute if score #.temp1 blue.misc matches 1..8 run function blue:tr/effects/sentry/ballista/low
execute if score #.temp1 blue.misc matches 9.. run function blue:tr/effects/sentry/ballista/high
scoreboard players add #.temp1 blue.misc 1
execute if score #.temp1 blue.misc matches 1..8 positioned ^ ^ ^-0.375 run function blue:tr/effects/sentry/ballista/low
execute if score #.temp1 blue.misc matches 9.. positioned ^ ^ ^-0.375 run function blue:tr/effects/sentry/ballista/high