execute if items entity @s contents #blue:tr/undermine positioned ^ ^-0.5 ^-1.5 if entity @a[distance=..0.01,tag=blue.tr.current_tick,predicate=blue:shared/is_sneaking,limit=1] at @s if block ~ ~-1 ~ #blue:trims/undermine run return run fill ~ ~-1 ~ ~ ~-1 ~ air destroy
execute unless items entity @s contents tnt[count=1] run return fail
execute on origin if entity @s[tag=blue.tr.current_tick] run scoreboard players set #.temp blue.misc -5199
execute unless score #.temp blue.misc matches -5199 run return fail
scoreboard players reset #.temp blue.misc
execute if score #.shaper.throw_cooldown blue.config matches -1 run function blue:tr/inv/item/quick_return
execute if score #.shaper.throw_cooldown blue.config matches -1 on origin run return run title @s actionbar [{"translate":"blue.tr.not-so_controlled_demolition_name","fallback":"Not-so Controlled Demolition","color":"#8F8F8F"},{"translate":"blue.tr.is_disabled","fallback":" is disabled on this server","color":"gray"}]
execute on origin run scoreboard players operation #.temp blue.tr.primary_cooldown = @s blue.tr.primary_cooldown
execute if score #.temp blue.tr.primary_cooldown matches 1.. on origin run function blue:tr/effects/display_primary_cooldown
execute if score #.temp blue.tr.primary_cooldown matches 1.. run return run function blue:tr/inv/item/quick_return
execute on origin at @s anchored eyes positioned ^ ^ ^0.5 positioned ~ ~-0.5 ~ run function blue:tr/effects/shaper/tnt/throw
execute if score #.difficulty blue.misc matches ..2 if score #.temp blue.misc matches -1 store success score #.temp blue.misc run kill @s[predicate=!blue:r/20c]
execute if score #.difficulty blue.misc matches 3.. if score #.temp blue.misc matches -1 run kill
execute if score #.temp blue.misc matches 0 run function blue:tr/inv/item/quick_return
execute on origin run scoreboard players operation @s blue.tr.primary_cooldown = #.shaper.throw_cooldown blue.config