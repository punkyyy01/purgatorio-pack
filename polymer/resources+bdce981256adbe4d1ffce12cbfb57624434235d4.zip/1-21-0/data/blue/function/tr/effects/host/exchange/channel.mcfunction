execute if score @s blue.tr.primary_cooldown matches 1.. run function blue:tr/effects/display_primary_cooldown
execute if score @s blue.tr.primary_cooldown matches 1.. run return 0
scoreboard players reset #.temp blue.misc
tag @s add blue.tr.host.channeling
execute anchored eyes positioned ^ ^ ^0.5 run function blue:tr/effects/host/exchange/cast
execute unless score #.temp blue.misc matches 1.. run scoreboard players reset @s blue.tr.primary_data
execute if score @s blue.tr.primary_data matches 30.. if score #.temp blue.misc matches 1.. run particle ash ~ ~1.3 ~ 0.3 0.4 0.3 0 6
execute if score @s blue.tr.primary_data matches 75.. if score #.temp blue.misc matches 1.. run particle ash ~ ~1.3 ~ 0.3 0.4 0.3 0 10
execute unless score @s blue.tr.primary_data matches 105.. run return fail
execute unless score #.temp blue.misc matches 1.. run return run function blue:tr/effects/host/exchange/cancel
playsound entity.illusioner.mirror_move player @a[distance=..20] ~ ~ ~ 0.75 2
scoreboard players set @s blue.tr.primary_cooldown 140
tag @s remove blue.tr.host.channeling
scoreboard players reset @s blue.tr.primary_data
effect give @s invisibility 4 0 true
particle ash ~ ~1 ~ 0.35 0.5 0.35 0 100
execute at b163102f-0-b-0-1 run tp @s ~ ~ ~
kill b163102f-0-b-0-1