execute if score #.20 blue.misc matches 6 as @a[scores={blue.tr.fear=1..},gamemode=!spectator] run function blue:tr/effects/eye/fear/player
execute as @a[scores={blue.tr.used_pearl=1..}] run function blue:tr/effects/eye/disfigure/curse
execute store success score #.eye.two_tick blue.misc unless score #.eye.two_tick blue.misc matches 1
execute unless score #.eye.disfigure_time blue.misc matches 1.. run return run execute unless score #.20 blue.misc matches 2..10 unless score #.20 blue.misc matches 12.. as @a[scores={blue.tr.current_trim=3},tag=!blue.trim_disabled,gamemode=!spectator] at @s anchored eyes positioned ^ ^ ^2.5 run function blue:tr/effects/eye/disfigure/player
scoreboard players remove #.eye.disfigure_time blue.misc 1
execute as @e[type=#blue:tr/disfigurable] run function blue:tr/effects/eye/disfigure/reduction
execute as @a[scores={blue.tr.current_trim=3},tag=!blue.trim_disabled,gamemode=!spectator] at @s anchored eyes positioned ^ ^ ^2.5 run function blue:tr/effects/eye/disfigure/player