playsound entity.tropical_fish.hurt player @a[distance=..32]
execute store result storage blue:trims temp.id int 1 run scoreboard players get #.link blue.id
execute if entity @s[type=player] run function blue:tr/delayed/cmd/trust/define/player
damage @s[tag=!blue.tr.trusted_player] 3 blue:tr/fish by @a[tag=blue.tr.current_tick,limit=1]
execute if score #.temp blue.misc matches 0 run playsound entity.witch.drink player @a[distance=..20] ~ ~ ~ 1 2
execute if score #.temp blue.misc matches 1 run playsound entity.witch.drink player @a[distance=..40] ~ ~ ~ 2 1
execute if score #.temp blue.misc matches 0 run particle instant_effect ^ ^ ^-0.25 0.1 0.2 0.1 0.5 20
execute if score #.temp blue.misc matches 1 run particle effect ^ ^ ^-0.25 0.1 0.2 0.1 0.5 20
execute if entity @s[tag=blue.tr.trusted_player] store success score #.temp blue.misc if score #.temp blue.misc matches 0
tag @a[tag=blue.tr.trusted_player] remove blue.tr.trusted_player
execute if score #.temp blue.misc matches 0 run function blue:tr/effects/coast/fire/proj/tropical/negative
execute if score #.temp blue.misc matches 1 run function blue:tr/effects/coast/fire/proj/tropical/positive
scoreboard players set #.temp blue.misc -99