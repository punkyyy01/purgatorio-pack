advancement revoke @s only blue:tr/ability/attunement req
execute on attacker if score @s blue.tr.current_trim matches 5 run scoreboard players set #.attunement blue.misc 1
execute if score #.attunement blue.misc matches 1 on attacker run xp add @s 7 points
execute if score #.attunement blue.misc matches 1 run xp add @s -7 points
scoreboard players reset #.attunement blue.misc