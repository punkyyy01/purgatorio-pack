tag @s remove blue.tr.temp
scoreboard players operation @s blue.id = #.link blue.id
execute if score #.temp blue.misc matches 1 store result storage blue:trims temp.float float 0.1 run random value -200..200
execute if score #.temp blue.misc matches 1 store result storage blue:trims temp.f2 float 0.1 run random value -200..200
execute if score #.temp blue.misc matches 0 store result storage blue:trims temp.float float 0.1 run random value -150..150
execute if score #.temp blue.misc matches 0 store result storage blue:trims temp.f2 float 0.1 run random value -150..150
function blue:tr/effects/coast/fire/rot-m with storage blue:trims temp
execute if score #.temp0 blue.misc matches -597 unless dimension the_nether run scoreboard players set @s blue.misc -1
data modify entity @s teleport_duration set value 1