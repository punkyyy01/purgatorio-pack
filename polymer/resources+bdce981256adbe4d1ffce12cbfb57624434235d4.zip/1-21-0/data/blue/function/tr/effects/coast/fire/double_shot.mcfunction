scoreboard players add @s blue.tr.fourth_data 1
execute unless score @s blue.tr.fourth_data matches 112.. unless score @s blue.tr.fourth_data matches 215.. unless score @s blue.tr.fourth_data matches 318.. run return fail
scoreboard players operation #.link blue.id = @s blue.id
execute if score @s blue.tr.fourth_data matches 112 at @s anchored eyes positioned ^ ^ ^0.5 summon item_display run function blue:tr/effects/coast/fire/cod
execute if score @s blue.tr.fourth_data matches 215 at @s anchored eyes positioned ^ ^ ^0.5 summon item_display run function blue:tr/effects/coast/fire/salmon
execute if score @s blue.tr.fourth_data matches 318 at @s anchored eyes positioned ^ ^ ^0.5 summon item_display run function blue:tr/effects/coast/fire/tropical
scoreboard players reset @s blue.tr.fourth_data