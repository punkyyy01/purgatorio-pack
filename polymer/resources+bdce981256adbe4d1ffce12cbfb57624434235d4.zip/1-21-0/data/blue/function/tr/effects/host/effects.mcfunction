scoreboard players reset #.temp blue.misc
execute as @e[tag=!smithed.strict,distance=..16,type=iron_golem] run function blue:tr/effects/host/morale
execute as @e[tag=!smithed.strict,distance=..16,type=villager] run function blue:tr/effects/host/morale
execute if score #.temp blue.misc matches -466 store success score #.temp blue.misc run effect give @s resistance 4 0 true