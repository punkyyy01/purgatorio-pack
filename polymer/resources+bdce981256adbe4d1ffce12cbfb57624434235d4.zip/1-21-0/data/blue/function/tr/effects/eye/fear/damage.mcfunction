function blue:tr/effects/flash {args:" ~ ~1 ~ 0.2 0.2 0.2 0 1 force @s[scores={blue.particles=1..}]"}
playsound entity.player.attack.crit player @s ^ ^ ^2 1.5 1
kill b163102f-0-6-0-1
summon marker ~ ~ ~ {UUID:[I;-1318907857,6,0,1]}
damage @s 6 blue:tr/scare by b163102f-0-6-0-1 from @p[scores={blue.tr.current_trim=3}]
kill b163102f-0-6-0-1