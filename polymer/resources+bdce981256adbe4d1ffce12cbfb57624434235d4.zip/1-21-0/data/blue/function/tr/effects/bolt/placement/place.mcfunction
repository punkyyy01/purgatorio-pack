$fill ~ ~ ~ ~ ~ ~ $(item) destroy
schedule function blue:tr/effects/bolt/placement/loop 1t
particle electric_spark ~ ~ ~ 0.35 0.35 0.35 0.1 18
execute as @e[tag=blue.tr.bolt.block,predicate=blue:shared/id_link,limit=1,type=marker] facing entity @s feet run return run function blue:tr/effects/bolt/conduct/start
tag @s add blue.tr.hit
summon marker ~ ~ ~ {Tags:["smithed.entity","smithed.strict","blue.tr.bolt.block"]}
execute as @e[tag=blue.tr.bolt.block,distance=..1,type=marker] unless score @s blue.id matches 1.. run scoreboard players operation @s blue.id = #.link blue.id
execute positioned ~ ~-0.5 ~ facing entity @s feet run function blue:tr/effects/bolt/conduct/player/start