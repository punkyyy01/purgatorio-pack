scoreboard players add @s blue.tr.ambient 1
execute if score @s blue.tr.ambient matches 4 run particle item{item:raw_gold_block} ~ ~0.8 ~ 0.2 0.3 0.2 0.01 1 normal @a[scores={blue.particles=2..},distance=..64]
execute if score @s blue.tr.ambient matches 7.. store success score @s blue.tr.ambient run particle item{item:raw_gold_block} ~ ~0.8 ~ 0.2 0.3 0.2 0.01 1 normal @a[scores={blue.particles=1..},distance=..64]
execute as @e[tag=!blue.tr.checked,distance=..8,type=item] run function blue:tr/effects/snout/gamble/item/main
execute unless score #.20 blue.misc matches 13 run return fail
execute if items entity @s weapon #blue:tr/gold_item run effect give @s haste 2 2 true
execute if predicate blue:shared/in_bastion run effect give @s fire_resistance 12 0 true
execute as @e[distance=..7,predicate=blue:tr/not_toddler_thief,type=piglin] run function blue:tr/effects/snout/piglin