scoreboard players add @s blue.tr.primary_data 1
execute as @e[tag=!blue.tr.checked,distance=..6,type=item] if items entity @s contents wind_charge run function blue:tr/inv/item/quick_return
execute if score @s blue.tr.primary_data matches 2 run function blue:tr/effects/flow/barrage/start
execute if score @s blue.tr.primary_data matches 2 run attribute @s generic.gravity modifier remove blue:tr.trim
execute if score @s blue.tr.primary_data matches 2 run attribute @s generic.gravity modifier add blue:tr.trim -0.0625 add_value
execute if score @s blue.tr.primary_data matches 11..43 run particle cloud ~ ~0.25 ~ 0.2 0 0.2 0 1
execute if score @s blue.tr.primary_data matches 39 run attribute @s generic.gravity modifier remove blue:tr.trim
execute if score @s blue.tr.primary_data matches 39 run attribute @s generic.gravity modifier add blue:tr.trim -0.08 add_value
execute if score @s blue.tr.primary_data matches 63 run tp @s ~ 100 ~
execute if score @s blue.tr.primary_data matches 63 run tp @s ~ ~ ~
execute if score @s blue.tr.primary_data matches 63.. run particle poof ~ ~-0.25 ~ 0.2 0 0.2 2 3
execute if score @s blue.tr.primary_data matches 62.. if predicate blue:tr/flow_bonus anchored eyes run function blue:tr/effects/flow/barrage/spawn
execute if score @s blue.tr.primary_data matches 62.. if predicate blue:shared/periodic_10 anchored eyes run function blue:tr/effects/flow/barrage/spawn
particle small_gust ~ ~-3 ~ 0.2 0 0.2 0 1
execute unless block ~ ~ ~ #air unless block ~ ~-1 ~ #air unless block ~ ~-2 ~ #air unless block ~ ~-3 ~ #air run scoreboard players operation @s blue.tr.primary_data = #.flow.wind_barrage_duration blue.config
execute unless score @s blue.tr.primary_data >= #.flow.wind_barrage_duration blue.config run return fail
scoreboard players reset @s blue.tr.primary_data
effect give @s slow_falling 3 0 true