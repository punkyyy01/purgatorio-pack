title @s actionbar {"translate":"blue.tr.gamble.flim_flam","fallback":"Flim Flam","color":"gray"}
execute unless entity b163102f-0-0-0-100000000 run function blue:shared/load
item replace entity b163102f-0-0-0-100000000 weapon from entity @s weapon.offhand
item replace entity @s weapon.offhand from entity @s weapon
item replace entity @s weapon from entity b163102f-0-0-0-100000000 weapon