execute unless score @s blue.tr.secondary_data matches 2.. run return run scoreboard players add @s blue.tr.secondary_data 1
scoreboard players reset @s blue.tr.secondary_data
scoreboard players operation #.link blue.id = @s blue.id
execute store success score #.temp blue.misc run damage @e[tag=blue.tr.host.guardian,predicate=blue:shared/id_link,type=iron_golem,distance=..20,limit=1] 20 blue:tr/sacrifice
execute if score #.temp blue.misc matches 1 at @e[tag=blue.tr.host.guardian,predicate=blue:shared/id_link,type=iron_golem,distance=..20,limit=1] run return run particle damage_indicator ~ ~1 ~ 0.6 1 0.6 0.1 5
particle damage_indicator ~ ~0.5 ~ 0.4 0.4 0.4 0.4 2
damage @s 2 blue:tr/sacrifice