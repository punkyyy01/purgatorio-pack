execute store result storage blue:trims temp.Motion[0] double -0.75 run data get storage blue:trims temp.flow_Motion[0]
execute store result storage blue:trims temp.Motion[1] double -0.75 run data get storage blue:trims temp.flow_Motion[1]
execute store result storage blue:trims temp.Motion[2] double -0.75 run data get storage blue:trims temp.flow_Motion[2]
scoreboard players add @a[tag=blue.tr.current_tick,distance=..9,limit=1] blue.tr.primary_data 5