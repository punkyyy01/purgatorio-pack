data modify storage blue:trims temp.effects set from entity @s active_effects[{id:"minecraft:hero_of_the_village"}]
effect clear @s hero_of_the_village
execute store result score #.temp blue.misc run data get storage blue:trims temp.effects.duration
execute store result score #.temp0 blue.misc run data get storage blue:trims temp.effects.amplifier
execute if score @s blue.tr.primary_cooldown matches 140 run scoreboard players remove #.temp blue.misc 18000
execute if score #.temp blue.misc matches ..30 run scoreboard players remove #.temp0 blue.misc 1
execute if score #.temp0 blue.misc matches ..-1 run return run data remove storage blue:trims temp.effects
execute if score #.temp blue.misc matches ..30 run scoreboard players add #.temp blue.misc 24000
execute store result storage blue:trims temp.effects.duration int 0.05 run scoreboard players get #.temp blue.misc
execute store result storage blue:trims temp.effects.amplifier int 1 run scoreboard players get #.temp0 blue.misc
function blue:tr/effects/sentry/macro with storage blue:trims temp.effects
data remove storage blue:trims temp.effects