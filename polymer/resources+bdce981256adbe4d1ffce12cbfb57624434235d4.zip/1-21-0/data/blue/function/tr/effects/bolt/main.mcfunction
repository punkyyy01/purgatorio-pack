execute store success score @s blue.tr.ambient unless score @s blue.tr.ambient matches 1
execute if score @s blue.tr.ambient matches 0 run particle dust{color:[0.8f,0.5f,0.2f],scale:0.6f} ~ ~0.7 ~ 0.3 0.3 0.3 0 1 normal @a[scores={blue.particles=1..},distance=..64]
execute if score @s blue.tr.ambient matches 1 run particle dust{color:[0.8f,0.5f,0.2f],scale:0.6f} ~ ~0.7 ~ 0.3 0.3 0.3 0 1 normal @a[scores={blue.particles=2..},distance=..64]
execute as @n[distance=..4,tag=!blue.tr.checked,predicate=blue:tr/copper,type=item] if function blue:tr/effects/bolt/placement/owner run function blue:tr/effects/bolt/placement/item with storage blue:trims temp
execute if score #.20 blue.misc matches 5 run function blue:tr/effects/bolt/charge
execute unless predicate blue:tr/overcharge run return fail
particle electric_spark ~ ~1 ~ 0.25 0.35 0.25 0.1 2
execute store result score #.temp blue.misc run random value 1..8
execute unless score #.temp blue.misc matches 8 run return fail
playsound entity.firework_rocket.twinkle player @a[distance=..20] ~ ~ ~ 0.4 2
particle electric_spark ~ ~1 ~ 0.3 0.4 0.3 0.8 10
particle wax_off ~ ~1 ~ 0.3 0.4 0.3 0 1
execute if predicate {"condition":"entity_properties","type":"entity_properties","entity":"this","predicate":{"effects":{"glowing":{"amplifier":44},"speed":{},"haste":{}}}} run return run execute as @a[distance=0.01..3,gamemode=!spectator,gamemode=!creative] at @s run function blue:tr/effects/bolt/zap
execute as @a[distance=0.01..1.8,gamemode=!spectator,gamemode=!creative] at @s run function blue:tr/effects/bolt/zap