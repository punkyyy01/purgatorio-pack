tag @s add blue.tr.current_tick
execute if score @s blue.tr.primary_cooldown matches 1.. run function blue:tr/effects/primary_cooldown
execute if score @s blue.tr.secondary_cooldown matches 1.. run function blue:tr/effects/secondary_cooldown
execute if entity @s[tag=blue.tr.trim.coast] run function blue:tr/effects/coast/main
execute if entity @s[tag=blue.tr.trim.dune] run function blue:tr/effects/dune/main
execute if entity @s[tag=blue.tr.trim.eye] run function blue:tr/effects/eye/main
execute if entity @s[tag=blue.tr.trim.host] run function blue:tr/effects/host/main
execute if entity @s[tag=blue.tr.trim.raiser] run function blue:tr/effects/raiser/main
execute if entity @s[tag=blue.tr.trim.rib] run function blue:tr/effects/rib/main
tag @s remove blue.tr.current_tick