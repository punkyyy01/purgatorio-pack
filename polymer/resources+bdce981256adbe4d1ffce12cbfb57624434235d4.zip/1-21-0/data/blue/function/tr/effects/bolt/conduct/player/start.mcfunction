scoreboard players set #.bolt.vertical blue.misc 0
scoreboard players set #.bolt.horizontal blue.misc 0
scoreboard players set #.cast blue.misc 1
playsound entity.firework_rocket.twinkle player @a[distance=..8] ~ ~ ~ 0.75 1.25
playsound entity.firework_rocket.twinkle player @a[distance=8.01..24] ~ ~ ~ 1.5 1.25
execute store result score #.temp blue.misc run random value 1..4
function blue:tr/delayed/cmd/trust/define/main
tag @a[tag=blue.tr.trusted_player,predicate=!blue:shared/id_link] add blue.tr.hit
tag @a[tag=blue.tr.trusted_player] remove blue.tr.trusted_player
execute if score #.temp blue.misc matches 1 rotated ~-50 ~ positioned ^ ^ ^0.2 rotated ~50 ~ run function blue:tr/effects/bolt/conduct/player/h
execute if score #.temp blue.misc matches 2 rotated ~50 ~ positioned ^ ^ ^0.2 rotated ~-50 ~ run function blue:tr/effects/bolt/conduct/player/-h
execute if score #.temp blue.misc matches 3 rotated ~ ~-50 positioned ^ ^ ^0.2 rotated ~ ~50 run function blue:tr/effects/bolt/conduct/player/v
execute if score #.temp blue.misc matches 4 rotated ~ ~50 positioned ^ ^ ^0.2 rotated ~ ~-50 run function blue:tr/effects/bolt/conduct/player/-v
tag @a[tag=blue.tr.hit] remove blue.tr.hit