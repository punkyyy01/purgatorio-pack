playsound entity.breeze.shoot player @a[distance=..32]
scoreboard players set #.tr.entity_exists blue.misc 1
data modify storage blue:trims merge.boost.Motion set from entity @s Motion
kill
execute on origin at @s anchored eyes positioned ^ ^ ^1 run function blue:tr/effects/flow/barrier/positioned