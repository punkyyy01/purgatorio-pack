execute store success score #.temp blue.misc if entity @s[advancements={blue:tr/ability/harpoon={kill=true}}]
advancement revoke @s only blue:tr/ability/harpoon
tag @s add blue.tr.current_tick
execute if score #.temp blue.misc matches 1 run tag @s add blue.tr.coast.propel
execute if score #.temp blue.misc matches 0 as @e[tag=!blue.tr.coast.checked,nbt={DealtDamage:1b,inGround:0b},type=trident] run function blue:tr/effects/coast/harpoon/find
tag @s remove blue.tr.current_tick