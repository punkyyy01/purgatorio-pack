execute summon breeze_wind_charge run data modify entity @s {} merge from storage blue:trims merge.boost
execute if entity @s[advancements={blue:tr/ability/flow_gust=false}] run return fail
execute if score @s blue.tr.primary_data matches 1.. run return fail
advancement revoke @s only blue:tr/ability/flow_gust
execute if score #.flow.gust_strength blue.config matches ..0 run return fail
scoreboard players operation #.temp blue.misc = #.flow.gust_strength blue.config
execute if score #.temp blue.misc matches 3.. if entity @s[x_rotation=70..90] run scoreboard players remove #.flow.gust_strength blue.config 3
execute store result storage blue:trims temp.int int 1 run scoreboard players get #.flow.gust_strength blue.config
execute unless predicate blue:shared/can_see_sky store result storage blue:trims temp.int int 0.8 run scoreboard players get #.flow.gust_strength blue.config
execute if score #.temp blue.misc matches 3.. if entity @s[x_rotation=70..90] run scoreboard players add #.flow.gust_strength blue.config 3
summon armor_stand ~ ~ ~ {UUID:[I;-1318907857,16,0,1],Marker:1b,Invisible:1b}
loot replace entity b163102f-0-10-0-1 armor.head loot blue:tr/z/gust
execute summon wind_charge run data modify entity @s {} merge from storage blue:trims merge.boost