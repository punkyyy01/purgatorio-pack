execute at @e[tag=blue.tr.silence.vortex,scores={blue.misc=44..},type=marker] run stopsound @a[distance=..24] hostile entity.creeper.primed
execute at @e[tag=blue.tr.silence.vortex,scores={blue.misc=44..},type=marker] run stopsound @a[distance=..24] block entity.generic.explode
kill @e[tag=blue.tr.silence.vortex,scores={blue.misc=44..},type=marker]