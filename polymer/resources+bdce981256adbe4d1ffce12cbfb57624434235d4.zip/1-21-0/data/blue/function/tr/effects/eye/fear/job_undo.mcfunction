title @a[tag=blue.tr.eye.job,predicate=!blue:shared/has_blindness] reset
tag @a[tag=blue.tr.eye.job,predicate=!blue:shared/has_blindness] remove blue.tr.eye.job