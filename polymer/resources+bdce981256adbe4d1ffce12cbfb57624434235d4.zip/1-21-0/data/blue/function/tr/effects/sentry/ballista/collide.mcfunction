scoreboard players set #.temp blue.misc 0
particle enchanted_hit ~ ~0.5 ~ 0 0 0 0.5 64 force
playsound item.crossbow.hit player @a[distance=..20] ~ ~ ~ 1 0.5
playsound item.crossbow.hit player @a[distance=..20] ~ ~ ~ 1 0.5