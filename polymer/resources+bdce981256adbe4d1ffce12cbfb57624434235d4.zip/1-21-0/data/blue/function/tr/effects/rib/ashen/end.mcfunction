execute as @e[team=blue.tr.rib,type=!player,predicate=blue:shared/id_link] at @s run function blue:tr/effects/rib/ashen/kill
scoreboard players set @s blue.tr.secondary_cooldown 300
playsound entity.illusioner.cast_spell player @s ~ ~ ~ 2 1.5
team leave @s[team=blue.tr.rib]