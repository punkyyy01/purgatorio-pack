execute on origin run scoreboard players set @s blue.tr.primary_data 1
execute store result score #.temp blue.misc run data get entity @s Item.count
scoreboard players remove #.temp blue.misc 60
execute on origin run loot give @s loot blue:tr/z/barrage_refund
kill