$execute if entity @s[distance=..1.5] store result storage blue:trims temp.float float $(float) run scoreboard players set #.temp blue.misc 126
$execute if entity @s[distance=1.51..2.5] store result storage blue:trims temp.float float $(float) run scoreboard players set #.temp blue.misc 113
$execute if entity @s[distance=2.51..3.5] store result storage blue:trims temp.float float $(float) run scoreboard players set #.temp blue.misc 100
$execute if entity @s[distance=3.51..4.5] store result storage blue:trims temp.float float $(float) run scoreboard players set #.temp blue.misc 87
$execute if entity @s[distance=4.51..5.5] store result storage blue:trims temp.float float $(float) run scoreboard players set #.temp blue.misc 74
$execute if entity @s[distance=5.51..6.5] store result storage blue:trims temp.float float $(float) run scoreboard players set #.temp blue.misc 61
$execute if entity @s[distance=6.51..7.5] store result storage blue:trims temp.float float $(float) run scoreboard players set #.temp blue.misc 48
$execute if entity @s[distance=7.51..] store result storage blue:trims temp.float float $(float) run scoreboard players set #.temp blue.misc 35
function blue:tr/effects/silence/vortex/damage with storage blue:trims temp