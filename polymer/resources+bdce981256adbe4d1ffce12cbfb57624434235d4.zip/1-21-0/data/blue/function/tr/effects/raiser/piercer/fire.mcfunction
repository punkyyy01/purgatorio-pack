scoreboard players reset #.temp0 blue.misc
execute if score @s blue.tr.primary_data matches 101.. run scoreboard players set @s blue.tr.primary_data 100
scoreboard players remove @s blue.tr.primary_data 48
playsound block.candle.extinguish block @a[distance=..20] ^ ^ ^1 2 0.5
function blue:tr/effects/raiser/piercer/cast
scoreboard players add @s blue.tr.primary_data 48