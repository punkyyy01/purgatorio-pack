title @s actionbar {"translate":"blue.tr.gamble.halt","fallback":"Halt","color":"dark_green"}
playsound entity.illusioner.prepare_blindness player @a[x=0] ~ ~ ~ 3 1
playsound entity.illusioner.prepare_mirror player @a[x=0] ~ ~ ~ 3 1.25
summon marker ~ ~ ~ {Tags:["blue.tr.gamble.halt_marker"]}
scoreboard players operation @e[tag=blue.tr.gamble.halt_marker,distance=..0.1,type=marker] blue.id = @s blue.id
execute as @e[tag=blue.tr.gamble.halt_marker,distance=..0.1,type=marker] unless score @s blue.tr.schedule_context matches 1.. store result score @s blue.tr.schedule_context run schedule function blue:tr/effects/snout/gamble/halt/delay 20t append
particle glow ~ ~1 ~ 0.3 1 0.3 0 64