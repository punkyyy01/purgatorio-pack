execute if entity @s[tag=blue.tr.trusted_player,scores={blue.health=11..}] store result score #.temp blue.misc run scoreboard players add @a[tag=blue.tr.current_tick,distance=..24,limit=1] blue.tr.primary_data 6
execute if entity @s[tag=blue.tr.trusted_player,scores={blue.health=..10}] store result score #.temp blue.misc run scoreboard players add @a[tag=blue.tr.current_tick,distance=..24,limit=1] blue.tr.primary_data 3
execute if entity @s[type=!player] store result score #.temp blue.misc run scoreboard players add @a[tag=blue.tr.current_tick,distance=..24,limit=1] blue.tr.primary_data 2
execute if entity @s[tag=!blue.tr.trusted_player,type=player] store result score #.temp blue.misc run scoreboard players add @a[tag=blue.tr.current_tick,distance=..24,limit=1] blue.tr.primary_data 1
execute if score #.temp blue.misc matches 5.. run particle dust{color:[1f,0.6f,0.5f],scale:1} ~ ~0.7 ~ 0.3 0.5 0.3 0 6 force @a[tag=blue.tr.current_tick,distance=..24,limit=1]
execute unless score #.temp blue.misc matches 105.. run return fail
execute if score @s[tag=blue.tr.trusted_player] blue.health matches ..10 if score @a[tag=blue.tr.current_tick,distance=..24,limit=1] blue.health matches 10.. run effect give @s instant_health 1 0 true
execute if score @s[tag=blue.tr.trusted_player] blue.health matches ..10 run damage @a[tag=blue.tr.current_tick,distance=..24,scores={blue.health=10..},limit=1] 4 blue:tr/sacrifice
playsound entity.illusioner.mirror_move player @a[distance=..20] ~ ~ ~ 0.75 2
kill b163102f-0-b-0-1
summon marker ~ ~ ~ {UUID:[I;-1318907857,11,0,1]}
execute at @a[tag=blue.tr.current_tick,distance=..24,limit=1] run tp @s ~ ~ ~
effect give @s invisibility 4 0 true
effect give @s regeneration 3 0 true