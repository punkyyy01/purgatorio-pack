execute if predicate blue:r/25c as @a[tag=blue.tr.current_tick,distance=..16,limit=1] unless score @s blue.tr.fourth_data matches 1.. run scoreboard players set @s blue.tr.fourth_data 300
tp @s ~ ~ ~ ~ ~
data merge entity @s {Tags:["blue.tr.coast.projectile","blue.tr.coast.tropical","blue.tr.entity","smithed.entity"],teleport_duration:1,item:{id:tropical_fish},transformation:{scale:[0.5f,0.5f,0.5f],left_rotation:[-0.28f,-0.65f,0.28f,0.65f]}}
playsound entity.tropical_fish.death player @a[distance=..20] ~ ~ ~ 1 1.5
playsound entity.vex.hurt player @a[distance=..20] ~ ~ ~ 0.85 1.3
scoreboard players set @a[tag=blue.tr.current_tick,distance=..16,limit=1] blue.tr.primary_cooldown 5
execute if score #.temp0 blue.misc matches -597 run scoreboard players set @s blue.misc -2
execute if score #.coast.bonus blue.misc matches 2.. run scoreboard players remove @s blue.misc 3
execute if score #.coast.bonus blue.misc matches 2.. run scoreboard players remove @a[tag=blue.tr.current_tick,distance=..16,limit=1] blue.tr.primary_data 2
scoreboard players operation @s blue.id = #.link blue.id
execute if dimension the_nether run scoreboard players add @s blue.misc 1
execute unless predicate blue:r/10c run return fail
item replace entity @s contents with tropical_fish[enchantment_glint_override=true]
playsound entity.fish.swim player @a[distance=..20] ~ ~ ~ 0.5 2
tag @s add blue.tr.coast.reverse