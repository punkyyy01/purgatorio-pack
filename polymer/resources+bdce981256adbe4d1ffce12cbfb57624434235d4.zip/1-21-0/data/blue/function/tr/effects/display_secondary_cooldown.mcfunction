tag @s[scores={blue.tr.secondary_cooldown=..10}] add blue.tr.actionbar
tag @s[scores={blue.tr.secondary_cooldown=..10}] remove blue.tr.actionbar-2
execute if score @s blue.tr.secondary_cooldown matches ..10 run schedule function blue:tr/effects/display_reset 2t
scoreboard players operation #x blue.misc = @s blue.tr.secondary_cooldown
scoreboard players operation #x blue.misc *= #20 blue.misc
execute store result score #z blue.misc store result storage blue:trims temp.int int 0.1 run scoreboard players operation #x blue.misc /= #40 blue.misc
execute store result score #x blue.misc run data get storage blue:trims temp.int 10
scoreboard players operation #z blue.misc -= #x blue.misc
execute if entity @s[tag=blue.tr.trim.tide] run data modify storage blue:trims display set value {"translate":"blue.tr.tidal_surge_name","fallback":"Tidal Surge","color":"#199ADD"}
execute if entity @s[tag=blue.tr.trim.rib] run data modify storage blue:trims display set value {"translate":"blue.tr.ashen_trance","fallback":"Ashen Trance","color":"#E6484B"}
execute if entity @s[tag=blue.tr.trim.spire] run data modify storage blue:trims display set value {"translate":"blue.tr.guidance_name","fallback":"Guidance","color":"#BE20C7"}
execute if entity @s[tag=blue.tr.trim.ward] run data modify storage blue:trims display set value {"translate":"blue.tr.last_resort_name","fallback":"Last Resort","color":"#5C70AE"}
title @s actionbar {"translate":"%s • %s.%ss","color":"gray","with":[{"storage":"blue:trims","nbt":"display","interpret":true},{"storage":"blue:trims","nbt":"temp.int","color":"white","plain":true},{"score":{"name":"#z","objective":"blue.misc"},"color":"white"}]}