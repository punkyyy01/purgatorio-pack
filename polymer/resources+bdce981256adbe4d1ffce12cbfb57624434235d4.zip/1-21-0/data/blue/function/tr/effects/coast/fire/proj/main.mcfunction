execute if block ~ ~ ~ lava run return run function blue:tr/effects/coast/fire/proj/burn
scoreboard players add @s blue.misc 1
scoreboard players operation #.link blue.id = @s blue.id
tag @a[scores={blue.tr.current_trim=1},predicate=blue:shared/id_link,limit=1] add blue.tr.current_tick
execute if entity @s[tag=blue.tr.coast.cod] run function blue:tr/effects/coast/fire/proj/cod
execute if entity @s[tag=blue.tr.coast.salmon] run function blue:tr/effects/coast/fire/proj/salmon
execute if entity @s[tag=blue.tr.coast.pufferfish] run function blue:tr/effects/coast/fire/proj/pufferfish
execute if entity @s[tag=blue.tr.coast.tropical] run function blue:tr/effects/coast/fire/proj/tropical/main
tag @a[tag=blue.tr.current_tick,limit=1] remove blue.tr.current_tick