$execute store result storage blue:trims temp.float float 0.00001 run data get storage blue:trims temp.float $(int)
$execute store result storage blue:trims temp.f2 float 0.00001 run data get storage blue:trims temp.f2 $(int)
$execute store result storage blue:trims temp.f3 float 0.00001 run data get storage blue:trims temp.f3 $(int)