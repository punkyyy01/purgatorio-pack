title @s actionbar {"translate":"blue.tr.gamble.throwing","fallback":"Throwing LVL.%s","color":"gray","with":["2"]}
execute unless score @s blue.tr.primary_data matches 600.. run scoreboard players set @s blue.tr.primary_data 600
schedule function blue:tr/effects/snout/gamble/loop 1t
playsound entity.witch.throw player @a[distance=..40] ~ ~ ~ 1.5 0.75