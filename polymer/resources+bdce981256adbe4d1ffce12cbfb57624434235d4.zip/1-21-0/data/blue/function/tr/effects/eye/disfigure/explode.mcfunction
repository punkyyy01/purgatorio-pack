kill
particle scrape ~ ~ ~ 0 0 0 2 16 force
execute if entity @s[tag=blue.tr.eye.thrown] as @a[tag=blue.tr.current_tick,limit=1] run return run function blue:tr/effects/eye/disfigure/mist
execute on origin if entity @s[tag=blue.tr.current_tick] run return run function blue:tr/effects/eye/disfigure/mist
execute on origin run playsound entity.ender_eye.death player @s ~ -128 ~ 0 1.25 1
execute on origin run playsound entity.ender_eye.death player @s ~ -128 ~ 0 1.25 1
execute on origin run effect give @s nausea 7 17
playsound entity.ender_eye.death player @a[tag=blue.tr.current_tick,limit=1] ~ -128 ~ 0 1.1 0.75
playsound entity.ender_eye.death player @a[tag=blue.tr.current_tick,limit=1] ~ -128 ~ 0 1.1 0.75
playsound block.sign.waxed_interact_fail player @a[distance=..40] ~ ~ ~ 2 0.5
playsound entity.ender_eye.death player @a[distance=..40] ~ ~ ~ 2 1.25
particle glow_squid_ink ~ ~ ~ 0 0 0 0.1 4 force
particle scrape ~ ~ ~ 0 0 0 4 64 force