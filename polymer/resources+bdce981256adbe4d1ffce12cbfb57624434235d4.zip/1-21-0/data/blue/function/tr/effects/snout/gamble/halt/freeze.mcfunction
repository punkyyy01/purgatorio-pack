tp @s @s
particle scrape ~ ~1 ~ 0.3 0.6 0.3 1 32
scoreboard players set @s[type=player] blue.tr.combat -600
kill @e[tag=blue.tr.gamble.freeze,type=area_effect_cloud,distance=..0.25,limit=1]
execute unless entity @s[type=player] run return run summon area_effect_cloud ~ ~ ~ {Rotation:[0,180],Radius:0,Duration:340,Tags:["blue.tr.gamble.freeze","blue.tr.mob_freeze"],custom_particle:{type:"block",block_state:"air"},Particle:{type:"block",block_state:"air"}}
scoreboard players operation #.temp blue.misc = @s blue.id
summon area_effect_cloud ~ ~ ~ {Rotation:[0,180],Radius:0,Duration:340,Tags:["blue.tr.gamble.freeze","blue.tr.temp"],custom_particle:{type:"block",block_state:"air"},Particle:{type:"block",block_state:"air"}}
scoreboard players operation @e[tag=blue.tr.temp,distance=..1,limit=1,type=area_effect_cloud] blue.id = @s blue.id
tag @e[tag=blue.tr.temp,distance=..1,limit=1,type=area_effect_cloud] remove blue.tr.temp