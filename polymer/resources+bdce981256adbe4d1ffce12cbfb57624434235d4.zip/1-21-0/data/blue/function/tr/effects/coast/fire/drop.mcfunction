execute if items entity @s contents #fishes[count=1] on origin if entity @s[tag=blue.tr.current_tick] run scoreboard players set #.temp0 blue.misc -596
execute unless score #.temp0 blue.misc matches -596 run return fail
scoreboard players reset #.temp0 blue.misc
execute on origin run scoreboard players operation #.temp blue.misc = @s blue.tr.primary_cooldown
execute if score #.temp blue.misc matches 1.. on origin run function blue:tr/effects/display_primary_cooldown
execute if score #.temp blue.misc matches 1.. run return run function blue:tr/inv/item/quick_return
execute on origin if predicate blue:tr/pirate run scoreboard players set #.temp0 blue.misc -597
execute on origin store success score #.temp blue.misc if predicate blue:shared/moving
execute on origin run scoreboard players operation #.link blue.id = @s blue.id
execute on origin run scoreboard players operation #.coast.bonus blue.misc = @s blue.tr.primary_data
scoreboard players set #.tr.entity_exists blue.misc 1
execute if items entity @s contents cod on origin at @s anchored eyes positioned ^ ^ ^0.5 summon item_display run function blue:tr/effects/coast/fire/cod
execute if items entity @s contents salmon on origin at @s anchored eyes positioned ^ ^ ^0.5 summon item_display run function blue:tr/effects/coast/fire/salmon
execute if items entity @s contents cooked_cod on origin at @s anchored eyes positioned ^ ^ ^0.5 summon item_display run function blue:tr/effects/coast/fire/cod
execute if items entity @s contents pufferfish on origin at @s anchored eyes positioned ^ ^ ^0.5 run function blue:tr/effects/coast/fire/pufferfish
execute if items entity @s contents tropical_fish on origin at @s anchored eyes positioned ^ ^ ^0.5 summon item_display run function blue:tr/effects/coast/fire/tropical
execute if items entity @s contents cooked_salmon on origin at @s anchored eyes positioned ^ ^ ^0.5 summon item_display run function blue:tr/effects/coast/fire/salmon
kill