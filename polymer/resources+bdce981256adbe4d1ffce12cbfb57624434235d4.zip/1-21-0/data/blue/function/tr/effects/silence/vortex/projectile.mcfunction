execute if entity @s[type=marker] run return run function blue:tr/effects/silence/vortex/entity
execute store result entity @s Air byte 1 run scoreboard players get #.20 blue.misc
particle mycelium ~ ~0.4 ~ 0.15 0.15 0.15 0 10
particle sculk_charge_pop ~ ~0.49 ~ 0.175 0.175 0.175 0.01 14
particle sculk_charge_pop ~ ~0.49 ~ 0.175 0.175 0.175 0.01 6 force
particle smoke ~ ~0.4 ~ 0.175 0.175 0.175 0 1 force
particle glow ~ ~0.4 ~ 0.175 0.1755 0.1755 0 1
execute if block ~ ~-0.5 ~ #blue:shared/passable if block ~0.5 ~ ~ #blue:shared/passable if block ~-0.5 ~ ~ #blue:shared/passable if block ~ ~ ~0.5 #blue:shared/passable if block ~ ~ ~-0.5 #blue:shared/passable if block ~ ~0.5 ~ #blue:shared/passable if block ~-0.5 ~ ~-0.5 #blue:shared/passable if block ~0.5 ~ ~-0.5 #blue:shared/passable if block ~-0.5 ~ ~0.5 #blue:shared/passable if block ~0.5 ~ ~0.5 #blue:shared/passable if block ~-0.5 ~0.5 ~-0.5 #blue:shared/passable if block ~-0.5 ~0.5 ~0.5 #blue:shared/passable if block ~-0.5 ~0.5 ~ #blue:shared/passable if block ~0.5 ~0.5 ~ #blue:shared/passable if block ~-0.5 ~-0.5 ~-0.5 #blue:shared/passable if block ~-0.5 ~-0.5 ~0.5 #blue:shared/passable if block ~-0.5 ~-0.5 ~ #blue:shared/passable if block ~0.5 ~-0.5 ~ #blue:shared/passable if block ~-0.5 ~0.5 ~-0.5 #blue:shared/passable if block ~0.5 ~0.5 ~-0.5 #blue:shared/passable if block ~-0.5 ~0.5 ~0.5 #blue:shared/passable if block ~0.5 ~0.5 ~0.5 #blue:shared/passable if block ~-0.5 ~-0.5 ~-0.5 #blue:shared/passable if block ~0.5 ~-0.5 ~-0.5 #blue:shared/passable if block ~-0.5 ~-0.5 ~0.5 #blue:shared/passable if block ~0.5 ~-0.5 ~0.5 #blue:shared/passable run return fail
summon marker ~ ~ ~ {Tags:["smithed.entity","smithed.strict","blue.tr.entity","blue.tr.silence.vortex"]}
scoreboard players operation #.link blue.id = @s blue.id
execute as @e[tag=blue.tr.silence.vortex,type=marker,distance=..1] unless score @s blue.id matches 1.. run scoreboard players operation @s blue.id = #.link blue.id
kill
playsound entity.warden.sonic_charge player @a ~ ~ ~ 1.75 0.75
effect give @e[type=!#blue:shared/peaceful,predicate=!blue:shared/id_link,distance=..8] slowness 2 0
particle sculk_charge_pop ~ ~0.1 ~ 0 0 0 0.5 280
playsound entity.warden.nearby_closest master @a[distance=..50] ~ ~ ~ 2.5 0.5
playsound entity.warden.nearby_closest master @a[distance=..50] ~ ~ ~ 2.5 0.5
playsound entity.warden.nearby_closest master @a[distance=..50] ~ ~ ~ 2.5 0.5
playsound entity.warden.nearby_closest master @a[distance=..50] ~ ~ ~ 2.5 0.5
playsound entity.warden.nearby_closest master @a[distance=..50] ~ ~ ~ 2.5 0.5