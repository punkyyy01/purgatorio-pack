scoreboard players remove @s blue.tr.primary_data 1
execute if score @s blue.tr.primary_data matches 1.. run return run attribute @s generic.armor modifier add blue:tr.trim -0.15 add_multiplied_total
attribute @s generic.armor modifier remove blue:tr.trim