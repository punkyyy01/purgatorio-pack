execute unless predicate blue:shared/in_stronghold run scoreboard players remove @s blue.tr.secondary_data 1
scoreboard players remove @s blue.tr.secondary_data 1
scoreboard players operation #.temp blue.misc = @s blue.tr.secondary_data
scoreboard players operation #.temp blue.misc /= #20 blue.misc
execute unless score #.temp blue.misc = @s blue.tr.third_data if score @s blue.tr.secondary_data matches 18.. run playsound entity.ender_eye.launch player @s ~ ~ ~ 0.25 2
scoreboard players operation @s blue.tr.third_data = #.temp blue.misc