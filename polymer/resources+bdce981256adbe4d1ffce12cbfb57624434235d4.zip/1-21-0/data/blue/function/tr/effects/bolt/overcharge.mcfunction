advancement revoke @s only blue:tr/ability/overcharge req
execute at @n[type=lightning_bolt,distance=..224] run function blue:tr/effects/bolt/lightning
function blue:tr/effects/flash {args:" ~ ~1 ~"}