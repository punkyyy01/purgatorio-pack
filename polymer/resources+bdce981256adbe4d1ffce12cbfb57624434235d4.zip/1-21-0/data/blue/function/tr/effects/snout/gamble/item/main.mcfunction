execute on origin if entity @s[tag=blue.tr.current_tick,predicate=!blue:shared/is_sneaking] run scoreboard players set #.temp blue.misc -5521
execute unless score #.temp blue.misc matches -5521 run return fail
execute on origin run scoreboard players operation #.link blue.id = @s blue.id
execute store result score #.temp blue.misc if entity @e[tag=blue.tr.gamble.item,predicate=blue:shared/id_link,type=item]
execute if score #.temp blue.misc >= #.snout.gamble_limit blue.config unless score #.snout.gamble_limit blue.config matches -1 run return fail
scoreboard players reset #.temp blue.misc
execute if items entity @s contents gold_nugget store success score #.temp blue.misc run tag @s add blue.tr.gold_nugget
execute if items entity @s contents gold_ingot store success score #.temp blue.misc run tag @s add blue.tr.gold_ingot
execute if items entity @s contents gold_block store success score #.temp blue.misc run tag @s add blue.tr.gold_block
execute if entity @s[tag=blue.tr.gold_ingot] if entity @e[distance=..7,type=piglin,limit=1] run scoreboard players set #.temp blue.misc 0
execute unless score #.temp blue.misc matches 1 run return fail
execute on origin run scoreboard players operation #.temp blue.misc = @s blue.tr.primary_data
execute on origin run scoreboard players operation #.temp0 blue.misc = @s blue.tr.secondary_data
execute if score #.temp0 blue.misc matches 1.. run tag @s add blue.tr.gamble.withdrawal
execute if score #.temp blue.misc matches 1.. run function blue:tr/effects/snout/gamble/throw/entity
scoreboard players operation @s blue.id = #.link blue.id
tag @s add blue.tr.gamble.item
scoreboard players set #.tr.entity_exists blue.misc 1
tag @s add blue.tr.entity