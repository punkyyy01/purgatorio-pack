tag @s[tag=blue.tr.flow.in_chamber] remove blue.tr.flow.in_chamber
execute if predicate blue:shared/in_trial_chambers run tag @s add blue.tr.flow.in_chamber
execute if block ^ ^ ^ water run effect give @s[tag=blue.tr.flow.out_water] water_breathing 5 0 true
tag @s[tag=blue.tr.flow.out_water] remove blue.tr.flow.out_water
execute if block ^ ^ ^ #air run tag @s add blue.tr.flow.out_water
effect give @s wind_charged 2 50 true