execute at @a[tag=blue.tr.fake_throw] run particle sculk_charge_pop ~ ~0.1 ~ 0 0 0 0.5 280 force @s
execute at @a[tag=blue.tr.fake_throw] run playsound entity.warden.nearby_closest master @s ~ ~ ~ 2.5 0.5
execute at @a[tag=blue.tr.fake_throw] run playsound entity.warden.nearby_closest master @s ~ ~ ~ 2.5 0.5
execute at @a[tag=blue.tr.fake_throw] run playsound entity.warden.nearby_closest master @s ~ ~ ~ 2.5 0.5
execute at @a[tag=blue.tr.fake_throw] run playsound entity.warden.nearby_closest master @s ~ ~ ~ 2.5 0.5
tag @a[tag=blue.tr.fake_throw] remove blue.tr.fake_throw