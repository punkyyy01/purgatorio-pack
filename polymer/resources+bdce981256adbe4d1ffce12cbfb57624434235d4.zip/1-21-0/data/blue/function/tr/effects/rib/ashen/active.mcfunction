effect give @s strength 1 1
particle mycelium ~ ~0.7 ~ 0.2 0.4 0.2 0 4
particle soul_fire_flame ~ ~0.7 ~ 0.2 0.3 0.2 0 1
scoreboard players remove @s blue.tr.secondary_data 1
scoreboard players remove @s[scores={blue.tr.primary_cooldown=1..}] blue.tr.primary_cooldown 1
scoreboard players operation #.link blue.id = @s blue.id
execute if score #.20 blue.misc matches 10 if entity @e[distance=..32,team=blue.tr.rib,limit=1] run team join blue.tr.rib
execute if score @s blue.tr.secondary_data matches 1 run function blue:tr/effects/rib/ashen/end
execute if score #.rib.strict_scorch blue.config matches 1 if score @s blue.tr.combat matches -100.. run return fail
execute unless predicate blue:r/1c run return fail
playsound entity.blaze.shoot player @a[distance=..40] ~ ~ ~ 1.5 0.75
execute store result storage blue:trims temp.id int 1 run scoreboard players get @s blue.id
execute as @a[distance=..9] run function blue:tr/delayed/cmd/trust/define/player
execute as @a[distance=..8,tag=!blue.tr.trusted_player,predicate=!blue:shared/id_link] run damage @s 10 blue:tr/fire by @a[tag=blue.tr.current_tick,distance=..16,limit=1]
execute at @a[distance=..8,tag=!blue.tr.trusted_player,gamemode=!spectator,predicate=!blue:shared/id_link] run particle soul_fire_flame ~ ~1 ~ 0.3 0.5 0.3 0.02 12
tag @a[tag=blue.tr.trusted_player] remove blue.tr.trusted_player
execute as @e[type=!#blue:shared/peaceful,type=!player,distance=..8,predicate=!blue:shared/id_link] run damage @s 10 blue:tr/fire by @a[tag=blue.tr.current_tick,distance=..16,limit=1]
execute at @e[type=!#blue:shared/peaceful,type=!player,distance=..8,predicate=!blue:shared/id_link] run particle soul_fire_flame ~ ~1 ~ 0.3 0.5 0.3 0.02 12
particle soul_fire_flame ~ ~1 ~ 0.3 0.4 0.3 0.35 50