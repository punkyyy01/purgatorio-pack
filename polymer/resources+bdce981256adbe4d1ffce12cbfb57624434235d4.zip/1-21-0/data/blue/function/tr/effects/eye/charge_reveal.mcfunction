execute if predicate blue:shared/moving run return run execute if score @s blue.tr.primary_data matches 1.. run function blue:tr/effects/eye/end_reveal
execute unless score #.eye.disfigure_time blue.misc matches 1.. run scoreboard players add @s blue.tr.primary_data 1
execute if score @s blue.tr.primary_data matches 43 run effect give @s darkness 2 0 true
execute if score @s blue.tr.primary_data matches 20.. run particle reverse_portal ~ ~0.5 ~ 0.2 0.2 0.2 2 1
execute unless score @s blue.tr.primary_data matches 60.. run return fail
execute if score @s blue.tr.primary_data matches 60 run function blue:tr/effects/eye/first_reveal
particle glow ~ ~2 ~ 32 20 32 0 20 force
particle glow ~ ~2 ~ 34 21 34 0 50 normal @a[scores={blue.particles=1..}]
particle glow ~ ~2 ~ 36 21.5 36 0 40 force @a[scores={blue.particles=2}]
execute if score #.60 blue.misc matches 3 run playsound entity.phantom.ambient player @a[distance=..20] ~ ~ ~ 1 0.5
execute unless score #.20 blue.misc matches 10 run return fail
scoreboard players add @a[distance=5..64,gamemode=!spectator,gamemode=!creative] blue.tr.fear 17
scoreboard players add @a[distance=64.01..100,gamemode=!spectator,gamemode=!creative] blue.tr.fear 6
effect give @e[type=!#blue:shared/no_ai,distance=5..100,predicate=!blue:shared/gamemode] glowing 9 9 true
effect give @a[distance=5..80] slowness 5 1 true
effect give @s invisibility 5 0 true
effect give @s blindness 2 0 true