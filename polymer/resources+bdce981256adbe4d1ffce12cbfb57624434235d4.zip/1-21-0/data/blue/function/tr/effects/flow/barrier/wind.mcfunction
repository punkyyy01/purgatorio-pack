execute if entity @s[type=breeze_wind_charge] if score @a[tag=blue.tr.current_tick,distance=..9,limit=1] blue.tr.secondary_cooldown matches 1.. run return fail
scoreboard players set @s blue.tr.secondary_cooldown 200
execute facing entity @a[tag=blue.tr.current_tick,distance=..9,limit=1] eyes run particle cloud ~ ~ ~ ^ ^ ^10000000 0.00000004 0
playsound entity.breeze.inhale player @a[distance=..20] ~ ~ ~ 1 2
give @a[tag=blue.tr.current_tick,distance=..9,limit=1] wind_charge
kill