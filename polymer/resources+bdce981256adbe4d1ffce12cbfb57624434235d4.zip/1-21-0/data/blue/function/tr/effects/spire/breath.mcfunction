execute store result entity @s Air byte 1 run scoreboard players get #.20 blue.misc
particle dragon_breath ~ ~0.25 ~ 0.08 0.08 0.08 0 2
particle dragon_breath ~ ~0.25 ~ 0.08 0.08 0.08 0 2 normal @a[scores={blue.particles=2..}]
execute on origin run scoreboard players operation #.link blue.id = @s blue.id
execute if block ~ ~-0.5 ~ #blue:shared/passable if block ~0.5 ~ ~ #blue:shared/passable if block ~-0.5 ~ ~ #blue:shared/passable if block ~ ~ ~0.5 #blue:shared/passable if block ~ ~ ~-0.5 #blue:shared/passable if block ~ ~0.5 ~ #blue:shared/passable if block ~-0.5 ~ ~-0.5 #blue:shared/passable if block ~0.5 ~ ~-0.5 #blue:shared/passable if block ~-0.5 ~ ~0.5 #blue:shared/passable if block ~0.5 ~ ~0.5 #blue:shared/passable if block ~-0.5 ~0.5 ~-0.5 #blue:shared/passable if block ~-0.5 ~0.5 ~0.5 #blue:shared/passable if block ~-0.5 ~0.5 ~ #blue:shared/passable if block ~0.5 ~0.5 ~ #blue:shared/passable if block ~-0.5 ~-0.5 ~-0.5 #blue:shared/passable if block ~-0.5 ~-0.5 ~0.5 #blue:shared/passable if block ~-0.5 ~-0.5 ~ #blue:shared/passable if block ~0.5 ~-0.5 ~ #blue:shared/passable if block ~-0.5 ~0.5 ~-0.5 #blue:shared/passable if block ~0.5 ~0.5 ~-0.5 #blue:shared/passable if block ~-0.5 ~0.5 ~0.5 #blue:shared/passable if block ~0.5 ~0.5 ~0.5 #blue:shared/passable if block ~-0.5 ~-0.5 ~-0.5 #blue:shared/passable if block ~0.5 ~-0.5 ~-0.5 #blue:shared/passable if block ~-0.5 ~-0.5 ~0.5 #blue:shared/passable if block ~0.5 ~-0.5 ~0.5 #blue:shared/passable positioned ~-0.5 ~-0.5 ~-0.5 unless entity @e[type=!#blue:shared/no_ai,predicate=!blue:shared/gamemode,predicate=!blue:shared/id_link,dx=0,limit=1] run return fail
playsound entity.splash_potion.break player @a[distance=..20] ~ ~ ~ 0.8 0.75
kill
summon area_effect_cloud ~ ~ ~ {Rotation:[0,180],Tags:["blue.tr.blast-o-breath"],"potion_contents":{"potion":"harming"},custom_particle:{type:"block",block_state:"air"},Particle:{type:"block",block_state:"air"},Duration:16,Radius:0.5,RadiusPerTick:0.15,ReapplicationDelay:0,WaitTime:0s}
data modify entity @e[tag=blue.tr.blast-o-breath,type=area_effect_cloud,distance=..0.1,limit=1] Owner set from entity @s Thrower
summon area_effect_cloud ~ ~ ~ {Rotation:[0,180],Particle:{type:"dragon_breath"},custom_particle:{type:"dragon_breath"},Duration:15,Radius:1.5,RadiusPerTick:0.1,WaitTime:0s}
playsound entity.ender_dragon.shoot player @a[distance=..40] ~ ~ ~ 1.8 1
playsound entity.dragon_fireball.explode player @a[distance=..40] ~ ~ ~ 1.7 2
particle item{item:"dragon_breath"} ~ ~0.2 ~ 0.1 0.1 0.1 0.15 24
particle dragon_breath ~ ~0.2 ~ 0 0 0 0.08 48