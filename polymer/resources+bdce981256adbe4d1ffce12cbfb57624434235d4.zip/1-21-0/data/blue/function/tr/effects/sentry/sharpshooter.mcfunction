advancement revoke @s only blue:tr/ability/sharpshooter req
scoreboard players set @s blue.tr.secondary_cooldown 140
execute if score @s blue.tr.secondary_data matches ..-1 run scoreboard players set @s blue.tr.secondary_data 0
execute unless score @s blue.tr.secondary_data matches 50.. run scoreboard players add @s blue.tr.secondary_data 5