scoreboard players set @s blue.tr.secondary_cooldown 1
scoreboard players set @s blue.tr.primary_data -540