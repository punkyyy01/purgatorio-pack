scoreboard players operation #.link blue.id = @s blue.id
tag @a[scores={blue.tr.current_trim=9},predicate=blue:shared/id_link,limit=1] add blue.tr.current_tick
execute unless entity @a[tag=blue.tr.current_tick,limit=1] run kill
scoreboard players add @s blue.misc 1
execute if score @s blue.misc matches 1..3 run particle sculk_charge_pop ~ ~ ~ 0.4 0.4 0.4 0.01 24
execute if score @s blue.misc matches 1..3 run particle smoke ~ ~ ~ 0.4 0.4 0.4 0 1
execute if score @s blue.misc matches 1..3 run particle glow ~ ~ ~ 0.4 0.5 0.4 0 1
execute if score @s blue.misc matches ..4 run return fail
effect give @e[type=!#blue:shared/no_ai,tag=!blue.tr.current_tick,distance=..7.5] slow_falling 1 0
execute store success score @s blue.particles unless score @s blue.particles matches 1
scoreboard players add @s blue.tr.ambient 1
execute if score @s blue.tr.ambient matches 3 as @e[type=!#blue:shared/no_ai,type=!player,tag=!smithed.strict,distance=..8] facing entity @s feet positioned as @s if block ^ ^ ^-0.75 #blue:shared/passable run tp ^ ^ ^-0.25
execute if score @s blue.tr.ambient matches 3 as @a[tag=!blue.tr.current_tick,gamemode=!spectator,gamemode=!creative,distance=..8] facing entity @s feet positioned as @s if block ^ ^ ^-0.75 #blue:shared/passable run tp ^ ^ ^-0.25
scoreboard players set @s[scores={blue.tr.ambient=3}] blue.tr.ambient 0
execute if score @s blue.misc matches 5 run particle enchant ~ ~1 ~ 0.1 0.1 0.1 6 400 normal @a[scores={blue.particles=2..}]
execute if score @s blue.misc matches 5 run particle enchant ~ ~1 ~ 0.1 0.1 0.1 6 300 normal @a[scores={blue.particles=1..}]
execute if score @s blue.misc matches 5 run particle enchant ~ ~1 ~ 0.1 0.1 0.1 6 100 force
execute if score @s blue.misc matches 5 run particle nautilus ~ ~1 ~ 0.1 0.1 0.1 4.9 1200 normal @a[scores={blue.particles=2..}]
execute if score @s blue.misc matches 5 run particle nautilus ~ ~1 ~ 0.1 0.1 0.1 4.9 700
execute if score @s blue.misc matches 5 run particle nautilus ~ ~1 ~ 0.1 0.1 0.1 4.9 400 force
execute if score @s blue.misc matches 35 run stopsound @a[distance=..128] master entity.warden.nearby_closest
execute if score @s blue.misc matches 36 run particle sonic_boom ~ ~ ~ 0.1 0.1 0.1 0 24 force
execute unless score @s blue.misc matches 44.. run return fail
stopsound @a[tag=!blue.tr.current_tick,distance=..8] master item.elytra.flying
playsound item.elytra.flying master @a[tag=!blue.tr.current_tick,distance=..8] ~ -1000 ~ 0 1.7 0.4
effect give @a[tag=!blue.tr.current_tick,distance=..8] darkness 9 78 true
schedule function blue:tr/effects/silence/muffle_loop 1t
scoreboard players set @a[tag=blue.tr.current_tick,limit=1] blue.tr.primary_cooldown 1000
kill b163102f-0-6-0-1
summon marker ~ ~ ~ {UUID:[I;-1318907857,6,0,1]}
execute store result storage blue:trims temp.float float 0.01 run scoreboard players get #.silence.vortex_scale blue.config
execute as @e[type=!#blue:shared/no_ai,tag=!blue.tr.current_tick,distance=..9] run function blue:tr/effects/silence/vortex/multiply_damage with storage blue:trims temp
kill b163102f-0-6-0-1
tag @a[tag=blue.tr.current_tick,limit=1] remove blue.tr.current_tick
function blue:tr/effects/silence/vortex/flash
playsound block.sculk_catalyst.bloom master @a[distance=..48] ~ ~ ~ 11 0.5
playsound block.sculk_catalyst.bloom master @a[distance=..48] ~ ~ ~ 11 0.5
playsound block.sculk_catalyst.bloom master @a[distance=..48] ~ ~ ~ 11 0.5
playsound block.sculk_catalyst.bloom master @a[distance=..48] ~ ~ ~ 11 0.5
playsound block.sculk_catalyst.bloom master @a[distance=..48] ~ ~ ~ 11 0.5
playsound block.sculk_catalyst.bloom master @a[distance=..48] ~ ~ ~ 11 0.5
playsound entity.warden.sonic_boom master @a[distance=..100] ~ ~ ~ 4 0.7 0.1
particle sculk_charge_pop ~ ~0.1 ~ 0.1 0.1 0.1 0.44 300 normal @a[scores={blue.particles=2..}]
particle sculk_soul ~ ~0.1 ~ 0.1 0.1 0.1 0.39 900 normal @a[scores={blue.particles=2..}]
particle sculk_charge_pop ~ ~0.1 ~ 0.1 0.1 0.1 0.44 200 normal @a[scores={blue.particles=1..}]
particle large_smoke ~ ~0.1 ~ 0.1 0.1 0.1 0.44 50 normal @a[scores={blue.particles=1..}]
particle sculk_charge_pop ~ ~0.1 ~ 0.1 0.1 0.1 0.44 100 force
particle sculk_soul ~ ~0.1 ~ 0.1 0.1 0.1 0.39 300 force
particle sculk_soul ~ ~0.1 ~ 0.1 0.1 0.1 0.39 500
execute unless score #.silence.vortex_griefing blue.config matches 1 run return run kill
summon creeper ~ ~ ~ {Fuse:0s,ignited:1b,ExplosionRadius:4b,DeathLootTable:"",Silent:1b}
schedule function blue:tr/effects/silence/vortex/sound 1t
kill