schedule function blue:tr/effects/eye/fear/remove_float 2t
effect give @s levitation 1 55 true
tag @s add blue.tr.eye.float
tp @s @s