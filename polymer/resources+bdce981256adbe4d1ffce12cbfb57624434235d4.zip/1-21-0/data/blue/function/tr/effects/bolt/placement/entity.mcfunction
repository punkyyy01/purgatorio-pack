scoreboard players add @s blue.misc 1
schedule function blue:tr/effects/bolt/placement/loop 1t
function blue:tr/delayed/cmd/trust/define/main
execute if predicate blue:tr/zap positioned ~-1.5 ~-1.5 ~-1.5 as @a[dx=2,dy=2,dz=2,tag=!blue.tr.trusted_player] at @s run function blue:tr/effects/bolt/zap
tag @a[tag=blue.tr.trusted_player] remove blue.tr.trusted_player
execute unless score @s blue.misc matches 60.. if block ~ ~ ~ #blue:shared/copper_blocks run return fail
scoreboard players operation #.link blue.id = @s blue.id
execute as @a[scores={blue.tr.current_trim=17},predicate=blue:shared/id_link,limit=1] positioned ~ ~-0.5 ~ facing entity @s feet run function blue:tr/effects/bolt/conduct/player/start
execute if block ~ ~ ~ #blue:shared/copper_blocks run fill ~ ~ ~ ~ ~ ~ air destroy
particle wax_on ~ ~ ~ 0.4 0.4 0.4 0.1 12
kill