advancement revoke @s only blue:tr/ability/stack_ashen
execute if score @s blue.tr.secondary_data matches 1.. rotated ~ 0 positioned ^ ^ ^2 run return run function blue:tr/effects/rib/ashen/spawn
execute unless score #.rib.strict_ashen blue.config matches 0 unless dimension the_nether run return fail
execute if score @s blue.tr.secondary_cooldown matches 1.. run return run title @s actionbar {"text":"☠☠☠☠☠☠☠☠☠☠","color":"dark_gray","italic":true,"strikethrough":true}
scoreboard players add @s blue.tr.third_data 1
execute if score @s blue.tr.third_data matches 1 run title @s actionbar [{"text":"☠","color":"dark_red"},{"text":"☠☠☠☠☠☠☠☠☠","color":"dark_gray","italic":true}]
execute if score @s blue.tr.third_data matches 2 run title @s actionbar [{"text":"☠☠","color":"dark_red"},{"text":"☠☠☠☠☠☠☠☠","color":"dark_gray","italic":true}]
execute if score @s blue.tr.third_data matches 3 run title @s actionbar [{"text":"☠☠☠","color":"dark_red"},{"text":"☠☠☠☠☠☠☠","color":"dark_gray","italic":true}]
execute if score @s blue.tr.third_data matches 4 run title @s actionbar [{"text":"☠☠☠☠","color":"dark_red"},{"text":"☠☠☠☠☠☠","color":"dark_gray","italic":true}]
execute if score @s blue.tr.third_data matches 5 run title @s actionbar [{"text":"☠☠☠☠☠","color":"dark_red"},{"text":"☠☠☠☠☠","color":"dark_gray","italic":true}]
execute if score @s blue.tr.third_data matches 6 run title @s actionbar [{"text":"☠☠☠☠☠☠","color":"dark_red"},{"text":"☠☠☠☠","color":"dark_gray","italic":true}]
execute if score @s blue.tr.third_data matches 7 run title @s actionbar [{"text":"☠☠☠☠☠☠☠","color":"dark_red"},{"text":"☠☠☠","color":"dark_gray","italic":true}]
execute if score @s blue.tr.third_data matches 8 run title @s actionbar [{"text":"☠☠☠☠☠☠☠☠","color":"dark_red"},{"text":"☠☠","color":"dark_gray","italic":true}]
execute if score @s blue.tr.third_data matches 9 run title @s actionbar [{"text":"☠☠☠☠☠☠☠☠☠","color":"dark_red"},{"text":"☠","color":"dark_gray","italic":true}]
execute if score @s blue.tr.third_data matches 10.. run title @s actionbar {"text":"☠☠☠☠☠☠☠☠☠☠","color":"red","bold":true}
execute unless score @s blue.tr.third_data matches 10.. run return fail
scoreboard players set @s blue.tr.secondary_cooldown 1800
scoreboard players set @s blue.tr.secondary_data 500
scoreboard players set @s blue.tr.third_data 0
playsound entity.wither.death player @a[distance=..40] ~ ~ ~ 1.5 2
playsound entity.wither.ambient player @a[distance=..20] ~ ~ ~ 1 1
particle soul ~ ~1 ~ 0.2 0.4 0.2 0.4 128
particle ash ~ ~1 ~ 0.8 0.9 0.8 0 320
effect give @s resistance 15 9 true
effect give @s slowness 1 0 true
effect give @s glowing 2 0 true
team add blue.tr.rib