advancement revoke @s only blue:tr/ability/place_sand req
effect give @s haste 1 4 true
scoreboard players operation #.link blue.id = @s blue.id
execute anchored eyes positioned ^ ^ ^0.5 run function blue:tr/effects/dune/geyser/cast