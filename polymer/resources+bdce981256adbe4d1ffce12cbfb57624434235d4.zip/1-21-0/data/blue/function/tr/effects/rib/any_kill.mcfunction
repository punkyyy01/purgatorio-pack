scoreboard players remove @s[scores={blue.tr.primary_cooldown=1..}] blue.tr.primary_cooldown 40
scoreboard players remove @s[scores={blue.tr.secondary_cooldown=1..}] blue.tr.secondary_cooldown 40
execute if score @s blue.tr.primary_cooldown matches ..0 run scoreboard players set @s blue.tr.primary_cooldown 1
execute if score @s blue.tr.secondary_cooldown matches ..0 run scoreboard players set @s blue.tr.secondary_cooldown 1
advancement revoke @s only blue:tr/ability/rib_kill req