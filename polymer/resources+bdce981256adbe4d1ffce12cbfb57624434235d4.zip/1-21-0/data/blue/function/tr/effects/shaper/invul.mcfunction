execute store result score @s blue.tr.schedule_context run schedule function blue:tr/effects/shaper/clear 1t append
particle smoke ~ ~1 ~ 0.3 0.4 0.3 0 32
execute if biome ~ ~ ~ #blue:shared/old_growth run return run effect give @s resistance 2 9 true
execute if score #.difficulty blue.misc matches ..1 run return run effect give @s resistance 1 1 true
execute if score #.difficulty blue.misc matches 2 run return run effect give @s resistance 1 2 true
execute if score #.difficulty blue.misc matches 3.. run effect give @s resistance 1 3 true