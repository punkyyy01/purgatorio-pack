advancement revoke @s only blue:tr/ability/hit_warden req
tag @s add blue.tr.temp
execute as @e[distance=..10,team=blue.tr.silence,type=warden] at @s run function blue:tr/effects/silence/check_hit
tag @s remove blue.tr.temp
scoreboard players reset #.temp blue.misc