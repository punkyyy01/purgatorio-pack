scoreboard players add @s blue.tr.ambient 1
execute if score #.18s blue.misc matches 4 if score #.60 blue.misc matches 20 if score @s blue.tr.third_data matches 0.. run function blue:tr/effects/coast/check_streak
execute if score @s blue.tr.ambient matches 2 run particle white_ash ~ ~0.9 ~ 0.2 0.4 0.2 0 1 normal @a[scores={blue.particles=2..},distance=..64]
execute if score @s blue.tr.ambient matches 4.. store success score @s blue.tr.ambient run particle ash ~ ~0.9 ~ 0.2 0.4 0.2 0 1 normal @a[scores={blue.particles=1..},distance=..64]
execute unless predicate blue:shared/is_sneaking as @e[tag=!blue.tr.checked,distance=..4,type=item] run function blue:tr/effects/coast/fire/drop
execute if score @s blue.tr.fourth_data matches 1.. run function blue:tr/effects/coast/fire/double_shot
execute if entity @s[tag=blue.tr.coast.propel] as @e[tag=!blue.tr.propel_check,tag=!blue.tr.coast.checked,distance=..4,type=trident] at @s run function blue:tr/effects/coast/propel
execute unless score #.20 blue.misc matches 6 run return fail
execute unless predicate blue:tr/pirate run return fail
effect give @s resistance 3 2 true
effect give @s luck 3 1 true