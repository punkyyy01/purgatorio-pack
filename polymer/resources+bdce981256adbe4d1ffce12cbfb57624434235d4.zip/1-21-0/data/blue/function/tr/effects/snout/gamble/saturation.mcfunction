playsound entity.generic.eat player @a[distance=..20] ~ ~ ~ 1 1
particle dripping_lava ~ ~1 ~ 0.3 0.8 0.3 0 16
effect give @s saturation 8 0