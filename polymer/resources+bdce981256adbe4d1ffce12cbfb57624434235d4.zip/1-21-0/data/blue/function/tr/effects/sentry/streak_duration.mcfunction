scoreboard players add @s[scores={blue.tr.secondary_data=25..}] blue.tr.ambient 1
execute if score @s blue.tr.secondary_cooldown matches 2.. run return fail
scoreboard players reset @s blue.tr.secondary_cooldown
scoreboard players operation @s blue.tr.secondary_data /= #2 blue.misc
title @s[scores={blue.tr.secondary_data=20..}] actionbar {"translate":"blue.tr.sharpshooter_streak_lost","fallback":"Sharpshooter streak lost (x%s)","with":[{"score":{"name":"@s","objective":"blue.tr.secondary_data"},"color":"white"}],"color":"gray"}
scoreboard players reset @s blue.tr.secondary_data