scoreboard players add @s blue.tr.ambient 1
execute if score @s blue.tr.ambient matches 3 run particle falling_dust{block_state:{Name:sand,id:sand}} ~ ~0.9 ~ 0.2 0.4 0.2 0 1 normal @a[scores={blue.particles=2..},distance=..64]
execute if score @s blue.tr.ambient matches 7.. store success score @s blue.tr.ambient run particle falling_dust{block_state:{Name:sand,id:sand}} ~ ~0.9 ~ 0.2 0.4 0.2 0 1 normal @a[scores={blue.particles=1..},distance=..64]
execute if score #.60 blue.misc matches 23 run function blue:tr/effects/dune/endurance
execute unless score @s blue.tr.mined_sand matches 1.. run return fail
scoreboard players reset @s blue.tr.mined_sand
effect give @s haste 2 2 true
execute if items entity @s weapon #shovels run return fail
execute store success score #.temp blue.misc if predicate blue:shared/is_sneaking
scoreboard players operation #.link blue.id = @s blue.id
execute positioned ^ ^ ^1.5 as @e[distance=..4,tag=!blue.tr.checked,type=item] at @s align xyz run function blue:tr/effects/dune/raisure/item
execute if score #.temp blue.misc matches -5256 run function blue:tr/effects/dune/raisure/motion