summon marker ~ ~ ~ {Tags:["smithed.entity","smithed.strict","blue.tr.bolt.block"]}
execute as @e[tag=blue.tr.bolt.block,distance=..1,type=marker] unless score @s blue.id matches 1.. run scoreboard players operation @s blue.id = #.link blue.id
scoreboard players set #.bolt.vertical blue.misc 0
scoreboard players set #.bolt.horizontal blue.misc 0
scoreboard players set #.cast blue.misc 1
particle electric_spark ~ ~ ~ 0.35 0.35 0.35 0.1 18
playsound entity.firework_rocket.twinkle player @a[distance=..20] ~ ~ ~ 0.75 1.5
execute store result score #.temp blue.misc run random value 1..4
function blue:tr/delayed/cmd/trust/define/main
tag @a[tag=blue.tr.trusted_player,predicate=!blue:shared/id_link] add blue.tr.hit
tag @a[tag=blue.tr.trusted_player] remove blue.tr.trusted_player
execute if score #.temp blue.misc matches 1 rotated ~-50 ~ positioned ^ ^ ^0.2 rotated ~50 ~ run function blue:tr/effects/bolt/conduct/h
execute if score #.temp blue.misc matches 2 rotated ~50 ~ positioned ^ ^ ^0.2 rotated ~-50 ~ run function blue:tr/effects/bolt/conduct/-h
execute if score #.temp blue.misc matches 3 rotated ~ ~-50 positioned ^ ^ ^0.2 rotated ~ ~50 run function blue:tr/effects/bolt/conduct/v
execute if score #.temp blue.misc matches 4 rotated ~ ~50 positioned ^ ^ ^0.2 rotated ~ ~-50 run function blue:tr/effects/bolt/conduct/-v
tag @a[tag=blue.tr.hit] remove blue.tr.hit