execute if score #.temp blue.misc matches 1 run data merge entity @s {Tags:["blue.tr.host.guardian"],active_effects:[{id:"glowing",duration:100},{id:"fire_resistance",duration:1200,amplifier:2},{id:"resistance",duration:1200,amplifier:1},{id:"speed",duration:1200},{id:"weakness",duration:1200}],DeathLootTable:""}
execute if score #.temp blue.misc matches 0 run data merge entity @s {Tags:["blue.tr.host.guardian"],DeathLootTable:""}
scoreboard players operation @s blue.id = #.link blue.id
playsound entity.iron_golem.repair player @a[distance=..40] ~ ~ ~ 1.5 0.5