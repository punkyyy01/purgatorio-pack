execute if entity @s[tag=blue.tr.snout.add_trail] run function blue:tr/effects/snout/gamble/throw/trail
execute store result entity @s Air byte 1 run scoreboard players get #.20 blue.misc
execute unless predicate blue:shared/on_ground run return fail
tag @s remove blue.tr.deflectable
summon text_display ~ ~ ~ {Tags:["blue.tr.gamble.display"],alignment:center,text:'{"text":"#","obfuscated":true,"color":"gold"}',billboard:center,transformation:{scale:[3,3,3],translation:[0f,0.5f,0f],left_rotation:[0,0,0,1],right_rotation:[0,0,0,1]}}
ride @e[tag=blue.tr.gamble.display,predicate=!blue:shared/has_vehicle,type=text_display,distance=..1,limit=1] mount @s
schedule function blue:tr/effects/snout/gamble/item/display 1t
data merge entity @s {PickupDelay:32767s,Age:-32768s,Health:32767s}
particle wax_on ~ ~0.25 ~ 0 0 0 3 8
tag @s add blue.tr.ground
execute on origin unless predicate blue:shared/in_bastion run return fail
scoreboard players set @s blue.misc 32