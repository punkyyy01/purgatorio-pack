execute store result score #.temp blue.misc run time query gametime
execute as @a[scores={blue.tr.current_trim=8}] if score @s blue.tr.schedule_context = #.temp blue.misc run effect clear resistance
execute as @a[scores={blue.tr.current_trim=8}] if score @s blue.tr.schedule_context = #.temp blue.misc at @s run particle smoke ~ ~1.1 ~ 0.2 0.45 0.2 0.01 2