
execute if entity @a[tag=blue.tr.actionbar,limit=1] run schedule function blue:tr/effects/display_reset 2t
title @a[tag=blue.tr.actionbar-2] actionbar ""
tag @a[tag=blue.tr.actionbar-2] remove blue.tr.actionbar
tag @a[tag=blue.tr.actionbar-2] remove blue.tr.actionbar-2
tag @a[tag=blue.tr.actionbar] add blue.tr.actionbar-2