title @s actionbar {"translate":"blue.tr.gamble.throwing","fallback":"Throwing LVL.%s","color":"gray","with":["1"]}
execute unless score @s blue.tr.primary_data matches 400.. run scoreboard players set @s blue.tr.primary_data 400
schedule function blue:tr/effects/snout/gamble/loop 1t
playsound entity.witch.throw player @a[distance=..40] ~ ~ ~ 1.5 1