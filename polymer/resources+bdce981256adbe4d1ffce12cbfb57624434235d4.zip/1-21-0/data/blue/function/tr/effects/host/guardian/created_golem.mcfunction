data modify entity @n[type=iron_golem,tag=!smithed.strict,nbt={PlayerCreated:1b},distance=..9] PlayerCreated set value 0b
advancement revoke @s only blue:tr/ability/host_player_created req