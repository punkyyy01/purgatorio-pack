scoreboard players remove @s[scores={blue.misc=1..}] blue.misc 1
tag @s[tag=blue.tr.eye.tick] remove blue.tr.eye.tick