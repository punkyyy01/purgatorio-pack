title @s actionbar {"translate":"blue.tr.gamble.withdrawal","fallback":"Withdrawal","color":"gray"}
schedule function blue:tr/effects/snout/gamble/loop 1t
scoreboard players set @s blue.tr.secondary_data 800
playsound block.dispenser.launch player @a[distance=..40] ~ ~ ~ 1.5 0.5