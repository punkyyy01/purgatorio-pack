particle mycelium ~ ~-1 ~ 0.2 1 0.2 0 6 force
particle smoke ~ ~-1 ~ 0.4 1 0.4 0.06 16 force
particle lava ~ ~-1 ~ 0.3 1 0.3 0 3 force
particle smoke ~ ~-1 ~ 0.25 1 0.25 0.04 12
effect give @s resistance 2 3 true
effect give @s absorption 2 0 true
playsound entity.lightning_bolt.thunder player @s ~ ~-24 ~ 2 0.5
execute positioned ~-12 ~2 ~-12 run playsound entity.lightning_bolt.thunder player @a[dx=23,dy=-200,dz=23] ~ -128 ~ 0 0.5 0.5
execute unless predicate blue:shared/no_fall_distance unless score @s blue.tr.died matches 1.. run return fail
tag @s remove blue.tr.shaper.falling
particle explosion ~ ~0.5 ~ 0 1 0 0 4
stopsound @a[distance=..80] player entity.lightning_bolt.thunder
execute if block ~ ~-1 ~ #fall_damage_resetting run return run playsound entity.generic.extinguish_fire player @a[distance=..40] ~ ~ ~ 1.5 1.75
execute if block ~ ~ ~ #fall_damage_resetting run return run playsound entity.generic.extinguish_fire player @a[distance=..40] ~ ~ ~ 1.5 1.75
execute if block ~ ~-1 ~ water run return run playsound entity.generic.extinguish_fire player @a[distance=..50] ~ ~ ~ 2.5 0.8
execute if block ~ ~ ~ water run return run playsound entity.generic.extinguish_fire player @a[distance=..50] ~ ~ ~ 2.5 0.8
particle explosion_emitter ~ ~1 ~ 2 1 2 0 4
effect give @s absorption 7 4 true
tag @s add blue.tr.shaper.absorption
summon tnt ~-0.6 ~ ~-0.6 {fuse:0s,Tags:["blue.tr.shaper.impact"]}
summon tnt ~0.6 ~ ~-0.6 {fuse:0s,Tags:["blue.tr.shaper.impact"]}
summon tnt ~-0.6 ~ ~0.6 {fuse:0s,Tags:["blue.tr.shaper.impact"]}
summon tnt ~0.6 ~ ~0.6 {fuse:0s,Tags:["blue.tr.shaper.impact"]}
execute store result storage blue:shared player_id int 1 run scoreboard players get @s blue.id
function blue:shared/get_uuid with storage blue:shared
execute as @e[tag=blue.tr.shaper.impact,type=tnt,distance=..4,limit=4] run data modify entity @s owner set from storage blue:shared UUID