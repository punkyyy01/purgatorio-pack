attribute @s generic.attack_damage modifier remove blue:tr.trim
execute unless biome ~ ~ ~ #blue:shared/sandy run return fail
execute store success score #.temp blue.misc if predicate blue:shared/in_pyramid
execute if score #.temp blue.misc matches 0 run attribute @s generic.attack_damage modifier add blue:tr.trim 1.25 add_value
execute if score #.temp blue.misc matches 0 run return run effect give @s fire_resistance 2 0 true
attribute @s generic.attack_damage modifier add blue:tr.trim 3.75 add_value
effect give @s fire_resistance 11 0 true