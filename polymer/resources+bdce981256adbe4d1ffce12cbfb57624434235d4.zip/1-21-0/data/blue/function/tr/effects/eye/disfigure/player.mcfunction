tag @s add blue.tr.current_tick
function blue:tr/effects/eye/disfigure/cast
tag @s remove blue.tr.current_tick