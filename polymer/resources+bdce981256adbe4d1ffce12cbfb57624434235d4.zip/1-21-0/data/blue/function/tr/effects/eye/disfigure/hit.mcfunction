effect give @s blindness 2 0
scoreboard players add @s[type=player,tag=!blue.tr.current_tick] blue.tr.fear 400
execute if entity @s[type=player] run function blue:tr/delayed/cmd/trust/define/player
execute if entity @s[tag=blue.tr.trusted_player] run return run tag @s remove blue.tr.trusted_player
execute unless score @s blue.tr.fear matches 2400.. run scoreboard players add @s[type=!player] blue.tr.fear 600
damage @s 5 indirect_magic by b163102f-0-64-0-1 from @a[tag=blue.tr.current_tick,limit=1]
effect give @s blindness 8 0
effect give @s slowness 10 0
effect give @s glowing 10 0