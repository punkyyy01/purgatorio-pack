tag @s remove blue.tr.host.channeling
scoreboard players reset @s blue.tr.primary_data
kill b163102f-0-b-0-1