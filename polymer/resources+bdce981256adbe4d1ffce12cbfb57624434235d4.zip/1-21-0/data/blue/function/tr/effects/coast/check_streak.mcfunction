execute store result score #.temp blue.misc run time query day
scoreboard players remove #.temp blue.misc 2
execute unless score #.temp blue.misc = @s blue.tr.third_data run return fail
scoreboard players operation @s blue.tr.secondary_data /= #20 blue.misc
tellraw @s [{"text":"- ","color":"dark_gray"},{"translate":"blue.tr.fishing_streak_lost","fallback":"A full day has passed, ruining your fishing streak of %s days","with":[{"score":{"name":"@s","objective":"blue.tr.secondary_data"},"color":"white"}],"color":"gray"}]
playsound entity.player.splash.high_speed player @s ~ ~ ~ 0.5 0.5
scoreboard players reset @s blue.tr.secondary_data
scoreboard players reset @s blue.tr.third_data