scoreboard players add #.temp0 blue.misc 1
execute unless block ~ ~ ~ #blue:shared/passable run scoreboard players add #.temp0 blue.misc 5
execute if score #.temp blue.misc matches 0 run xp add @s[predicate=blue:r/40c] -1
execute if score #.temp blue.misc matches 1 run xp add @s[predicate=blue:r/10c] -1
execute if score #.temp0 blue.misc <= @s blue.tr.primary_data positioned ^ ^ ^0.125 run function blue:tr/effects/raiser/piercer/cast
execute positioned ~-0.75 ~-0.75 ~-0.75 as @e[type=!#blue:shared/peaceful,dx=0,tag=!blue.tr.current_tick] positioned ~0.5 ~0.5 ~0.5 if entity @s[dx=0] run damage @s 2 blue:tr/piercer by @a[tag=blue.tr.current_tick,distance=..32,limit=1]
particle dust_color_transition{from_color:[0.4f,0.85f,0f],to_color:[0.8f,1f,0f],scale:0.225f} ^ ^ ^0.0625 0.025 0.025 0.025 0 3 normal @a[scores={blue.particles=2..}]
particle dust_color_transition{from_color:[0.4f,0.85f,0f],to_color:[0.8f,1f,0f],scale:0.225f} ^ ^ ^ 0.025 0.025 0.025 0 3