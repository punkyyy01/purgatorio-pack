scoreboard players operation #.temp0 blue.misc = #.temp blue.misc
execute if score #.temp0 blue.misc matches 0 store success score #.temp blue.misc run damage @s 10 blue:tr/fish by @a[tag=blue.tr.current_tick,limit=1]
execute if score #.temp0 blue.misc matches 1 store success score #.temp blue.misc run damage @s 36 blue:tr/fish by @a[tag=blue.tr.current_tick,limit=1]
execute if score #.temp blue.misc matches 0 run return fail
schedule function blue:tr/effects/coast/fire/proj/salmon_cooldown 1t replace
scoreboard players set @s blue.tr.salmon_cooldown 3
scoreboard players set #.temp blue.misc -99
particle rain ^ ^ ^-0.25 0.1 0.1 0.1 0 18
playsound entity.salmon.hurt player @a[distance=..32]
tag @s add blue.tr.salmon_cooldown