playsound entity.player.attack.sweep player @a[distance=..20] ~ ~ ~ 0.5 1.2
particle sweep_attack ~ ~0.5 ~ 0.1 0.1 0.1 0 1
damage @s 5 player_attack