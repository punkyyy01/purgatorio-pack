execute if score #.20 blue.misc matches 15 anchored eyes run function blue:tr/effects/flow/delay
execute store success score @s blue.tr.ambient unless score @s blue.tr.ambient matches 1
execute if score @s blue.tr.ambient matches 0 run particle dust_color_transition{from_color:[0.6f,0.8f,1f],to_color:[1,1,1],scale:0.8f} ~ ~0.1 ~ 0.15 0.05 0.15 0 2 normal @a[scores={blue.particles=1..},distance=..64]
execute if score @s blue.tr.ambient matches 1 run particle dust_color_transition{from_color:[0.6f,0.8f,1f],to_color:[1,1,1],scale:0.8f} ~ ~0.1 ~ 0.15 0.05 0.15 0 2 normal @a[scores={blue.particles=2..},distance=..64]
execute if score @s blue.tr.ambient matches 0 if predicate blue:tr/aerial run particle dust_color_transition{from_color:[0.7f,0.8f,1f],to_color:[1,1,1],scale:0.8f} ~ ~0.9 ~ 0.15 0.25 0.15 0 2 normal @a[distance=0.01..64,scores={blue.particles=1..}]
execute if score @s blue.tr.ambient matches 1 if predicate blue:tr/aerial run particle dust_color_transition{from_color:[0.7f,0.8f,1f],to_color:[1,1,1],scale:0.8f} ~ ~0.9 ~ 0.15 0.25 0.15 0 2 normal @a[distance=0.01..64,scores={blue.particles=2..}]
execute positioned ~ ~0.75 ~ as @e[type=#blue:shared/projectiles,distance=..3,tag=!blue.tr.checked,predicate=blue:shared/moving,tag=!smithed.strict] at @s run function blue:tr/effects/flow/barrier/projectile
execute as @e[tag=!blue.tr.checked,predicate=!blue:tr/barrage,distance=..6,type=item] if function blue:tr/effects/flow/air run function blue:tr/effects/flow/barrage/dropped
execute if score @s blue.tr.primary_data matches 1.. run return run function blue:tr/effects/flow/barrage/loop
attribute @s generic.gravity modifier remove blue:tr.trim
execute if entity @s[tag=!blue.tr.flow.in_chamber,x_rotation=-90..-12,predicate=!blue:shared/is_sneaking] run return run attribute @s generic.gravity modifier add blue:tr.trim -0.05 add_value
execute if entity @s[x_rotation=40..90,predicate=blue:shared/is_sneaking] run return run attribute @s generic.gravity modifier add blue:tr.trim 0.04 add_value
execute unless entity @s[tag=blue.tr.flow.in_chamber] run return run attribute @s generic.gravity modifier add blue:tr.trim -0.03 add_value
execute if entity @s[x_rotation=-90..-12,predicate=!blue:shared/is_sneaking] run return run attribute @s generic.gravity modifier add blue:tr.trim -0.06 add_value
attribute @s generic.gravity modifier add blue:tr.trim -0.04 add_value