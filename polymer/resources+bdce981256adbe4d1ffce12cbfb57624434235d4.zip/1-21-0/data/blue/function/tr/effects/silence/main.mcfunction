scoreboard players add @s blue.tr.ambient 1
execute if score @s blue.tr.primary_data matches 1.. run function blue:tr/effects/silence/vortex/armor
execute if score #.60 blue.misc matches 40 if score @s blue.tr.combat matches ..-100 as @a[distance=..9,predicate=!blue:tr/anti_darkness,gamemode=!spectator,gamemode=!creative] at @s run function blue:tr/effects/silence/darkness
execute if score @s blue.tr.ambient matches 11.. store success score @s blue.tr.ambient run particle sculk_soul ~ ~0.8 ~ 0.2 0.35 0.2 0.01 1 normal @a[scores={blue.particles=1..},distance=..64]
execute if score @s blue.tr.ambient matches 6 run particle sculk_soul ~ ~0.8 ~ 0.2 0.35 0.2 0.01 2 normal @a[scores={blue.particles=2..},distance=..64]
execute if score #.60 blue.misc matches 15 if entity @e[distance=..100,limit=1,type=warden] run function blue:tr/effects/silence/warden_team
execute as @e[tag=!blue.tr.checked,distance=..5,predicate=blue:tr/vortex,limit=1,type=item] run function blue:tr/effects/silence/vortex/throw_check
execute unless biome ~ ~ ~ deep_dark run return fail
particle sculk_charge_pop ~ ~0.8 ~ 0.25 0.3 0.25 0 1
execute unless score @s blue.tr.ambient matches 3.. facing entity @a[distance=4..24,predicate=!blue:tr/silence_track,gamemode=!spectator] feet run particle sculk_charge_pop ~ ~0.5 ~ ^ ^ ^10000000 0.00000002 0 force @s
execute unless score #.20 blue.misc matches 7 run return fail
playsound entity.warden.heartbeat master @a[tag=blue.tr.trim.ward,distance=..48,limit=1] ~ ~ ~ 2 0.9
playsound entity.warden.heartbeat master @a[tag=!blue.tr.trim.ward,distance=..32] ~ ~ ~ 1.4 0.9
effect give @s strength 8 0 true
effect give @s speed 8 0 true