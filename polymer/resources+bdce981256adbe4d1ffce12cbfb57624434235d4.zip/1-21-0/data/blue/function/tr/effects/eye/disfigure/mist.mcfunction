execute if predicate blue:shared/is_sneaking run function blue:tr/effects/eye/disfigure/tp
particle large_smoke ~ ~ ~ 0 0 0 0.25 250
particle large_smoke ~ ~ ~ 0 0 0 0.25 100 force
particle large_smoke ~ ~ ~ 0 0 0 0.25 100 force @a[scores={blue.particles=2..}]
particle large_smoke ~ ~ ~ 0 0 0 0.25 250 normal @a[scores={blue.particles=2..}]
particle scrape ~ ~ ~ 0 0 0 28 250
particle scrape ~ ~ ~ 0 0 0 28 100 force
particle scrape ~ ~ ~ 0 0 0 28 100 force @a[scores={blue.particles=2..}]
particle scrape ~ ~ ~ 0 0 0 28 250 normal @a[scores={blue.particles=2..}]
particle glow_squid_ink ~ ~0.5 ~ 0 0 0 0.35 75
particle glow_squid_ink ~ ~0.5 ~ 0 0 0 0.35 40 force
particle glow_squid_ink ~ ~0.5 ~ 0 0 0 0.35 40 force @a[scores={blue.particles=2..}]
particle glow_squid_ink ~ ~0.5 ~ 0 0 0 0.35 75 normal @a[scores={blue.particles=2..}]
summon marker ~ ~ ~ {UUID:[I;-1318907857,100,0,1]}
execute store result storage blue:trims temp.id int 1 run scoreboard players get @s blue.id
execute as @e[type=!#blue:shared/peaceful,predicate=!blue:shared/gamemode,distance=0.01..14] run function blue:tr/effects/eye/disfigure/hit
kill b163102f-0-64-0-1
playsound entity.glow_squid.squirt player @a[tag=blue.tr.current_tick,limit=1] ~ ~ ~ 0 0.6 1
playsound entity.glow_squid.squirt player @a[tag=blue.tr.current_tick,limit=1] ~ ~ ~ 0 0.6 1
playsound entity.glow_squid.squirt player @a[distance=..50] ~ ~ ~ 2.5 0.6