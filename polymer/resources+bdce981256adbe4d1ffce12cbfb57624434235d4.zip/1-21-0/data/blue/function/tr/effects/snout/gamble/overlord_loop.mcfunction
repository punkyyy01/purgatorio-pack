scoreboard players remove @a[scores={blue.tr.current_trim=10,blue.tr.third_data=1..}] blue.tr.third_data 1
execute at @a[scores={blue.tr.current_trim=10,blue.tr.third_data=1..}] run particle item{item:raw_gold_block} ~ ~1 ~ 0.3 0.4 0.3 0.05 2
execute if entity @a[scores={blue.tr.current_trim=10,blue.tr.third_data=1..},limit=1] run schedule function blue:tr/effects/snout/gamble/overlord_loop 1t