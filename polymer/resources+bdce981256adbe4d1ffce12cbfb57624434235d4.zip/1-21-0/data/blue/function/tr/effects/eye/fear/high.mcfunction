particle glow ~ ~1 ~ 0 0.4 0 0.1 3 force
particle glow ~ ~1 ~ 0 0.4 0 0.1 3 force @a[scores={blue.tr.current_trim=3,blue.particles=1..}]
execute if score #.temp blue.misc matches 45..46 run return run tp @s @s
execute if score #.temp blue.misc matches 47..48 run return run function blue:tr/effects/eye/fear/damage
execute if score #.temp blue.misc matches 51..54 run effect give @s glowing 8 0 true
execute if score #.temp blue.misc matches 49..50 run return run effect give @s blindness 5 0
execute if score #.temp blue.misc matches 51..52 run return run function blue:tr/effects/eye/fear/float_medium
execute if score #.temp blue.misc matches 53 run return run tp @s ~ ~ ~ facing entity @e[sort=random,limit=1,distance=..32]
execute if score #.temp blue.misc matches 54 run return run function blue:tr/effects/eye/fear/float_strong
execute if score #.temp blue.misc matches 55 run return run playsound item.totem.use player @s ~ ~ ~ 0.9 1
execute if score #.temp blue.misc matches 56 run return run effect give @s slowness 2 100
execute if score #.temp blue.misc matches 57 run return run effect give @s weakness 2 100
execute if score #.temp blue.misc matches 58 run return run function blue:tr/effects/eye/fear/fake_death
execute if score #.temp blue.misc matches 59.. run particle glow ~ ~8 ~ 0.2 8 0.2 0 32 normal @a[scores={blue.tr.current_trim=3}]
execute if score #.temp blue.misc matches 59 run return run function blue:tr/effects/eye/fear/job
execute if score #.temp blue.misc matches 60 run return run function blue:tr/effects/eye/fear/curse
execute if score #.temp blue.misc matches 61..62 run return run function blue:tr/effects/eye/fear/motion
execute unless score #.temp blue.misc matches 63 run return fail
playsound entity.warden.attack_impact player @s ~ ~ ~ 2.5 0.5
schedule function blue:tr/effects/eye/fear/fake_throw 5t
tag @s add blue.tr.fake_throw