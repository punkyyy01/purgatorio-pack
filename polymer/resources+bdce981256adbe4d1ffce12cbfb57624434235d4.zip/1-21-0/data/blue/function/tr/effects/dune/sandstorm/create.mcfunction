scoreboard players set #.temp blue.misc -592
scoreboard players operation #.link blue.id = @s blue.id
playsound item.brush.brushing.sand.complete player @a[x=0] ~ ~ ~ 3 0.5
playsound item.brush.brushing.sand.complete player @a[x=0] ~ ~ ~ 3 0.5
execute store result score #.temp0 blue.misc if entity @e[tag=blue.tr.dune.sandstorm,predicate=blue:shared/id_link,type=marker,limit=2,distance=..32]
execute if score #.temp0 blue.misc matches 2 run return run scoreboard players remove @e[tag=blue.tr.dune.sandstorm,predicate=blue:shared/id_link,type=marker,distance=..16,sort=nearest,limit=1] blue.misc 30
playsound entity.lightning_bolt.impact player @a[distance=..20] ~ ~ ~ 0.5 1.25
playsound item.elytra.flying player @a ~ ~ ~ 1.5 1.75
summon marker ~ ~ ~ {Tags:["blue.tr.dune.sandstorm"]}
execute as @e[tag=blue.tr.dune.sandstorm,type=marker,distance=..1] unless score @s blue.id matches 1.. run scoreboard players operation @s blue.id = #.link blue.id
schedule function blue:tr/effects/dune/sandstorm/loop 1t
effect give @s invisibility 8 0
effect give @s speed 4 2 true