execute store result score #.temp blue.misc run time query gametime
execute as @e[tag=blue.tr.gamble.apple,type=text_display] if score @s blue.tr.schedule_context = #.temp blue.misc run kill