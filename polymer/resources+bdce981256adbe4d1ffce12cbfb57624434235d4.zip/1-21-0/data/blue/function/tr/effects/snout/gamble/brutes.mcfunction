damage @s 0 blue:tr/sacrifice by @a[tag=blue.tr.current_tick,limit=1]
particle small_flame ~ ~1 ~ 0.3 0.4 0.3 0.02 48
tag @s remove blue.tr.gamble.punisher_new
effect give @s strength 120 0 true
effect give @s speed 120 0 true