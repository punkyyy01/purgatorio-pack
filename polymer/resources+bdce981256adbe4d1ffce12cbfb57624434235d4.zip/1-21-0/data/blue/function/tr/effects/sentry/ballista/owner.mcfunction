execute on origin if entity @s[tag=blue.tr.current_tick] run scoreboard players set #.temp blue.misc -81234
execute if score #.temp blue.misc matches -81234 run kill