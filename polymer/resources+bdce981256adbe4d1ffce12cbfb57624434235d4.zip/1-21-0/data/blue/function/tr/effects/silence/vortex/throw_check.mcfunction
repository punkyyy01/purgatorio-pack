execute on origin if entity @s[tag=blue.tr.current_tick] run scoreboard players set #.temp blue.misc -633
execute unless score #.temp blue.misc matches -633 run return fail
execute store result score #.temp blue.misc run data get entity @s Item.count
execute on origin if entity @s[advancements={blue:tr/tags={tutorial_vortex=false}}] if score #.temp blue.misc matches 1 run function blue:tr/effects/silence/vortex/tutorial
execute unless score #.temp blue.misc matches 32.. run return fail
execute on origin run scoreboard players operation #.temp blue.tr.primary_cooldown = @s blue.tr.primary_cooldown
execute if score #.temp blue.tr.primary_cooldown matches 1.. on origin run function blue:tr/effects/display_primary_cooldown
execute if score #.temp blue.tr.primary_cooldown matches 1.. run return run function blue:tr/inv/item/quick_return
scoreboard players remove #.temp blue.misc 32
execute on origin run loot give @s loot blue:tr/z/vortex_refund
execute on origin at @s run function blue:tr/effects/silence/vortex/throw
kill