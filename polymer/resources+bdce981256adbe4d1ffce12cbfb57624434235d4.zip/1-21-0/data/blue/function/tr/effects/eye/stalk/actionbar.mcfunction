execute store result score #.temp blue.misc run time query gametime
execute as @a[scores={blue.tr.current_trim=3}] if score @s blue.tr.schedule_context = #.temp blue.misc run title @s actionbar ""