advancement revoke @s only blue:tr/ability/harvester
execute rotated ~ 0 run loot spawn ^ ^0.5 ^1.5 loot blue:tr/z/harvester