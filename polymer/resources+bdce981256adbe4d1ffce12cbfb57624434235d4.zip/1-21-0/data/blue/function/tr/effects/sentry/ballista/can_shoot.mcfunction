execute if score @s blue.tr.primary_cooldown matches 1.. run return run function blue:tr/effects/display_primary_cooldown
scoreboard players operation @s blue.tr.primary_data += #.sentry.charge_speed blue.config
scoreboard players set @s blue.tr.third_data 125
execute if score @s blue.tr.third_data matches 125 if predicate {condition:"entity_properties","type":"entity_properties",entity:"this",predicate:{effects:{"hero_of_the_village":{amplifier:1}}}} run scoreboard players set @s blue.tr.third_data 150
execute if score @s blue.tr.third_data matches 125 if predicate {condition:"entity_properties","type":"entity_properties",entity:"this",predicate:{effects:{"hero_of_the_village":{amplifier:2}}}} run scoreboard players set @s blue.tr.third_data 175
execute if score @s blue.tr.third_data matches 125 if predicate {condition:"entity_properties","type":"entity_properties",entity:"this",predicate:{effects:{"hero_of_the_village":{amplifier:3}}}} run scoreboard players set @s blue.tr.third_data 200
execute if score @s blue.tr.third_data matches 125 if predicate {condition:"entity_properties","type":"entity_properties",entity:"this",predicate:{effects:{"hero_of_the_village":{amplifier:{min:4}}}}} run scoreboard players set @s blue.tr.third_data 225
execute if score @s blue.tr.primary_data matches 480.. run function blue:tr/effects/sentry/ballista/circle
execute if score @s blue.tr.primary_data matches 90..209 run effect give @s slowness 1 1
execute if score @s blue.tr.primary_data matches 210..329 run effect give @s slowness 1 3
execute if score @s blue.tr.primary_data matches 330..449 run effect give @s slowness 1 5
execute if score @s blue.tr.primary_data matches 450.. run effect give @s slowness 1 7
execute if score @s blue.tr.primary_data matches 30.. run particle dust{color:[0f,0.5f,0.6f],scale:0.2} ^ ^0.30 ^2.8 0.025 0.025 0.025 0 2 normal @a[distance=..32]
execute if score @s blue.tr.primary_data matches 60.. run particle dust{color:[0f,0.5f,0.6f],scale:0.2} ^-0.12 ^0.28 ^2.8 0.025 0.025 0.025 0 2 normal @a[distance=..32]
execute if score @s blue.tr.primary_data matches 90.. run particle dust{color:[0f,0.5f,0.6f],scale:0.2} ^-0.21 ^0.21 ^2.8 0.025 0.025 0.025 0 2 normal @a[distance=..32]
execute if score @s blue.tr.primary_data matches 120.. run particle dust{color:[0f,0.5f,0.6f],scale:0.2} ^-0.28 ^0.12 ^2.8 0.025 0.025 0.025 0 2 normal @a[distance=..32]
execute if score @s blue.tr.primary_data matches 150.. run particle dust{color:[0f,0.5f,0.6f],scale:0.2} ^-0.30 ^ ^2.8 0.025 0.025 0.025 0 2 normal @a[distance=..32]
execute if score @s blue.tr.primary_data matches 180.. run particle dust{color:[0f,0.5f,0.6f],scale:0.2} ^-0.28 ^-0.12 ^2.8 0.025 0.025 0.025 0 2 normal @a[distance=..32]
execute if score @s blue.tr.primary_data matches 210.. run particle dust{color:[0f,0.5f,0.6f],scale:0.2} ^-0.21 ^-0.21 ^2.8 0.025 0.025 0.025 0 2 normal @a[distance=..32]
execute if score @s blue.tr.primary_data matches 240.. run particle dust{color:[0f,0.5f,0.6f],scale:0.2} ^-0.12 ^-0.28 ^2.8 0.025 0.025 0.025 0 2 normal @a[distance=..32]
execute if score @s blue.tr.primary_data matches 270.. run particle dust{color:[0f,0.5f,0.6f],scale:0.2} ^ ^-0.30 ^2.8 0.025 0.025 0.025 0 2 normal @a[distance=..32]
execute if score @s blue.tr.primary_data matches 300.. run particle dust{color:[0f,0.5f,0.6f],scale:0.2} ^0.12 ^-0.28 ^2.8 0.025 0.025 0.025 0 2 normal @a[distance=..32]
execute if score @s blue.tr.primary_data matches 330.. run particle dust{color:[0f,0.5f,0.6f],scale:0.2} ^0.21 ^-0.21 ^2.8 0.025 0.025 0.025 0 2 normal @a[distance=..32]
execute if score @s blue.tr.primary_data matches 360.. run particle dust{color:[0f,0.5f,0.6f],scale:0.2} ^0.28 ^-0.12 ^2.8 0.025 0.025 0.025 0 2 normal @a[distance=..32]
execute if score @s blue.tr.primary_data matches 390.. run particle dust{color:[0f,0.5f,0.6f],scale:0.2} ^0.30 ^ ^2.8 0.025 0.025 0.025 0 2 normal @a[distance=..32]
execute if score @s blue.tr.primary_data matches 420.. run particle dust{color:[0f,0.5f,0.6f],scale:0.2} ^0.28 ^0.12 ^2.8 0.025 0.025 0.025 0 2 normal @a[distance=..32]
execute if score @s blue.tr.primary_data matches 450.. run particle dust{color:[0f,0.5f,0.6f],scale:0.2} ^0.21 ^0.21 ^2.8 0.025 0.025 0.025 0 2 normal @a[distance=..32]
execute if score @s blue.tr.third_data matches 150.. if score @s blue.tr.primary_data matches 90.. run particle enchanted_hit ^-0.25 ^0.25 ^3 ^-9000000 ^9000000 ^-20000000 0.000000085 0 force
execute if score @s blue.tr.third_data matches 150.. if score @s blue.tr.primary_data matches 90.. run particle enchanted_hit ^-0.4 ^0.4 ^2.8 ^-8500000 ^8500000 ^-19000000 0.000000085 0
execute if score @s blue.tr.third_data matches 175.. if score @s blue.tr.primary_data matches 210.. run particle enchanted_hit ^-0.25 ^-0.25 ^3 ^-9000000 ^-9000000 ^-20000000 0.000000085 0 force
execute if score @s blue.tr.third_data matches 175.. if score @s blue.tr.primary_data matches 210.. run particle enchanted_hit ^-0.4 ^-0.4 ^2.8 ^-8500000 ^-8500000 ^-19000000 0.000000085 0
execute if score @s blue.tr.third_data matches 200.. if score @s blue.tr.primary_data matches 330.. run particle enchanted_hit ^0.25 ^-0.25 ^3 ^9000000 ^-9000000 ^-20000000 0.000000085 0 force
execute if score @s blue.tr.third_data matches 200.. if score @s blue.tr.primary_data matches 330.. run particle enchanted_hit ^0.4 ^-0.4 ^2.8 ^8500000 ^-8500000 ^-19000000 0.000000085 0
execute if score @s blue.tr.third_data matches 225 if score @s blue.tr.primary_data matches 450.. run particle enchanted_hit ^0.25 ^0.25 ^3 ^9000000 ^9000000 ^-20000000 0.000000085 0 force
execute if score @s blue.tr.third_data matches 225 if score @s blue.tr.primary_data matches 450.. run particle enchanted_hit ^0.4 ^0.4 ^2.8 ^8500000 ^8500000 ^-19000000 0.000000085 0
execute if score @s blue.tr.primary_data matches 480.. run scoreboard players operation #.temp blue.misc = @s blue.tr.third_data
execute if score @s blue.tr.primary_data matches 480.. positioned ^ ^ ^5 run function blue:tr/effects/sentry/ballista/pre_cast
execute if score @s blue.tr.primary_data matches 90.. unless score @s blue.tr.fourth_data matches 2.. if score @s blue.tr.third_data matches 150.. run playsound block.smithing_table.use player @a[distance=..20] ~ ~ ~ 0.5 1.25
execute if score @s blue.tr.primary_data matches 90.. unless score @s blue.tr.fourth_data matches 2.. run scoreboard players set @s blue.tr.fourth_data 2
execute if score @s blue.tr.primary_data matches 210.. unless score @s blue.tr.fourth_data matches 3.. if score @s blue.tr.third_data matches 175.. run playsound block.smithing_table.use player @a[distance=..20] ~ ~ ~ 0.55 1.5
execute if score @s blue.tr.primary_data matches 210.. unless score @s blue.tr.fourth_data matches 3.. run scoreboard players set @s blue.tr.fourth_data 3
execute if score @s blue.tr.primary_data matches 330.. unless score @s blue.tr.fourth_data matches 4.. if score @s blue.tr.third_data matches 200.. run playsound block.smithing_table.use player @a[distance=..20] ~ ~ ~ 0.6 1.75
execute if score @s blue.tr.primary_data matches 330.. unless score @s blue.tr.fourth_data matches 4.. run scoreboard players set @s blue.tr.fourth_data 4
execute if score @s blue.tr.primary_data matches 450.. unless score @s blue.tr.fourth_data matches 5.. if score @s blue.tr.third_data matches 225 run playsound block.smithing_table.use player @a[distance=..20] ~ ~ ~ 0.65 2
execute if score @s blue.tr.primary_data matches 450.. unless score @s blue.tr.fourth_data matches 5.. run scoreboard players set @s blue.tr.fourth_data 5