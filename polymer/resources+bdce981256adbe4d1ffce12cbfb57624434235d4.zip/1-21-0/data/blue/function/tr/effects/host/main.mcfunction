execute if score #.60 blue.misc matches 44 run function blue:tr/effects/host/effects
execute store result storage blue:trims temp.id int 1 run scoreboard players get @s blue.id
execute as @a[distance=..22] run function blue:tr/effects/host/check_trust
execute as @a[tag=blue.tr.trusted_player,distance=0.01..18,gamemode=!spectator,gamemode=!creative] at @s run function blue:tr/effects/host/morale-player
tag @s[tag=blue.tr.host.channeling] remove blue.tr.host.channeling
execute if predicate blue:shared/is_sneaking if entity @e[type=#blue:tr/exchangeable,distance=..22,limit=1] run function blue:tr/effects/host/exchange/channel
execute if score @s blue.tr.primary_data matches 1.. unless entity @s[tag=blue.tr.host.channeling] run function blue:tr/effects/host/exchange/cancel
execute store success score @s blue.tr.ambient unless score @s blue.tr.ambient matches 1
execute if score @s blue.tr.ambient matches 0 run particle dust_color_transition{from_color:[0.9f,0.2f,0.2f],scale:0.6f,to_color:[0.1f,0f,0f]} ~ ~0.8 ~ 0.25 0.3 0.25 0 1 normal @a[scores={blue.particles=1..},distance=..64]
execute if score #.20 blue.misc matches 15 at @a[scores={blue.health=..10},tag=blue.tr.trusted_player,gamemode=!spectator,gamemode=!creative,distance=0.01..18] run particle damage_indicator ~ ~2.25 ~ 0.2 0 0.2 0 2 force @s
execute if score @s blue.tr.combat matches -59 on attacker run function blue:tr/effects/host/guardian/spawn
execute unless score #.20 blue.misc matches 5 run return run tag @a[tag=blue.tr.trusted_player] remove blue.tr.trusted_player
execute at @a[scores={blue.health=..10},tag=blue.tr.trusted_player,gamemode=!spectator,gamemode=!creative,distance=0.01..18] run particle damage_indicator ~ ~2.25 ~ 0.2 0 0.2 0 2 force @s
execute store result score #.temp blue.misc if entity @e[distance=..24,limit=32,type=villager]
scoreboard players operation #.temp blue.misc *= #5 blue.misc
execute as @e[distance=..22,limit=6,type=iron_golem] run scoreboard players add #.temp blue.misc 20
execute as @a[tag=blue.tr.trusted_player,gamemode=!spectator,gamemode=!creative,distance=0.01..20,limit=3] run scoreboard players add #.temp blue.misc 50
tag @a[tag=blue.tr.trusted_player] remove blue.tr.trusted_player
execute if predicate blue:shared/in_village run scoreboard players add #.temp blue.misc 15
execute if score @s blue.tr.ambient matches 1 if score #.temp blue.misc matches 1.. run particle dust_color_transition{from_color:[0.9f,0.2f,0.2f],scale:0.6f,to_color:[0.1f,0f,0f]} ~ ~0.8 ~ 0.25 0.3 0.25 0 1 normal @a[scores={blue.particles=2..},distance=..64]
attribute @s generic.max_health modifier remove blue:tr.trim
execute if score #.temp blue.misc matches 160.. run attribute @s[advancements={blue:tr/cure={7=true}}] generic.max_health modifier add blue:tr.trim 15.2 add_value
execute if score #.temp blue.misc matches 140.. run attribute @s[advancements={blue:tr/cure={6=true}}] generic.max_health modifier add blue:tr.trim 12.6 add_value
execute if score #.temp blue.misc matches 120.. run attribute @s[advancements={blue:tr/cure={5=true}}] generic.max_health modifier add blue:tr.trim 10 add_value
execute if score #.temp blue.misc matches 80.. run attribute @s[advancements={blue:tr/cure={4=true}}] generic.max_health modifier add blue:tr.trim 8 add_value
execute if score #.temp blue.misc matches 60.. run attribute @s[advancements={blue:tr/cure={3=true}}] generic.max_health modifier add blue:tr.trim 6 add_value
execute if score #.temp blue.misc matches 40.. run attribute @s[advancements={blue:tr/cure={2=true}}] generic.max_health modifier add blue:tr.trim 4 add_value
execute if score #.temp blue.misc matches 20.. run attribute @s[advancements={blue:tr/cure={1=true}}] generic.max_health modifier add blue:tr.trim 2 add_value
execute if score #.temp blue.misc matches ..0 run attribute @s generic.max_health modifier add blue:tr.trim -2 add_value