execute if predicate blue:r/25c as @a[tag=blue.tr.current_tick,distance=..16,limit=1] unless score @s blue.tr.fourth_data matches 1.. run scoreboard players set @s blue.tr.fourth_data 200
execute if score #.temp blue.misc matches 1 store result storage blue:trims temp.float float 0.1 run random value -40..40
execute if score #.temp blue.misc matches 1 store result storage blue:trims temp.f2 float 0.1 run random value -40..40
execute if score #.temp blue.misc matches 0 store result storage blue:trims temp.float float 0.1 run random value -20..20
execute if score #.temp blue.misc matches 0 store result storage blue:trims temp.f2 float 0.1 run random value -20..20
function blue:tr/effects/coast/fire/rot-m with storage blue:trims temp
data merge entity @s {Tags:["blue.tr.coast.projectile","blue.tr.coast.salmon","blue.tr.entity","smithed.entity"],teleport_duration:1,item:{id:salmon},transformation:{scale:[0.5f,0.5f,0.5f],left_rotation:[-0.28f,-0.65f,0.28f,0.65f]}}
playsound entity.salmon.death player @a[distance=..20] ~ ~ ~ 1 1.5
playsound entity.vex.hurt player @a[distance=..20] ~ ~ ~ 0.8 1.6
scoreboard players set @a[tag=blue.tr.current_tick,distance=..16,limit=1] blue.tr.primary_cooldown 12
execute if score #.temp0 blue.misc matches -597 run scoreboard players set @s blue.misc -2
execute if score #.coast.bonus blue.misc matches 2.. run scoreboard players remove @s blue.misc 3
execute if score #.coast.bonus blue.misc matches 2.. run scoreboard players remove @a[tag=blue.tr.current_tick,distance=..16,limit=1] blue.tr.primary_data 2
scoreboard players operation @s blue.id = #.link blue.id
execute if dimension the_nether run scoreboard players add @s blue.misc 1