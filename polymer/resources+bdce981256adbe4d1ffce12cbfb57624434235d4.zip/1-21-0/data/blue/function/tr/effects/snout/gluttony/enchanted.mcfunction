scoreboard players operation #.link blue.id = @s blue.id
kill @e[tag=blue.tr.gamble.apple,type=text_display,predicate=blue:shared/id_link]
data modify storage blue:trims display set value []
tag @s add blue.tr.current_tick
execute store result storage blue:trims temp.id int 1 run scoreboard players get @s blue.id
execute as @a[distance=..32] run function blue:tr/delayed/cmd/trust/define/player
function blue:tr/effects/snout/gluttony/instant
execute unless score @s blue.tr.fourth_data matches 1.. run function blue:tr/effects/snout/gluttony/instant
execute unless score @s blue.tr.fourth_data matches 2 run function blue:tr/effects/snout/gluttony/instant
tag @a[tag=blue.tr.trusted_player] remove blue.tr.trusted_player
tag @s remove blue.tr.current_tick
data remove storage blue:trims display[-1]
execute unless score @s blue.tr.fourth_data matches 2.. run scoreboard players add @s blue.tr.fourth_data 1
execute store result score #.temp blue.misc run time query gametime
execute store result score @s blue.tr.schedule_context run schedule function blue:tr/effects/snout/gluttony/reduction 20s append
execute anchored eyes rotated 0 0 positioned ^ ^0.5 ^ summon text_display run function blue:tr/effects/snout/gluttony/spawn