function blue:tr/delayed/cmd/trim_messages
scoreboard players set #.template_loot blue.misc 4
execute if score #.tr.objective_announcements blue.config matches 1 run tellraw @a ["",{"text":"- ","color":"dark_gray"},{"selector":"@s"}," ",{"translate":"blue.tr.announce_completion","fallback":"has completed the objective for","color":"gray"}," ",{"storage":"blue:trims","nbt":"logs.append.trim","interpret":true}]
function blue:shared/get_name
function blue:tr/completion/z/list
advancement grant @s[advancements={blue:tr/tags={trim_limit=false}}] only blue:tr/tags trim_limit
advancement grant @s[advancements={blue:tr/display/guides/ownership=false}] only blue:tr/display/guides/ownership
data modify storage blue:trims logs.completion append from storage blue:trims logs.append
schedule function blue:tr/completion/z/delay 2t
advancement grant @s only blue:tr/inv_checks
tag @s add blue.tr.rtd_cooldown