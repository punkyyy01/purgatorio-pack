execute store result score #.temp blue.misc run time query gametime
execute as @a[tag=blue.tr.shaper] if score @s blue.tr.schedule_context = #.temp blue.misc at @s as @e[type=!#blue:shared/peaceful,distance=0.01..9] run damage @s 16 player_explosion by @p[tag=blue.tr.shaper]
execute as @a[tag=blue.tr.shaper] if score @s blue.tr.schedule_context = #.temp blue.misc at @s run playsound entity.generic.explode player @a[distance=..50] ~ ~ ~ 2.5 0.7
execute as @a[tag=blue.tr.shaper] if score @s blue.tr.schedule_context = #.temp blue.misc at @s run particle smoke ~ ~1 ~ 1 0.8 1 0.35 400
execute as @a[tag=blue.tr.shaper] if score @s blue.tr.schedule_context = #.temp blue.misc at @s run particle explosion_emitter ~ ~ ~ 1.5 1.5 1.5 0 3