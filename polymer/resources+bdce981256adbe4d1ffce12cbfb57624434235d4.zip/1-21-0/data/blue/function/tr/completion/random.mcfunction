data modify storage blue:trims temp.random set value []
execute unless entity @s[tag=blue.tr.rib] run data modify storage blue:trims temp.random append value {id:"rib"}
execute unless entity @s[tag=blue.tr.silence] run data modify storage blue:trims temp.random append value {id:"silence"}
execute unless entity @s[tag=blue.tr.tide] run data modify storage blue:trims temp.random append value {id:"tide"}
execute unless entity @s[tag=blue.tr.shaper] run data modify storage blue:trims temp.random append value {id:"shaper"}
execute unless entity @s[tag=blue.tr.spire] run data modify storage blue:trims temp.random append value {id:"spire"}
execute unless entity @s[tag=blue.tr.eye] run data modify storage blue:trims temp.random append value {id:"eye"}
execute unless entity @s[tag=blue.tr.vex] run data modify storage blue:trims temp.random append value {id:"vex"}
execute unless entity @s[tag=blue.tr.flow] run data modify storage blue:trims temp.random append value {id:"flow"}
execute unless entity @s[tag=blue.tr.wayfinder] run data modify storage blue:trims temp.random append value {id:"wayfinder"}
execute unless entity @s[tag=blue.tr.wild] run data modify storage blue:trims temp.random append value {id:"wild"}
execute unless entity @s[tag=blue.tr.raiser] run data modify storage blue:trims temp.random append value {id:"raiser"}
execute unless entity @s[tag=blue.tr.snout] run data modify storage blue:trims temp.random append value {id:"snout"}
execute unless entity @s[tag=blue.tr.dune] run data modify storage blue:trims temp.random append value {id:"dune"}
execute unless entity @s[tag=blue.tr.sentry] run data modify storage blue:trims temp.random append value {id:"sentry"}
execute unless entity @s[tag=blue.tr.host] run data modify storage blue:trims temp.random append value {id:"host"}
execute unless entity @s[tag=blue.tr.coast] run data modify storage blue:trims temp.random append value {id:"coast"}
execute unless entity @s[tag=blue.tr.ward] run data modify storage blue:trims temp.random append value {id:"ward"}
execute unless entity @s[tag=blue.tr.bolt] run data modify storage blue:trims temp.random append value {id:"bolt"}
execute store result score #.temp blue.misc run data get storage blue:trims temp.random
execute store result storage blue:trims temp.int int 1 run scoreboard players remove #.temp blue.misc 1
function blue:tr/completion/z/get_index with storage blue:trims temp
function blue:tr/completion/z/randomize with storage blue:trims temp