tag @s add blue.tr.spire
advancement grant @a only blue:tr/display/spire
scoreboard players set @s blue.tr.dragons_killed 0
execute if score #.tr.objective_completion blue.config matches 1 run scoreboard players set #.tr.spire_completed blue.config 1
advancement revoke @s only blue:tr/quests/spire_crystals
data modify storage blue:trims logs.append.trim set value {"translate":"Spire","color":"#BE20C7"}
scoreboard players set #.temp blue.misc 11
data modify storage blue:trims temp.list set from storage blue:trims owners.spire
function blue:tr/completion/z/setup
data modify storage blue:trims owners.spire set from storage blue:trims temp.list
loot give @s loot blue:tr/spire
execute store result score #.temp blue.misc run clear @s spire_armor_trim_smithing_template 0
execute if score #.temp blue.misc matches 0 run scoreboard players set #.spire_stored blue.misc 4
scoreboard players set #.template_loot blue.misc 1
scoreboard players set @s blue.tr.primary_data 54
execute rotated 0 0 positioned ~ ~-0.25 ~ run function blue:tr/effects/spire/reversal/charge
scoreboard players reset @s blue.tr.primary_data
effect give @s levitation 1 25 true
execute store result score @s blue.tr.schedule_context run schedule function blue:tr/completion/z/levi 3t append