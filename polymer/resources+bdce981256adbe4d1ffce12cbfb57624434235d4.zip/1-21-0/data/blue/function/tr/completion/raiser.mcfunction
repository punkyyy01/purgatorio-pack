tag @s add blue.tr.raiser
advancement grant @a only blue:tr/display/raiser
scoreboard players set @s blue.tr.items_enchanted 0
execute if score #.tr.objective_completion blue.config matches 1 run scoreboard players set #.tr.raiser_completed blue.config 1
advancement revoke @s only blue:tr/quests/raiser
data modify storage blue:trims logs.append.trim set value {"translate":"Raiser","color":"#95B623"}
scoreboard players set #.temp blue.misc 5
data modify storage blue:trims temp.list set from storage blue:trims owners.raiser
function blue:tr/completion/z/setup
data modify storage blue:trims owners.raiser set from storage blue:trims temp.list
loot give @s loot blue:tr/raiser
execute store result score #.temp blue.misc run clear @s raiser_armor_trim_smithing_template 0
execute if score #.temp blue.misc matches 0 run scoreboard players set #.raiser_stored blue.misc 4
scoreboard players set #.template_loot blue.misc 1
effect give @s haste 7 5 true
effect give @s speed 7 0 true
effect give @s speed 6 1 true
effect give @s speed 5 2 true
effect give @s speed 3 3 true
effect give @s speed 2 4 true
effect give @s speed 1 5 true
effect give @s strength 7 3 true
xp add @s 1000 points
playsound block.enchantment_table.use player @a[distance=..50] ~ ~ ~ 2.5 0.6
particle instant_effect ~ ~0.5 ~ 2.5 2 2.5 0.3 320
particle effect ~ ~0.5 ~ 2.5 2 2.5 0.3 320