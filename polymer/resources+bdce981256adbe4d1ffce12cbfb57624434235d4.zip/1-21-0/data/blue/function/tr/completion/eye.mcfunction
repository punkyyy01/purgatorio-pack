tag @s add blue.tr.eye
advancement grant @a only blue:tr/display/eye
scoreboard players set @s blue.tr.silverfish_killed 0
execute if score #.tr.objective_completion blue.config matches 1 run scoreboard players set #.tr.eye_completed blue.config 1
advancement revoke @s only blue:tr/quests/eye
data modify storage blue:trims logs.append.trim set value {"translate":"Eye","color":"#1F8A46"}
scoreboard players set #.temp blue.misc 3
data modify storage blue:trims temp.list set from storage blue:trims owners.eye
function blue:tr/completion/z/setup
data modify storage blue:trims owners.eye set from storage blue:trims temp.list
loot give @s loot blue:tr/eye
execute store result score #.temp blue.misc run clear @s eye_armor_trim_smithing_template 0
execute if score #.temp blue.misc matches 0 run scoreboard players set #.eye_stored blue.misc 4
scoreboard players set #.template_loot blue.misc 1
particle scrape ~ ~1 ~ 0.3 0.3 0.3 70 400
particle glow ~ ~2 ~ 5 3 5 0 180 force
playsound entity.phantom.ambient player @a[distance=..50] ~ ~ ~ 2.5 2
playsound entity.phantom.ambient player @a[distance=..50] ~ ~ ~ 2.5 1
playsound entity.phantom.ambient player @a[distance=..50] ~ ~ ~ 2.5 0.5
playsound block.end_portal.spawn player @a[distance=..20] ~ ~ ~ 1 2
effect give @e[type=!#blue:shared/no_ai,distance=0.01..32] glowing 6 0 true
effect give @s darkness 2 0 true