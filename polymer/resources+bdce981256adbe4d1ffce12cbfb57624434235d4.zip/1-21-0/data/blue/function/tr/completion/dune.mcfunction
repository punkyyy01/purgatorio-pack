tag @s add blue.tr.dune
advancement grant @a only blue:tr/display/dune
scoreboard players set @s blue.tr.desert_time 0
execute if score #.tr.objective_completion blue.config matches 1 run scoreboard players set #.tr.dune_completed blue.config 1
advancement revoke @s only blue:tr/quests/dune
data modify storage blue:trims logs.append.trim set value {"translate":"Dune","color":"#E7C547"}
scoreboard players set #.temp blue.misc 2
data modify storage blue:trims temp.list set from storage blue:trims owners.dune
function blue:tr/completion/z/setup
data modify storage blue:trims owners.dune set from storage blue:trims temp.list
loot give @s loot blue:tr/dune
execute store result score #.temp blue.misc run clear @s dune_armor_trim_smithing_template 0
execute if score #.temp blue.misc matches 0 run scoreboard players set #.dune_stored blue.misc 4
scoreboard players set #.template_loot blue.misc 1
scoreboard players set #.tr.entity_exists blue.misc 1
summon falling_block ~0.35 ~ ~0.35 {Tags:["blue.tr.dune.block","blue.tr.dune.raisure","blue.tr.entity"],BlockState:{Name:sand,id:sand},Motion:[0.175,0.5,0.175]}
summon falling_block ~0.35 ~ ~-0.35 {Tags:["blue.tr.dune.block","blue.tr.dune.raisure","blue.tr.entity"],BlockState:{Name:sand,id:sand},Motion:[0.175,0.5,-0.175]}
summon falling_block ~-0.35 ~ ~-0.35 {Tags:["blue.tr.dune.block","blue.tr.dune.raisure","blue.tr.entity"],BlockState:{Name:sand,id:sand},Motion:[-0.175,0.5,-0.175]}
summon falling_block ~-0.35 ~ ~0.35 {Tags:["blue.tr.dune.block","blue.tr.dune.raisure","blue.tr.entity"],BlockState:{Name:sand,id:sand},Motion:[-0.175,0.5,0.175]}
playsound block.suspicious_gravel.place player @a[distance=..40] ~ ~ ~ 2 0.5
playsound item.brush.brushing.sand player @a[distance=..50] ~ ~ ~ 2.5 0.5
particle falling_dust{block_state:{Name:sand,id:sand}} ~ ~1 ~ 3 3 3 0 480