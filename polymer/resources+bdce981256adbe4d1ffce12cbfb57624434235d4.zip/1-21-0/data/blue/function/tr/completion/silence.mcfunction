tag @s add blue.tr.silence
advancement grant @a only blue:tr/display/silence
execute if score #.tr.objective_completion blue.config matches 1 run scoreboard players set #.tr.silence_completed blue.config 1
advancement revoke @s only blue:tr/quests/silence_down
advancement revoke @s only blue:tr/quests/silence_up
team add blue.tr.silence
data modify storage blue:trims logs.append.trim set value {"translate":"Silence","color":"#3842Cf"}
scoreboard players set #.temp blue.misc 9
data modify storage blue:trims temp.list set from storage blue:trims owners.silence
function blue:tr/completion/z/setup
data modify storage blue:trims owners.silence set from storage blue:trims temp.list
loot give @s loot blue:tr/silence
execute store result score #.temp blue.misc run clear @s silence_armor_trim_smithing_template 0
execute if score #.temp blue.misc matches 0 run scoreboard players set #.silence_stored blue.misc 4
scoreboard players set #.template_loot blue.misc 1
playsound block.sculk_shrieker.shriek player @a[distance=..40] ~ ~ ~ 2 1.5
particle sculk_charge_pop ~ ~0.9 ~ 0.1 0.1 0.1 0.25 100 force
particle sculk_soul ~ ~0.9 ~ 0.1 0.1 0.1 0.2 100 force
playsound entity.warden.death player @a[distance=..60] ~ ~ ~ 2.75 0.5
particle sculk_soul ~ ~1 ~ 0.6 0.6 0.6 0.5 256
effect give @a[tag=!blue.tr.silence,distance=..8] darkness 9 0 true
execute as @e[type=!#blue:shared/no_ai,tag=!blue.tr.silence,distance=0.01..10] run damage @s 20 blue:tr/vortex by @p[tag=blue.tr.silence]
effect give @s darkness 2 0 true