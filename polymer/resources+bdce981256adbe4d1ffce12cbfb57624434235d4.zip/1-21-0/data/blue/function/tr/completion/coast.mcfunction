tag @s add blue.tr.coast
advancement grant @a only blue:tr/display/coast
scoreboard players set @s blue.tr.items_fished 0
execute if score #.tr.objective_completion blue.config matches 1 run scoreboard players set #.tr.coast_completed blue.config 1
data modify storage blue:trims logs.append.trim set value {"translate":"Coast","color":"#C1C888"}
scoreboard players set #.temp blue.misc 1
data modify storage blue:trims temp.list set from storage blue:trims owners.coast
function blue:tr/completion/z/setup
data modify storage blue:trims owners.coast set from storage blue:trims temp.list
loot give @s loot blue:tr/coast
execute store result score #.temp blue.misc run clear @s coast_armor_trim_smithing_template 0
execute if score #.temp blue.misc matches 0 run scoreboard players set #.coast_stored blue.misc 4
scoreboard players set #.template_loot blue.misc 1
particle white_ash ~ ~1 ~ 2 2.25 2 0 1800
playsound item.brush.brushing.sand.complete player @a[distance=..40] ~ ~ ~ 2 0.5
playsound entity.puffer_fish.death player @a[distance=..20] ~ ~ ~ 0.8 1.5
playsound entity.cod.death player @a[distance=..20] ~ ~ ~ 1 1.5
playsound entity.vex.hurt player @a[distance=..20] ~ ~ ~ 0.75 0.8