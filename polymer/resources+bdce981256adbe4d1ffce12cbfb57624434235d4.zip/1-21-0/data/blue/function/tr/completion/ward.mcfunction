tag @s add blue.tr.ward
advancement grant @a only blue:tr/display/ward
scoreboard players set @s blue.tr.damage_blocked 0
execute if score #.tr.objective_completion blue.config matches 1 run scoreboard players set #.tr.ward_completed blue.config 1
advancement revoke @s only blue:tr/quests/ward_stored
data modify storage blue:trims logs.append.trim set value {"translate":"Ward","color":"#5C70AE"}
scoreboard players set #.temp blue.misc 14
data modify storage blue:trims temp.list set from storage blue:trims owners.ward
function blue:tr/completion/z/setup
data modify storage blue:trims owners.ward set from storage blue:trims temp.list
loot give @s loot blue:tr/ward
execute store result score #.temp blue.misc run clear @s ward_armor_trim_smithing_template 0
execute if score #.temp blue.misc matches 0 run scoreboard players set #.ward_stored blue.misc 4
scoreboard players set #.template_loot blue.misc 1
playsound item.shield.break player @a[distance=..40] ~ ~ ~ 2 0.5
playsound item.shield.block player @a[distance=..40] ~ ~ ~ 2 0.5
playsound entity.minecart.riding player @a[distance=..20] ~ ~ ~ 1 2
particle electric_spark ~ ~ ~ 2.5 2 2.5 0.5 500
particle wax_off ~ ~ ~ 4 2.5 4 5 300
scoreboard players set #.cast blue.misc 0
scoreboard players set #.temp blue.misc 802
execute anchored feet rotated ~ 0 positioned ^2.25 ^ ^-0.1 run function blue:tr/effects/ward/kinetic/field/expand