tag @s add blue.tr.snout
advancement grant @a only blue:tr/display/snout
scoreboard players set @s blue.tr.piglin_trades 0
execute if score #.tr.objective_completion blue.config matches 1 run scoreboard players set #.tr.snout_completed blue.config 1
advancement revoke @s only blue:tr/quests/snout
data modify storage blue:trims logs.append.trim set value {"translate":"Snout","color":"#F2B01A"}
scoreboard players set #.temp blue.misc 10
data modify storage blue:trims temp.list set from storage blue:trims owners.snout
function blue:tr/completion/z/setup
data modify storage blue:trims owners.snout set from storage blue:trims temp.list
loot give @s loot blue:tr/snout
execute store result score #.temp blue.misc run clear @s snout_armor_trim_smithing_template 0
execute if score #.temp blue.misc matches 0 run scoreboard players set #.snout_stored blue.misc 4
scoreboard players set #.template_loot blue.misc 1
title @s title ""
playsound entity.villager.work_toolsmith player @a[distance=..40] ~ ~ ~ 2 0.5
particle falling_dust{block_state:"minecraft:yellow_glazed_terracotta"} ~ ~2 ~ 2 2.5 2 0 300
advancement revoke @s only blue:tr/quests/snout