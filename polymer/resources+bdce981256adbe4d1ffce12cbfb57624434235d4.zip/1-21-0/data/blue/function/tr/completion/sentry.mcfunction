tag @s add blue.tr.sentry
advancement grant @a only blue:tr/display/sentry
scoreboard players set @s blue.tr.raids_won 0
execute if score #.tr.objective_completion blue.config matches 1 run scoreboard players set #.tr.sentry_completed blue.config 1
advancement revoke @s only blue:tr/quests/sentry
data modify storage blue:trims logs.append.trim set value {"translate":"Sentry","color":"#4B885B"}
scoreboard players set #.temp blue.misc 7
data modify storage blue:trims temp.list set from storage blue:trims owners.sentry
function blue:tr/completion/z/setup
data modify storage blue:trims owners.sentry set from storage blue:trims temp.list
loot give @s loot blue:tr/sentry
execute store result score #.temp blue.misc run clear @s sentry_armor_trim_smithing_template 0
execute if score #.temp blue.misc matches 0 run scoreboard players set #.sentry_stored blue.misc 4
scoreboard players set #.template_loot blue.misc 1
playsound item.goat_horn.sound.0 player @a[distance=..40] ~ ~ ~ 1.5 0.9
playsound block.anvil.destroy player @a[distance=..40] ~ ~ ~ 1.6 1.5
playsound entity.dragon_fireball.explode player @a[distance=..40] ^ ^ ^2 1.5 1.5
playsound entity.firework_rocket.blast player @a[distance=..40] ^ ^ ^2 1.5 0.5
playsound entity.firework_rocket.launch player @a[distance=..20] ^ ^ ^5 1 1.4
particle happy_villager ~ ~1 ~ 5 2.5 5 0 400
particle enchanted_hit ~ ~1 ~ 2 2.5 2 0.2 200
effect give @s hero_of_the_village 180 4 true
scoreboard players set #.temp blue.misc 500
loot spawn ~ ~1 ~ loot blue:tr/z/emeralds