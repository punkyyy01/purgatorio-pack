data remove storage blue:trims temp.list[{translate:"gui.none"}]
data modify storage blue:trims temp.list append value {"text":"","id":0}
data modify storage blue:trims temp.list[-1].text set from storage blue:shared player_name
execute store result storage blue:trims temp.list[-1].id int 1 run scoreboard players get @s blue.id