tag @s add blue.tr.bolt
advancement grant @a only blue:tr/display/bolt
scoreboard players set @s blue.tr.plain_vault 0
execute if score #.tr.objective_completion blue.config matches 1 run scoreboard players set #.tr.bolt_completed blue.config 1
advancement revoke @s only blue:tr/quests/bolt
data modify storage blue:trims logs.append.trim set value {"translate":"Bolt","color":"#B65D1A"}
scoreboard players set #.temp blue.misc 17
data modify storage blue:trims temp.list set from storage blue:trims owners.bolt
function blue:tr/completion/z/setup
data modify storage blue:trims owners.bolt set from storage blue:trims temp.list
loot give @s loot blue:tr/bolt
execute store result score #.temp blue.misc run clear @s bolt_armor_trim_smithing_template 0
execute if score #.temp blue.misc matches 0 run scoreboard players set #.bolt_stored blue.misc 4
scoreboard players set #.template_loot blue.misc 1
execute positioned ^6 ^1 ^-5 positioned ~ ~-0.5 ~ facing entity @s eyes run function blue:tr/effects/bolt/conduct/player/start
execute positioned ^-8 ^ ^1 positioned ~ ~-0.5 ~ facing entity @s eyes run function blue:tr/effects/bolt/conduct/player/start
execute positioned ^-3 ^-5 ^-2 positioned ~ ~-0.5 ~ facing entity @s eyes run function blue:tr/effects/bolt/conduct/player/start
playsound block.trial_spawner.detect_player player @s ~ ~ ~ 2.5 0.75
playsound entity.lightning_bolt.thunder master @s ~ ~ ~ 2.5 2
particle trial_spawner_detection ~ ~0.6 ~ 3 3 3 0 148