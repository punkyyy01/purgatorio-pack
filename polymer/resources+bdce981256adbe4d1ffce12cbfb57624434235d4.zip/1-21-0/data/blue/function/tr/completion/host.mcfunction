tag @s add blue.tr.host
advancement grant @a only blue:tr/display/host
scoreboard players set @s blue.tr.villagers_cured 0
execute if score #.tr.objective_completion blue.config matches 1 run scoreboard players set #.tr.host_completed blue.config 1
advancement revoke @s only blue:tr/quests/host
data modify storage blue:trims logs.append.trim set value {"translate":"Host","color":"#A34646"}
scoreboard players set #.temp blue.misc 4
data modify storage blue:trims temp.list set from storage blue:trims owners.host
function blue:tr/completion/z/setup
data modify storage blue:trims owners.host set from storage blue:trims temp.list
loot give @s loot blue:tr/host
execute store result score #.temp blue.misc run clear @s host_armor_trim_smithing_template 0
execute if score #.temp blue.misc matches 0 run scoreboard players set #.host_stored blue.misc 4
execute store result score #.temp blue.misc run clear @s coast_armor_trim_smithing_template 0
execute if score #.temp blue.misc matches 0 run scoreboard players set #.coast_stored blue.misc 4
scoreboard players set #.template_loot blue.misc 1
execute at @e[type=!#blue:shared/no_ai,tag=!smithed.strict,distance=0.01..12,sort=random,limit=1] run summon marker ~ ~ ~ {UUID:[I;-1318907857,11,0,1]}
execute at b163102f-0-b-0-1 run tp @e[type=!#blue:shared/no_ai,tag=!smithed.strict,distance=..0.01,limit=1] @s
execute at b163102f-0-b-0-1 run tp @s ~ ~ ~
kill b163102f-0-b-0-1
execute at @s run playsound entity.evoker.cast_spell player @a[distance=..40] ~ ~ ~ 2 1.25
execute at @s run particle damage_indicator ~ ~1 ~ 0.1 0.1 0.1 3 320