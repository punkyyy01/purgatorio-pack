tag @s add blue.tr.tide
advancement grant @a only blue:tr/display/tide
scoreboard players set @s blue.tr.blocks_swam 0
execute if score #.tr.objective_completion blue.config matches 1 run scoreboard players set #.tr.tide_completed blue.config 1
advancement revoke @s only blue:tr/quests/tide
data modify storage blue:trims logs.append.trim set value {"translate":"Tide","color":"#199ADD"}
scoreboard players set #.temp blue.misc 12
data modify storage blue:trims temp.list set from storage blue:trims owners.tide
function blue:tr/completion/z/setup
data modify storage blue:trims owners.tide set from storage blue:trims temp.list
loot give @s loot blue:tr/tide
execute store result score #.temp blue.misc run clear @s tide_armor_trim_smithing_template 0
execute if score #.temp blue.misc matches 0 run scoreboard players set #.tide_stored blue.misc 4
scoreboard players set #.template_loot blue.misc 1
playsound entity.elder_guardian.death player @a[distance=..24] ~ ~ ~ 3 0.65
particle dripping_water ~ ~1 ~ 2 2 2 0 480
function blue:tr/effects/tide/aquatic/burst/water