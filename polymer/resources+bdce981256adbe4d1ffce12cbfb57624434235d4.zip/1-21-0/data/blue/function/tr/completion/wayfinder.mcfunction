scoreboard players set @s blue.tr.blocks_walked 0
tag @s add blue.tr.wayfinder
advancement grant @a only blue:tr/display/wayfinder
execute if score #.tr.objective_completion blue.config matches 1 run scoreboard players set #.tr.wayfinder_completed blue.config 1
data modify storage blue:trims logs.append.trim set value {"translate":"Wayfinder","color":"#F1FFC8"}
scoreboard players set #.temp blue.misc 15
data modify storage blue:trims temp.list set from storage blue:trims owners.wayfinder
function blue:tr/completion/z/setup
data modify storage blue:trims owners.wayfinder set from storage blue:trims temp.list
loot give @s loot blue:tr/wayfinder
execute store result score #.temp blue.misc run clear @s wayfinder_armor_trim_smithing_template 0
execute if score #.temp blue.misc matches 0 run scoreboard players set #.wayfinder_stored blue.misc 4
scoreboard players set #.template_loot blue.misc 1
playsound block.end_portal.spawn player @a[distance=..40] ~ ~ ~ 1.2 1.6
particle enchant ~ ~2 ~ 0.4 0.6 0.4 10 640