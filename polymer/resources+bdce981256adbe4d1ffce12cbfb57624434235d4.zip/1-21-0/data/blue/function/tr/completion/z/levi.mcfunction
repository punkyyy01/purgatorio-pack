execute store result score #.temp blue.misc run time query gametime
execute as @a[tag=blue.tr.spire] if score @s blue.tr.schedule_context = #.temp blue.misc run effect clear @s levitation