tag @s add blue.tr.shaper
advancement grant @a only blue:tr/display/shaper
scoreboard players set @s blue.tr.explosions_survived 0
execute if score #.tr.objective_completion blue.config matches 1 run scoreboard players set #.tr.shaper_completed blue.config 1
advancement revoke @s only blue:tr/quests/shaper_kill
data modify storage blue:trims logs.append.trim set value {"translate":"Shaper","color":"#8F8F8F"}
scoreboard players set #.temp blue.misc 8
data modify storage blue:trims temp.list set from storage blue:trims owners.shaper
function blue:tr/completion/z/setup
data modify storage blue:trims owners.shaper set from storage blue:trims temp.list
loot give @s loot blue:tr/shaper
execute store result score #.temp blue.misc run clear @s shaper_armor_trim_smithing_template 0
execute if score #.temp blue.misc matches 0 run scoreboard players set #.shaper_stored blue.misc 4
scoreboard players set #.template_loot blue.misc 1
playsound entity.tnt.primed player @a[distance=..20] ~ ~ ~ 2.5 1.4
playsound item.flintandsteel.use player @a[distance=..20] ~ ~ ~ 0.6 0.5
playsound block.lava.pop player @a[distance=..20] ~ ~ ~ 1 0.5
execute store result score @s blue.tr.schedule_context run schedule function blue:tr/completion/z/boom 15t append
particle smoke ~ ~1 ~ 0.3 0.2 0.3 0.1 80
particle lava ~ ~1 ~ 0.3 0.2 0.3 0 8