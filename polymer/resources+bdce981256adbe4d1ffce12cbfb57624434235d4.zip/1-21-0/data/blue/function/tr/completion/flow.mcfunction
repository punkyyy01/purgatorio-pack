tag @s add blue.tr.flow
advancement grant @a only blue:tr/display/flow
scoreboard players set @s blue.tr.ominous_vault 0
execute if score #.tr.objective_completion blue.config matches 1 run scoreboard players set #.tr.flow_completed blue.config 1
advancement revoke @s only blue:tr/quests/flow_kills
data modify storage blue:trims logs.append.trim set value {"translate":"Flow","color":"#85B2C5"}
scoreboard players set #.temp blue.misc 18
data modify storage blue:trims temp.list set from storage blue:trims owners.flow
function blue:tr/completion/z/setup
data modify storage blue:trims owners.flow set from storage blue:trims temp.list
loot give @s loot blue:tr/flow
execute store result score #.temp blue.misc run clear @s flow_armor_trim_smithing_template 0
execute if score #.temp blue.misc matches 0 run scoreboard players set #.flow_stored blue.misc 4
scoreboard players set #.template_loot blue.misc 1
summon wind_charge ~ ~ ~2 {acceleration_power:0.1d,Motion:[0.0d,-0.5d,0.0d]}
summon wind_charge ~1.41 ~ ~1.41 {acceleration_power:0.1d,Motion:[0.0d,-0.5d,0.0d]}
summon wind_charge ~2 ~ ~ {acceleration_power:0.1d,Motion:[0.0d,-0.5d,0.0d]}
summon wind_charge ~1.41 ~ ~-1.41 {acceleration_power:0.1d,Motion:[0.0d,-0.5d,0.0d]}
summon wind_charge ~ ~ ~-2 {acceleration_power:0.1d,Motion:[0.0d,-0.5d,0.0d]}
summon wind_charge ~-1.41 ~ ~-1.41 {acceleration_power:0.1d,Motion:[0.0d,-0.5d,0.0d]}
summon wind_charge ~-2 ~ ~ {acceleration_power:0.1d,Motion:[0.0d,-0.5d,0.0d]}
summon wind_charge ~-1.41 ~ ~1.41 {acceleration_power:0.1d,Motion:[0.0d,-0.5d,0.0d]}
playsound block.trial_spawner.ominous_activate player @a[x=0] ~ ~ ~ 3 0.5
particle trial_spawner_detection_ominous ~ ~-0.5 ~ 3 3 3 0 1000
playsound entity.breeze.inhale player @a[distance=..40] ~ ~ ~ 2 0.5