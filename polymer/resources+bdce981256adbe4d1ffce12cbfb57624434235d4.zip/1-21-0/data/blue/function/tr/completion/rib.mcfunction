tag @s add blue.tr.rib
advancement grant @a only blue:tr/display/rib
scoreboard players set @s blue.tr.lava_seconds 0
execute if score #.tr.objective_completion blue.config matches 1 run scoreboard players set #.tr.rib_completed blue.config 1
advancement revoke @s only blue:tr/quests/rib_complete
team add blue.tr.rib
data modify storage blue:trims logs.append.trim set value {"translate":"Rib","color":"#E6484B"}
scoreboard players set #.temp blue.misc 6
data modify storage blue:trims temp.list set from storage blue:trims owners.rib
function blue:tr/completion/z/setup
data modify storage blue:trims owners.rib set from storage blue:trims temp.list
loot give @s loot blue:tr/rib
execute store result score #.temp blue.misc run clear @s rib_armor_trim_smithing_template 0
execute if score #.temp blue.misc matches 0 run scoreboard players set #.rib_stored blue.misc 4
scoreboard players set #.template_loot blue.misc 1
execute as @e[type=!#blue:shared/peaceful,distance=0.1..4.5] run damage @s 14 blue:tr/fire by @p
execute at @e[type=!#blue:shared/peaceful,distance=0.1..4.5] run particle small_flame ~ ~1 ~ 0.3 0.5 0.3 0.02 6
particle flame ~ ~1 ~ 0 0.2 0 0.2 20 normal @a[scores={blue.particles=2..}]
playsound entity.blaze.shoot player @a[distance=..20] ~ ~ ~ 1 1
playsound entity.blaze.shoot player @a[distance=..40] ~ ~ ~ 2 0.5
particle lava ~ ~1 ~ 0.65 0.5 0.65 0 48
particle flame ~ ~1 ~ 0 0.2 0 0.2 30