tag @s add blue.tr.wild
advancement grant @a only blue:tr/display/wild
scoreboard players set @s blue.tr.animals_bred 0
scoreboard players set @s blue.tr.animals_tamed 0
execute if score #.tr.objective_completion blue.config matches 1 run scoreboard players set #.tr.wild_completed blue.config 1
advancement revoke @s only blue:tr/quests/wild_tames
data modify storage blue:trims logs.append.trim set value {"translate":"Wild","color":"#00D529"}
scoreboard players set #.temp blue.misc 16
data modify storage blue:trims temp.list set from storage blue:trims owners.wild
function blue:tr/completion/z/setup
data modify storage blue:trims owners.wild set from storage blue:trims temp.list
loot give @s loot blue:tr/wild
execute store result score #.temp blue.misc run clear @s wild_armor_trim_smithing_template 0
execute if score #.temp blue.misc matches 0 run scoreboard players set #.wild_stored blue.misc 4
scoreboard players set #.template_loot blue.misc 1
playsound entity.player.levelup player @a[distance=..50] ~ ~ ~ 2.5 0.8
particle spore_blossom_air ~ ~1.2 ~ 0.6 0.8 0.6 1 256
particle spore_blossom_air ~ ~1.2 ~ 2.5 2 2.5 1 256