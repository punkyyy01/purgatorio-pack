tag @s add blue.tr.vex
advancement grant @a only blue:tr/display/vex
scoreboard players set @s blue.tr.mobs_killed 0
execute if score #.tr.objective_completion blue.config matches 1 run scoreboard players set #.tr.vex_completed blue.config 1
data modify storage blue:trims logs.append.trim set value {"translate":"Vex","color":"#CFC6A5"}
scoreboard players set #.temp blue.misc 13
data modify storage blue:trims temp.list set from storage blue:trims owners.vex
function blue:tr/completion/z/setup
data modify storage blue:trims owners.vex set from storage blue:trims temp.list
loot give @s loot blue:tr/vex
execute store result score #.temp blue.misc run clear @s vex_armor_trim_smithing_template 0
execute if score #.temp blue.misc matches 0 run scoreboard players set #.vex_stored blue.misc 4
scoreboard players set #.template_loot blue.misc 1
playsound entity.vex.death player @a[distance=..40] ~ ~ ~ 2 1
playsound entity.vex.death player @a[distance=..40] ~ ~ ~ 2 0.5
playsound entity.vex.charge player @a[distance=..40] ~ ~ ~ 2 0.5
playsound entity.allay.ambient_with_item player @a[x=0] ~ ~ ~ 3 2
particle white_smoke ~ ~1 ~ 0.1 0.1 0.1 0.25 340
effect give @s strength 2 0 true
effect give @s speed 2 1 true