$scoreboard players operation @s blue.particles = $(name) blue.particles
$scoreboard players reset $(name) blue.id
$scoreboard players set @s blue.id $(id)