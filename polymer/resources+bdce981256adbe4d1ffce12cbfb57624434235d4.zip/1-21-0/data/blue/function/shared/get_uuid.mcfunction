data remove storage blue:shared UUID
$data modify storage blue:shared UUID set from storage blue:shared players[{id:$(player_id)}].UUID
execute unless data storage blue:shared UUID run data modify storage blue:shared UUID set from entity @s UUID