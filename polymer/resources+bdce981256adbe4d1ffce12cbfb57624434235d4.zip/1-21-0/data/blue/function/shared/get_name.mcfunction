loot replace block 200600 2 200600 container.10 loot blue:tr/z/head
data modify storage blue:shared player_name set from block 200600 2 200600 Items[-1].components.minecraft:profile.name
function #blue:shared/setup_logs